<script lang="tsx" setup>
import { defaultMockModelName, modelMappingList, triggerModelTermination } from '@/components/MarkdownPreview/models'
import { type InputInst } from 'naive-ui'
import type { SelectBaseOption } from 'naive-ui/es/select/src/interface'
import { isGithubDeployed } from '@/config'
import { renderMarkdownText } from '@/components/MarkdownPreview/plugins/markdown'
import type { CrossTransformFunction } from '@/components/MarkdownPreview/models'

const businessStore = useBusinessStore()

const modelListSelections = computed(() => {
  return modelMappingList.map<SelectBaseOption>((modelItem) => {
    let disabled = false
    if (isGithubDeployed && modelItem.modelName !== defaultMockModelName) {
      disabled = true
    }
    return {
      label: modelItem.label,
      value: modelItem.modelName,
      disabled
    }
  })
})

const loading = ref(true)
setTimeout(() => { loading.value = false }, 400)

const stylizingLoading = ref(false)
const inputTextString = ref('')
const refInputTextString = ref<InputInst | null>()
const refMessagesContainer = ref<HTMLElement>()

/** 手机端侧边栏 */
const showSidebar = ref(false)

/** 流式读取相关 */
const textBuffer = ref('')
const displayText = ref('')
const isAbort = ref(false)
const readIsOver = ref(false)
let typingAnimationFrame: number | null = null

const renderedMarkdown = computed(() => {
  return renderMarkdownText(displayText.value)
})

/** 发送消息 */
const handleSend = async () => {
  if (stylizingLoading.value) {
    isAbort.value = true
    if (typingAnimationFrame) {
      cancelAnimationFrame(typingAnimationFrame)
      typingAnimationFrame = null
    }
    businessStore.finishAssistantMessage()
    stylizingLoading.value = false
    triggerModelTermination()
    return
  }

  const text = inputTextString.value.trim()
  if (!text) return

  businessStore.addUserMessage(text)
  inputTextString.value = ''

  const messages = businessStore.getApiMessages()
  forceScrollToBottom()

  displayText.value = ''
  textBuffer.value = ''
  isAbort.value = false
  readIsOver.value = false

  stylizingLoading.value = true

  const { error, reader } = await businessStore.createAssistantWriterStylized({
    text,
    messages
  })

  if (error || !reader) {
    stylizingLoading.value = false
    window.$ModalMessage.error('请求失败，请重试')
    triggerModelTermination()
    return
  }

  readTextStream(reader)
}

/** 流式读取 */
const readTextStream = async (reader: ReadableStreamDefaultReader<string>) => {
  const textDecoder = new TextDecoder('utf-8')
  const transformer = businessStore.currentModelItem?.transformStreamValue as CrossTransformFunction

  while (true) {
    if (isAbort.value) break

    try {
      const { value, done } = await reader.read()
      if (done) {
        readIsOver.value = true
        break
      }

      if (!transformer) break

      const stream = transformer(value, textDecoder)
      if (stream.done) {
        readIsOver.value = true
        break
      }

      if (stream.content) {
        textBuffer.value += stream.content
        businessStore.appendAssistantMessage(stream.content)
      }

      if (typingAnimationFrame === null) {
        showTyping()
      }
    } catch (error) {
      readIsOver.value = true
      break
    }
  }
}

/** 打字机效果 */
const showTyping = () => {
  if (isAbort.value && typingAnimationFrame) {
    cancelAnimationFrame(typingAnimationFrame)
    typingAnimationFrame = null
    return
  }

  if (!readIsOver.value) {
    if (textBuffer.value.length > 0) {
      const nextChunk = textBuffer.value.substring(0, 10)
      displayText.value += nextChunk
      textBuffer.value = textBuffer.value.substring(10)
    }
    typingAnimationFrame = requestAnimationFrame(showTyping)
  } else {
    if (textBuffer.value.length > 0) {
      displayText.value += textBuffer.value
      textBuffer.value = ''
    }
    businessStore.finishAssistantMessage()
    stylizingLoading.value = false
    triggerModelTermination()
    window.$ModalNotification.success({ title: '生成完毕', duration: 1500 })
    typingAnimationFrame = null
  }

  smartScrollToBottom()
}

/** 判断用户是否在底部附近（100px 阈值） */
const isNearBottom = (): boolean => {
  const el = refMessagesContainer.value
  if (!el) return true
  return el.scrollHeight - el.scrollTop - el.clientHeight < 100
}

/** 智能滚动：仅在用户处于底部时自动滚动 */
const smartScrollToBottom = async () => {
  await nextTick()
  if (isNearBottom()) {
    const el = refMessagesContainer.value
    if (el) {
      el.scrollTop = el.scrollHeight
    }
  }
}

/** 发送消息时强制滚到底部 */
const forceScrollToBottom = async () => {
  await nextTick()
  const el = refMessagesContainer.value
  if (el) {
    el.scrollTop = el.scrollHeight
  }
}

const placeholder = computed(() => {
  if (stylizingLoading.value) return '生成中...'
  return '输入消息...'
})

/** 新建对话 */
const handleNewChat = () => {
  if (stylizingLoading.value) return
  businessStore.createConversation()
  inputTextString.value = ''
  displayText.value = ''
  textBuffer.value = ''
  showSidebar.value = false
  nextTick(() => { refInputTextString.value?.focus() })
}

/** 切换对话（手机端自动关闭侧边栏） */
const handleSwitchConv = (id: string) => {
  businessStore.switchConversation(id)
  showSidebar.value = false
}

const isCurrentStreaming = (msg: any) => {
  return msg.role === 'assistant' && msg.isStreaming
}

/** 时间格式化 */
const formatTime = (ts: number) => {
  const d = new Date(ts)
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${hh}:${mm}`
}

/** 预设提示词 */
const promptTextList = ref([
  '打个招呼吧，并告诉我你的名字',
  '用中文解释什么是 Vue3 Composition API'
])

const handlePromptClick = (text: string) => {
  inputTextString.value = text
  nextTick(() => { refInputTextString.value?.focus() })
}

/** 复制消息 */
const handleCopyMsg = (content: string) => {
  navigator.clipboard.writeText(content).then(() => {
    window.$ModalMessage.success('已复制')
  })
}

/** HTML 预览 */
const htmlPreviewVisible = ref(false)
const htmlPreviewCode = ref('')

const handlePreviewHtml = (code: string) => {
  htmlPreviewCode.value = code
  htmlPreviewVisible.value = true
}

/** 提取 HTML 代码块并添加预览按钮（后处理 v-html） */
const processRenderedHtml = (html: string): string => {
  // 匹配 <pre><code class="language-html">...</code></pre> 或 <pre><code class="lang-html">
  return html.replace(
    /(<pre[^>]*><code[^>]*class="[^"]*(?:language|lang)-html[^"]*"[^>]*>)([\s\S]*?)(<\/code><\/pre>)/g,
    '$1$2<span class="html-preview-btn" onclick="window.__previewHtml(this)">预览</span>$3'
  )
}

/** 注册全局预览回调 */
onMounted(() => {
  ;(window as any).__previewHtml = (el: HTMLElement) => {
    const pre = el.closest('pre')
    if (pre) {
      const code = pre.querySelector('code')?.textContent || ''
      handlePreviewHtml(code)
    }
  }
})

onUnmounted(() => {
  delete (window as any).__previewHtml
})
</script>

<template>
  <div
    class="chat-app"
    :class="{ 'sidebar-open': showSidebar }"
  >
    <!-- 移动端遮罩 -->
    <div
      v-if="showSidebar"
      class="sidebar-overlay sm:hidden"
      @click="showSidebar = false"
    ></div>

    <!-- 左侧会话列表（桌面端固定 / 手机端抽屉） -->
    <aside
      class="sidebar"
      :class="{ 'sidebar-visible': showSidebar }"
    >
      <!-- 新建对话按钮 -->
      <div class="sidebar-header">
        <n-button
          block
          type="primary"
          :disabled="stylizingLoading"
          @click="handleNewChat"
        >
          <template #icon>
            <div class="i-hugeicons:plus text-16"></div>
          </template>
          新建对话
        </n-button>
      </div>

      <!-- 对话列表 -->
      <div class="sidebar-list">
        <div
          v-for="conv in businessStore.conversations"
          :key="conv.id"
          class="conv-item"
          :class="{ active: businessStore.activeConversationId === conv.id }"
          @click="handleSwitchConv(conv.id)"
        >
          <div class="conv-info">
            <div class="conv-title">{{ conv.title }}</div>
            <div class="conv-time">{{ formatTime(conv.updatedAt) }}</div>
          </div>
          <n-popconfirm
            v-if="!stylizingLoading"
            @positive-click="businessStore.deleteConversation(conv.id)"
          >
            <template #trigger>
              <div
                class="conv-delete"
                @click.stop
              >
                <div class="i-hugeicons:delete-02 text-14"></div>
              </div>
            </template>
            确定删除此对话？
          </n-popconfirm>
        </div>

        <div
          v-if="businessStore.conversations.length === 0"
          class="conv-empty"
        >
          暂无对话
        </div>
      </div>

      <!-- 底部模型选择 -->
      <div class="sidebar-footer">
        <div class="model-label">当前模型</div>
        <n-select
          v-model:value="businessStore.systemModelName"
          size="small"
          placeholder="选择模型"
          :disabled="stylizingLoading"
          :options="modelListSelections"
        />
      </div>
    </aside>

    <!-- 右侧聊天主区域 -->
    <main class="chat-main">
      <!-- 顶部栏 -->
      <header class="chat-header">
        <div class="header-left">
          <!-- 手机端汉堡菜单 -->
          <div
            class="menu-btn sm:hidden"
            @click="showSidebar = !showSidebar"
          >
            <div class="i-hugeicons:menu-02 text-22 c-#303133"></div>
          </div>
          <div class="header-title-wrap">
            <div class="i-hugeicons:ai-chat-02 text-20 c-primary"></div>
            <span class="header-title">
              {{ businessStore.activeConversation?.title || 'AI 助手' }}
            </span>
          </div>
        </div>
        <div class="header-right">
          <n-button
            quaternary
            circle
            size="small"
            :disabled="stylizingLoading"
            @click="handleNewChat"
          >
            <div class="i-hugeicons:plus text-18"></div>
          </n-button>
        </div>
      </header>

      <!-- 消息列表 -->
      <div
        ref="refMessagesContainer"
        class="chat-messages"
      >
        <!-- 空状态 -->
        <div
          v-if="businessStore.activeMessages.length === 0"
          class="empty-state"
        >
          <div class="empty-icon">
            <div class="i-hugeicons:ai-chat-02"></div>
          </div>
          <div class="empty-text">开始一段新对话</div>
          <div class="empty-prompts">
            <div
              v-for="(textItem, idx) in promptTextList"
              :key="idx"
              class="prompt-chip"
              @click="handlePromptClick(textItem)"
            >
              {{ textItem }}
            </div>
          </div>
        </div>

        <!-- 消息气泡 -->
        <div
          v-else
          class="messages-list"
        >
          <div
            v-for="msg in businessStore.activeMessages"
            :key="msg.id"
            class="msg-row"
            :class="msg.role === 'user' ? 'msg-user' : 'msg-assistant'"
          >
            <!-- 用户消息 -->
            <template v-if="msg.role === 'user'">
              <div class="msg-bubble msg-bubble-user">
                {{ msg.content }}
              </div>
            </template>

            <!-- 助手消息 -->
            <template v-else>
              <div class="msg-bubble msg-bubble-assistant">
                <div
                  v-if="isCurrentStreaming(msg) && !displayText"
                  class="thinking-indicator"
                >
                  <div class="i-svg-spinners:3-dots-rotate text-18"></div>
                  <span>思考中...</span>
                </div>
                <div
                  v-else
                  class="markdown-wrapper"
                  v-html="processRenderedHtml(isCurrentStreaming(msg) ? renderedMarkdown : renderMarkdownText(msg.content))"
                ></div>
              </div>
              <!-- 复制按钮 -->
              <div
                v-if="!msg.isStreaming && msg.content"
                class="msg-action"
                @click="handleCopyMsg(msg.content)"
              >
                <div class="i-hugeicons:copy-01 text-14"></div>
              </div>
            </template>
          </div>

          <!-- 流式光标 -->
          <div
            v-if="stylizingLoading && displayText"
            class="msg-row msg-assistant"
          >
            <div class="msg-bubble msg-bubble-assistant">
              <div class="i-svg-spinners:pulse-3 text-18 c-#999"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 输入区域 -->
      <div class="chat-input-area">
        <div class="input-wrapper">
          <n-input
            ref="refInputTextString"
            v-model:value="inputTextString"
            type="textarea"
            autofocus
            :autosize="{ minRows: 1, maxRows: 6 }"
            class="chat-textarea"
            :placeholder="placeholder"
            @keydown.enter.exact.prevent="handleSend"
          />
          <button
            class="send-btn"
            :class="{ loading: stylizingLoading }"
            @click.stop.prevent="handleSend"
          >
            <div
              v-if="stylizingLoading"
              class="i-svg-spinners:pulse-2 text-20"
            ></div>
            <div
              v-else
              class="i-hugeicons:start-up-02 text-20"
            ></div>
          </button>
        </div>
        <div class="input-hint">
          按 Enter 发送，Shift+Enter 换行
        </div>
      </div>
    </main>

    <!-- HTML 预览弹窗 -->
    <n-modal
      v-model:show="htmlPreviewVisible"
      preset="card"
      title="HTML 预览"
      class="html-preview-modal"
      :style="{ width: '90vw', maxWidth: '900px' }"
      :segmented="{ content: true }"
      closable
    >
      <iframe
        :srcdoc="htmlPreviewCode"
        class="html-preview-frame"
        sandbox="allow-scripts allow-same-origin"
        title="HTML Preview"
      ></iframe>
    </n-modal>
  </div>
</template>

<style lang="scss" scoped>
.chat-app {
  display: flex;
  width: 100%;
  height: 100dvh;
  overflow: hidden;
  background: #fff;
  position: relative;
}

/* ===== 侧边栏 ===== */
.sidebar {
  width: 260px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  background: #f7f7f8;
  border-right: 1px solid #e5e5e5;
  z-index: 100;
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  @media (max-width: 639px) {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    transform: translateX(-100%);
    box-shadow: 4px 0 24px rgba(0, 0, 0, 0.15);
  }

  &.sidebar-visible {
    @media (max-width: 639px) {
      transform: translateX(0);
    }
  }
}

.sidebar-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  z-index: 99;
  backdrop-filter: blur(2px);
}

.sidebar-header {
  padding: 12px;
}

.sidebar-list {
  flex: 1;
  overflow-y: auto;
  padding: 0 8px;
  -webkit-overflow-scrolling: touch;
}

.conv-item {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  margin-bottom: 2px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background: #efefef;
  }

  &.active {
    background: #e8e8e8;
    font-weight: 600;
  }
}

.conv-info {
  flex: 1;
  min-width: 0;
}

.conv-title {
  font-size: 14px;
  color: #666;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  .active & {
    color: #303133;
  }
}

.conv-time {
  font-size: 11px;
  color: #999;
  margin-top: 2px;
}

.conv-delete {
  opacity: 0;
  transition: opacity 0.2s;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;

  .conv-item:hover & {
    opacity: 1;
  }

  &:hover {
    background: #ddd;
  }
}

.conv-empty {
  text-align: center;
  padding: 40px 0;
  font-size: 13px;
  color: #bbb;
}

.sidebar-footer {
  padding: 12px;
  border-top: 1px solid #e5e5e5;
}

.model-label {
  font-size: 12px;
  color: #999;
  margin-bottom: 6px;
}

/* ===== 主聊天区域 ===== */
.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 100%;
}

/* 顶部栏 */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  border-bottom: 1px solid #f0f0f0;
  flex-shrink: 0;
  background: #fff;
  z-index: 10;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.menu-btn {
  cursor: pointer;
  padding: 4px;
  border-radius: 6px;
  flex-shrink: 0;

  &:active {
    background: #f0f0f0;
  }
}

.header-title-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.header-title {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

/* 消息列表 */
.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  -webkit-overflow-scrolling: touch;

  @media (min-width: 640px) {
    padding: 20px;
  }
}

/* 空状态 */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  padding: 20px;
}

.empty-icon {
  font-size: 56px;
  color: #ddd;
  margin-bottom: 16px;

  @media (min-width: 640px) {
    font-size: 64px;
  }
}

.empty-text {
  font-size: 16px;
  color: #999;
  margin-bottom: 20px;
}

.empty-prompts {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
  max-width: 400px;
}

.prompt-chip {
  padding: 8px 14px;
  border-radius: 20px;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s;
  background: #f5f5f5;
  color: #666;
  border: 1px solid transparent;

  &:hover {
    background: #eaeaea;
  }

  &:active {
    background: #e0e0e0;
  }
}

/* 消息列表 */
.messages-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

.msg-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.msg-user {
  justify-content: flex-end;
}

.msg-assistant {
  justify-content: flex-start;
}

.msg-bubble {
  max-width: 85%;
  padding: 12px 16px;
  border-radius: 16px;
  font-size: 15px;
  line-height: 1.6;
  word-break: break-word;
  overflow-wrap: break-word;

  @media (min-width: 640px) {
    max-width: 75%;
  }
}

.msg-bubble-user {
  background: var(--n-color-primary, #7c3aed);
  color: #fff;
  border-bottom-right-radius: 4px;
}

.msg-bubble-assistant {
  background: #f5f5f5;
  color: #303133;
  border-bottom-left-radius: 4px;
}

.thinking-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #999;
}

.msg-action {
  flex-shrink: 0;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  color: #bbb;
  transition: all 0.2s;
  align-self: flex-start;
  margin-top: 2px;

  &:hover {
    color: #666;
    background: #eee;
  }
}

/* 输入区域 */
.chat-input-area {
  flex-shrink: 0;
  padding: 10px 16px 12px;
  border-top: 1px solid #f0f0f0;
  background: #fff;

  @media (min-width: 640px) {
    padding: 12px 20px 16px;
  }
}

.input-wrapper {
  position: relative;
  width: 100%;
  max-width: 800px;
  margin: 0 auto;
}

.chat-textarea {
  width: 100%;

  :deep(.n-input-wrapper) {
    padding-right: 48px;
  }

  :deep(.n-input__textarea-el) {
    font-size: 15px;
  }
}

.send-btn {
  position: absolute;
  right: 10px;
  bottom: 50%;
  transform: translateY(50%);
  width: 36px;
  height: 36px;
  border-radius: 10px;
  border: none;
  background: var(--n-color-primary, #7c3aed);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
  z-index: 10;

  &:hover {
    opacity: 0.9;
    transform: translateY(50%) scale(1.05);
  }

  &:active {
    transform: translateY(50%) scale(0.95);
  }

  &.loading {
    background: #e0e0e0;
    color: #999;
  }
}

.input-hint {
  text-align: center;
  font-size: 11px;
  color: #bbb;
  margin-top: 6px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;

  @media (max-width: 639px) {
    display: none;
  }
}

/* HTML 预览按钮 */
:deep(.html-preview-btn) {
  display: inline-block;
  position: absolute;
  top: 8px;
  right: 8px;
  padding: 2px 10px;
  font-size: 12px;
  color: #fff;
  background: var(--n-color-primary, #7c3aed);
  border-radius: 4px;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.2s;
  z-index: 5;
}

:deep(pre:hover .html-preview-btn) {
  opacity: 1;
}

/* HTML 预览 iframe */
.html-preview-frame {
  width: 100%;
  height: 60vh;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  background: #fff;
}
</style>

<style lang="scss">
.markdown-wrapper {
  h1 { font-size: 1.6em; }
  h2 { font-size: 1.4em; }
  h3 { font-size: 1.2em; }
  h4 { font-size: 1em; }
  h5 { font-size: 0.875em; }
  h6 { font-size: 0.85em; }
  h1,h2,h3,h4,h5,h6 { margin: 12px 0 8px; line-height: 1.3; }
  .markdown-wrapper:first-child {
    h1, h2, h3 { margin-top: 0; }
  }
  ul,ol { padding-left: 1.5em; line-height: 0.8; }
  ul,li,ol { list-style-position: outside; white-space: normal; }
  li { line-height: 1.7; }
  li > code { background: #e5e5e5; white-space: pre; margin: 2px; padding: 2px 6px; border-radius: 5px; font-size: 0.9em; }
  ol ol { padding-left: 20px; }
  ul ul { padding-left: 20px; }
  hr { margin: 16px 0; }
  a { color: var(--n-color-primary, #7c3aed); font-weight: bolder; text-decoration: underline; padding: 0 3px; }
  p { line-height: 1.5; margin: 6px 0; }
  p > code { background: #e5e5e5; white-space: pre; margin: 0 4px; padding: 2px 6px; border-radius: 5px; font-size: 0.9em; }
  p img { display: inline-block; max-width: 100%; }
  li > p { line-height: 2; }
  blockquote { padding: 10px; margin: 12px 0; border-left: 4px solid #ccc; background-color: #f9f9f9; color: #555; border-radius: 0 8px 8px 0; }
  blockquote > p { margin: 0; }
  .katex { color: var(--n-color-primary, #7c3aed); }
  kbd { display: inline-block; padding: 0.1em 0.3em; background: #fcfcfc; color: #555; border: 1px solid #ccc; border-bottom-width: 2px; border-radius: 0.2em; font-size: 0.9em; }
  table { width: fit-content; border-collapse: collapse; margin: 12px 0; font-size: 14px; }
  th, td { padding: 7px 10px; text-align: left; border: 1px solid #ddd; }
  th { background: #f2f2f2; font-weight: 600; }
  tr:nth-child(even) { background: #f9f9f9; }
  tr:hover { background: #f1f1f1; }
  pre { margin: 10px 0; border-radius: 8px; overflow-x: auto; -webkit-overflow-scrolling: touch; font-size: 13px; position: relative; }
  pre code { font-size: 13px; }
  .think-wrapper { padding-left: 12px; font-size: 14px; color: #8b8b8b; border-left: 2px solid #e5e5e5; }
  .think-wrapper p { line-height: 26px; }
}
</style>

const LayoutDefault = () => import('@/components/Layout/default.vue')

const childrenRoutes: Array<RouteRecordRaw> = [
  {
    path: '/chat',
    component: () => import('@/views/chat.vue'),
    name: 'ChatIndex'
  }
]

export default childrenRoutes

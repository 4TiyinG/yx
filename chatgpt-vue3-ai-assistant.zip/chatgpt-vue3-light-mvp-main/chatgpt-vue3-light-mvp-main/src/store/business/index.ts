import { defineStore } from 'pinia'
import { v4 as uuidv4 } from 'uuid'

import * as TransformUtils from '@/components/MarkdownPreview/transform'
import { defaultModelName, modelMappingList } from '@/components/MarkdownPreview/models'

export interface MessageItem {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
  isStreaming?: boolean
}

export interface ConversationItem {
  id: string
  title: string
  messages: MessageItem[]
  createdAt: number
  updatedAt: number
}

export interface BusinessState {
  systemModelName: string
  conversations: ConversationItem[]
  activeConversationId: string | null
}

const STORAGE_KEY = 'ai-chat-data'

/** 从 localStorage 加载数据 */
function loadFromStorage (): Partial<BusinessState> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return {}
    const data = JSON.parse(raw)
    return {
      systemModelName: data.systemModelName || defaultModelName,
      conversations: Array.isArray(data.conversations) ? data.conversations : [],
      activeConversationId: data.activeConversationId || null
    }
  } catch {
    return {}
  }
}

/** 保存到 localStorage */
function saveToStorage (state: BusinessState) {
  try {
    const data = {
      systemModelName: state.systemModelName,
      conversations: state.conversations.map(c => ({
        ...c,
        messages: c.messages.map(m => ({
          ...m,
          isStreaming: false
        }))
      })),
      activeConversationId: state.activeConversationId
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  } catch (e) {
    console.warn('localStorage 保存失败：', e)
  }
}

const saved = loadFromStorage()

export const useBusinessStore = defineStore('business-store', {
  state: (): BusinessState => {
    return {
      systemModelName: saved.systemModelName || defaultModelName,
      conversations: saved.conversations || [],
      activeConversationId: saved.activeConversationId || null
    }
  },
  getters: {
    currentModelItem (state) {
      return modelMappingList.find(v => v.modelName === state.systemModelName)
    },
    activeConversation (state): ConversationItem | null {
      if (!state.activeConversationId) return null
      return state.conversations.find(c => c.id === state.activeConversationId) || null
    },
    activeMessages (state): MessageItem[] {
      const conv = state.conversations.find(c => c.id === state.activeConversationId)
      return conv ? conv.messages : []
    }
  },
  actions: {
    /** 持久化当前状态 */
    _persist () {
      saveToStorage(this.$state)
    },

    /** 创建新对话 */
    createConversation () {
      const conv: ConversationItem = {
        id: uuidv4(),
        title: '新对话',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now()
      }
      this.conversations.unshift(conv)
      this.activeConversationId = conv.id
      this._persist()
      return conv
    },

    /** 切换对话 */
    switchConversation (id: string) {
      this.activeConversationId = id
      this._persist()
    },

    /** 删除对话 */
    deleteConversation (id: string) {
      const idx = this.conversations.findIndex(c => c.id === id)
      if (idx !== -1) {
        this.conversations.splice(idx, 1)
        if (this.activeConversationId === id) {
          this.activeConversationId = this.conversations.length > 0 ? this.conversations[0].id : null
        }
        this._persist()
      }
    },

    /** 添加用户消息 */
    addUserMessage (text: string) {
      if (!this.activeConversationId) {
        this.createConversation()
      }
      const conv = this.conversations.find(c => c.id === this.activeConversationId)
      if (!conv) return

      const msg: MessageItem = {
        id: uuidv4(),
        role: 'user',
        content: text,
        timestamp: Date.now()
      }
      conv.messages.push(msg)

      if (conv.messages.filter(m => m.role === 'user').length === 1) {
        conv.title = text.substring(0, 30) + (text.length > 30 ? '...' : '')
      }
      conv.updatedAt = Date.now()
      this._persist()
      return msg
    },

    /** 添加/更新助手消息（流式追加） */
    appendAssistantMessage (content: string) {
      const conv = this.conversations.find(c => c.id === this.activeConversationId)
      if (!conv) return

      const lastMsg = conv.messages[conv.messages.length - 1]
      if (lastMsg && lastMsg.role === 'assistant' && lastMsg.isStreaming) {
        lastMsg.content += content
      } else {
        conv.messages.push({
          id: uuidv4(),
          role: 'assistant',
          content,
          timestamp: Date.now(),
          isStreaming: true
        })
      }
    },

    /** 完成助手消息流式输出 */
    finishAssistantMessage () {
      const conv = this.conversations.find(c => c.id === this.activeConversationId)
      if (!conv) return

      const lastMsg = conv.messages[conv.messages.length - 1]
      if (lastMsg && lastMsg.role === 'assistant' && lastMsg.isStreaming) {
        lastMsg.isStreaming = false
        lastMsg.timestamp = Date.now()
      }
      conv.updatedAt = Date.now()
      this._persist()
    },

    /** 获取当前对话的 messages 数组（用于 API 请求） */
    getApiMessages (): Array<{role: string, content: string}> {
      const conv = this.conversations.find(c => c.id === this.activeConversationId)
      if (!conv) return []
      return conv.messages
        .filter(m => !m.isStreaming)
        .map(m => ({ role: m.role, content: m.content }))
    },

    /** Event Stream 调用大模型接口（支持多轮对话） */
    async createAssistantWriterStylized(data: { text: string, messages?: Array<{role: string, content: string}> }): Promise<{error: number, reader: ReadableStreamDefaultReader<string> | null}> {
      return new Promise((resolve) => {
        if (!this.currentModelItem?.chatFetch) {
          return resolve({ error: 1, reader: null })
        }
        this.currentModelItem.chatFetch(data.text, data.messages)
          .then((res) => {
            if (res.body) {
              const reader = res.body
                .pipeThrough(new TextDecoderStream())
                .pipeThrough(TransformUtils.splitStream('\n'))
                .getReader()
              resolve({ error: 0, reader })
            } else {
              resolve({ error: 1, reader: null })
            }
          })
          .catch((err) => {
            console.error('API 请求失败：', err)
            resolve({ error: 1, reader: null })
          })
      })
    }
  }
})

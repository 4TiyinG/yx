#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SIZE 1000

typedef struct {
    char name[100];
    int population;
} Industry;

int main() {
    Industry data[MAX_SIZE];
    int n = 0;

    // 1. 读取原始数据文件
    FILE *fp = fopen("employ-data.txt", "r");
    if (fp == NULL) {
        printf("读取失败！请检查 employ-data.txt 是否与代码在同一目录下。\n");
        return 1;
    }

    char line[256];
    while (fgets(line, sizeof(line), fp) != NULL) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) == 0) continue;

        char *name_ptr = line;
        char *pop_ptr = NULL;

        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] == ' ' || line[i] == '\t' || line[i] == ',' || line[i] == ':') {
                pop_ptr = &line[i];
                line[i] = '\0';
                pop_ptr++;
                break;
            }
        }

        if (pop_ptr != NULL) {
            int pop = atoi(pop_ptr);
            if (pop > 0) {
                strcpy(data[n].name, name_ptr);
                data[n].population = pop;
                n++;
            }
        }

        if (n >= MAX_SIZE) {
            printf("警告：数据量达到上限 %d 条，后续数据将被忽略！\n", MAX_SIZE);
            break;
        }
    }
    fclose(fp);

    printf("成功读取到 %d 条数据。\n", n);
    if (n == 0) {
        printf("没有读取到有效数据，请检查 employ-data.txt 的内容格式。\n");
        return 1;
    }

    // 2. 排序（【改为：选择排序】降序）
    for (int i = 0; i < n - 1; i++) {
        int max_idx = i; // 假设当前 i 位置是最大的
        // 在剩余未排序的元素中寻找真正的最大值
        for (int j = i + 1; j < n; j++) {
            if (data[j].population > data[max_idx].population) {
                max_idx = j; // 更新最大值的索引
            }
        }
        // 如果找到的最大值不在当前 i 位置，则交换
        if (max_idx != i) {
            Industry temp = data[i];
            data[i] = data[max_idx];
            data[max_idx] = temp;
        }
    }

    // 3. 显示并写入文件（每次运行强制替换旧文件）
    remove("employ-sort.txt");

    FILE *out_fp = fopen("employ-sort.txt", "w");
    if (out_fp == NULL) {
        printf("无法创建 employ-sort.txt！\n");
        return 1;
    }

    printf("排序后的数据结果：\n");
    printf("--------------------\n");
    for (int i = 0; i < n; i++) {
        printf("%s: %d\n", data[i].name, data[i].population);
        fprintf(out_fp, "%s: %d\n", data[i].name, data[i].population);
    }
    printf("--------------------\n");
    fclose(out_fp);
    printf("数据已成功写入 employ-sort.txt (旧文件已被替换)\n\n");

    // 4. 查询功能
    char query[50];
    while (1) {
        printf("请输入要查询的行业名称 (输入 exit 退出): ");
        scanf("%s", query);

        // 退出提示逻辑
        if (strcmp(query, "exit") == 0) {
            printf("\n>>> 您已选择退出查询。程序运行结束，感谢使用！<<<\n");
            break;
        }

        int found = 0;
        for (int i = 0; i < n; i++) {
            if (strcmp(data[i].name, query) == 0) {
                printf("查询到的就业人数: %d\n", data[i].population);
                found = 1;
                break;
            }
        }

        if (!found) {
            printf("查询不成功\n");
        }
    }

    return 0;
}
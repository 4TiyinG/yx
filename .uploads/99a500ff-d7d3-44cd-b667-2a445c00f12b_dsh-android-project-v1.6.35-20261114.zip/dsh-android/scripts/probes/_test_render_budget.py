#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""帧预算调度器护栏（v1.6.30）。

## 这个探针守什么

「资源隔离与预算控制」落到这个进程里，只有三条能被静态守住的不变量：

- **I1 单一调度源**：任何高频帧驱动都不许自己 `postDelayed` 自排下一拍，
  否则它就和别人抢主线程、且永远没有上限。
- **I2 窗口事务有界**：`WindowManager.updateViewLayout` 每次都是一趟 binder
  IPC 进 system_server。它的调用次数必须与**刷新率**同阶，不能与**触摸采样率**
  同阶（后者通常是前者的 2~4 倍）。
- **I3 生命周期收尾**：调度器订阅必须随窗口/服务消失而撤销，否则窗口没了
  还在发事务（被 runCatching 吞掉，白烧 CPU 且极难查）。

## 校验方式（两层，各自证明什么必须说清）

1. **结构断言**：读源码确认上面三条有代码守着（订阅/撤销成对、旧写法已移除、
   预算与优先级存在、空订阅时停摆）。
2. **调度算术复刻**：Kotlin 跑不了，所以把 `RenderBudget` 的排帧算术
   （间隔判定 + 每帧预算 + 每帧合并）按源码复刻成 Python，喂 60Hz 帧时钟 /
   240Hz 触摸事件，算出**每秒窗口事务数**与**单帧最大事务数**的前后对比。
   这是**模型数值，不是真机测量**：它证明的是「调用次数被压到刷新率同阶」，
   不证明真机帧时间改善多少（那需要 dumpsys gfxinfo）。

跑法：python3 scripts/probes/_test_render_budget.py
"""

import io
import math
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")

RB = os.path.join(JAVA, "ui/RenderBudget.kt")
PET = os.path.join(JAVA, "pet/PetOverlayService.kt")
STATUS = os.path.join(JAVA, "StatusOverlay.kt")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(path):
    return io.open(path, encoding="utf-8").read()


def code_only(src):
    """去掉注释再查「旧写法残留」——否则注释里写的「原来是 postDelayed(this, 16)」
    会被自己的守则判成违规。"""
    src = re.sub(r"/\*[\s\S]*?\*/", "", src)
    src = re.sub(r"(?m)^\s*//.*$", "", src)
    src = re.sub(r"//[^\n\"]*$", "", src, flags=re.M)
    return src


rb = read(RB)
pet = read(PET)
status = read(STATUS)

# ── 1. 单一调度源 ────────────────────────────────────────────────────
check("只有一个 Choreographer 调度入口",
      rb.count("postFrameCallback") == 1, "多条帧回调 = 又变成多个调度源")
check("订阅表是 id 键控的（同 id 重复注册只更新，不叠加）",
      "subs[id] = Sub(" in rb and "val existing = subs[id]" in rb)
check("订阅表为空时不排任何 wakeup",
      "if (subs.isEmpty() && onceActions.isEmpty()) return" in rb
      or "subs.isEmpty() && onceActions.isEmpty()" in rb)
check("没有订阅者时立刻取消待发唤醒", "cancelPendingWake()" in rb)
check("分发顺序按 (优先级, 注册序) 稳定排序",
      "sortedWith(compareBy({ it.priority }, { it.seq }))" in rb)
check("优先级常量齐备", all(k in rb for k in ("const val HIGH", "const val NORMAL", "const val LOW")))

# ── 2. 每帧预算 ─────────────────────────────────────────────────────
check("有每帧主线程预算", "budgetMs" in rb and "DEFAULT_BUDGET_MS" in rb)
check("超预算只顺延、不丢弃（deferred 计数而非丢弃）",
      "deferred++" in rb and "continue" in rb)
check("HIGH 优先级不受预算限制", "sub.priority != HIGH" in rb)
check("预算值被钳制在合理区间", "coerceIn(0.5, 16.0)" in rb)
check("单帧分发耗时是实测的（nanoTime），不是估算",
      "System.nanoTime() - startedNs" in rb)

# ── 3. 卡顿自适应 ───────────────────────────────────────────────────
check("跟踪帧间隔 EMA", "intervalEmaMs = intervalEmaMs * 0.9 + dtMs * 0.1" in rb)
check("连续卡顿进入降频态", "JANK_STREAK_TO_DEGRADE" in rb and "degraded = true" in rb)
check("连续顺畅退出降频态", "SMOOTH_STREAK_TO_RECOVER" in rb and "degraded = false" in rb)
check("降频只作用于 LOW（主运动不被降频）", "sub.priority != LOW" in rb)

# ── 4. 保活回退（息屏/doze 下不改变旧语义）──────────────────────────
check("有保活定时器", "keepAlive" in rb and "KEEPALIVE_MS" in rb)
check("帧到达即撤掉保活（否则白发一次分发）",
      re.search(r"doFrame[\s\S]{0,400}removeCallbacks\(keepAlive\)", rb) is not None)

# ── 5. 每帧合并（postOnce）───────────────────────────────────────────
check("postOnce 存在且后写覆盖先写",
      "fun postOnce" in rb and "onceActions[id] = action" in rb)
check("postOnce 动作每帧只取走一次", "onceActions.clear()" in rb)
check("postOnce 超预算也顺延不丢", "onceActions[id] = action" in rb)
check("postOnce 可撤销", "fun cancelOnce" in rb)

# ── 6. 宠物窗口：拖拽合帧 + 甩抛入预算 ───────────────────────────────
check("拖拽走 postOnce 合帧", "RenderBudget.postOnce(DRAG_APPLY)" in pet)
check("拖拽不再逐事件发窗口事务",
      "runCatching { w.updateViewLayout(view, p) }"
      not in code_only(pet.split("view.onDragMove")[1].split("view.onDragEnd")[0]))
check("松手前把挂起那帧落地（不停在旧坐标）",
      "RenderBudget.cancelOnce(DRAG_APPLY)" in pet and "applyDragFrame()" in pet)
check("甩抛交给调度器（16ms，物理步长不变）",
      "RenderBudget.schedule(FLING_TICK, RenderBudget.NORMAL, MOVE_TICK_MS)" in pet)
check("甩抛不再自己 postDelayed(16)",
      code_only(pet).count("handler.postDelayed(this, 16L)") == 0)
check("停止甩抛时撤销订阅", "RenderBudget.cancel(FLING_TICK)" in pet.split("private fun stopFling")[1][:200])
check("服务销毁时撤销全部订阅",
      "RenderBudget.cancelOnce(DRAG_APPLY)" in pet.split("override fun onDestroy")[1][:300])

# ── 7. 状态悬浮窗：拖拽合帧 + 吸附对齐 vsync ────────────────────────
check("状态窗拖拽走 postOnce 合帧", "RenderBudget.postOnce(SNAP_DRAG)" in status)
check("状态窗拖拽不再逐事件发窗口事务",
      "updateViewLayout(root ?: target, p)" not in code_only(status))
check("吸附动画交给调度器", "RenderBudget.schedule(SNAP_ANIM" in status)
check("吸附动画不再 postDelayed(16)", "handler.postDelayed(this, 16)" not in code_only(status))
check("动画走完撤销订阅", "if (i >= steps) RenderBudget.cancel(SNAP_ANIM)" in status)
check("窗口移除时撤销动画与挂起事务",
      "RenderBudget.cancel(SNAP_ANIM)" in status.split("fun hide")[1][:400])

# ── 8. 旧写法残留检查（这两条路径不该再有自排帧）────────────────────
for f, path in (("pet", PET), ("status", STATUS)):
    src = code_only(read(path))
    leftover = re.findall(r"postDelayed\(\s*this\s*,\s*16", src)
    check("%s: 无 16ms 自排帧残留" % f, not leftover, "残留 %d 处" % len(leftover))

# ── 9. 调度算术复刻（模型，非真机）────────────────────────────────────

FRAME_MS = 1000.0 / 60.0      # 60Hz 显示
TOUCH_MS = 1000.0 / 240.0     # 240Hz 触摸采样
SECONDS = 1.0


def timeline_before():
    """改动前的调用次数：每源各自 postDelayed 自排，拖拽逐事件立即发事务。"""
    frames = int(SECONDS * 60)
    per_frame = [0] * frames

    # 拖拽：每个触摸事件 2 次事务（宠物窗口 + 气泡跟随），不经过任何合帧
    touch_count = int(SECONDS * 240)
    for k in range(touch_count):
        t = k * TOUCH_MS
        f = int(t / FRAME_MS)
        if f < frames:
            per_frame[f] += 2

    # 甩抛：postDelayed(16) 自排，与 16.667ms 帧不同步 → 部分帧撞两次
    t = 0.0
    ticks = 0
    while t < SECONDS * 1000:
        f = int(t / FRAME_MS)
        if f < frames:
            per_frame[f] += 1
        ticks += 1
        t += 16.0

    # 漫游：32ms 自排（空闲时才跑，这里按同时存在算，取最坏情形）
    t = 0.0
    while t < SECONDS * 1000:
        f = int(t / FRAME_MS)
        if f < frames:
            per_frame[f] += 1
        t += 32.0

    return per_frame, ticks


def timeline_after():
    """改动后：单一调度源 + 每帧合并 + 预算顺延。"""
    frames = int(SECONDS * 60)
    per_frame = [0] * frames

    # 拖拽：同一帧内多次请求合并成 1 次
    touch_count = int(SECONDS * 240)
    touched_frames = set()
    for k in range(touch_count):
        touched_frames.add(int((k * TOUCH_MS) / FRAME_MS))
    for f in touched_frames:
        if f < frames:
            per_frame[f] += 1

    # 甩抛：按 vsync 排 → 每帧最多 1 次（16ms 间隔在 60Hz 下等价于每帧）
    for f in range(frames):
        per_frame[f] += 1

    # 漫游：32ms → 每 2 帧 1 次
    for f in range(0, frames, 2):
        per_frame[f] += 1

    return per_frame


before, before_ticks = timeline_before()
after = timeline_after()

sum_before, sum_after = sum(before), sum(after)
peak_before, peak_after = max(before), max(after)

check("模型：每秒窗口事务数下降", sum_after < sum_before,
      "before=%d after=%d" % (sum_before, sum_after))
check("模型：单帧峰值事务数下降", peak_after < peak_before,
      "before=%d after=%d" % (peak_before, peak_after))
check("模型：峰值被压到刷新率同阶（≤4/帧）", peak_after <= 4,
      "peak_after=%d" % peak_after)
check("模型：没有一帧是空的（动画不因合并而停摆）", min(after) > 0)

# 预算算术：每帧 5ms、单个订阅 2ms → 一帧最多跑 3 个，剩下的顺延
BUDGET_NORMAL = 3


def budget_dispatch(n_subs, cost_ms, budget_ms=5.0):
    """复刻 dispatch() 的预算判定：spent > budget 且非 HIGH → 顺延。"""
    order = list(range(n_subs))
    ran = 0
    spent = 0.0
    for _ in order:
        if spent > budget_ms:
            break
        ran += 1
        spent += cost_ms
    return ran


check("预算算术：5ms 预算下 2ms/订阅 → 单帧最多 3 个",
      budget_dispatch(8, 2.0) == BUDGET_NORMAL, "got %d" % budget_dispatch(8, 2.0))
check("预算算术：订阅很少时全部跑完",
      budget_dispatch(2, 2.0) == 2)
check("预算算术：零成本订阅不被预算挡住",
      budget_dispatch(50, 0.0) == 50)

# 间隔算术：卡顿降频把 LOW 的间隔翻倍（等效调用次数减半）
def calls_per_sec(interval_ms, degraded, priority):
    if degraded and priority == "LOW":
        interval_ms *= 2
    return 1000.0 / interval_ms


check("降频算术：LOW 间隔翻倍 → 调用次数减半",
      abs(calls_per_sec(32, True, "LOW") - calls_per_sec(32, False, "LOW") / 2) < 1e-9)
check("降频算术：NORMAL 不受降频影响",
      calls_per_sec(16, True, "NORMAL") == calls_per_sec(16, False, "NORMAL"))

# ── 报告 ────────────────────────────────────────────────────────────
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))

print()
print("模型结果（60Hz 帧 / 240Hz 触摸 / 1 秒，仅算术复刻，非真机）")
print("  窗口事务/秒 : %d -> %d  (-%.0f%%)" % (
    sum_before, sum_after, (1 - sum_after / max(sum_before, 1)) * 100))
print("  单帧峰值    : %d -> %d  (-%.0f%%)" % (
    peak_before, peak_after, (1 - peak_after / max(peak_before, 1)) * 100))
print("  甩抛自排拍数: %d/秒 (与帧不同步)" % before_ticks)
print()
failed = [n for n, ok, _ in checks if not ok]
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All render-budget checks passed.")

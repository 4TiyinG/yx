#!/usr/bin/env node
/*
 * 热降级脚本的行为自检（v1.6.35）。
 *
 * 为什么用行为测试而不是只做语法检查：`thermal-degrade.js` 的关键语义都是
 * 「状态机不变量」，语法正确但语义错了照样能跑，而且很难在真机上看出来：
 *
 *   1. `set()` 必须幂等（原生侧会重复推：导航重注入、onResume 补推）；
 *   2. WARM 档**不得**降帧（需求：温升初期保持帧率，只削效果）；
 *   3. 回到 NORMAL 必须把 canvas 分辨率**复原**（否则降级=永久掉画质）；
 *   4. 根 class 必须随档位切换（CSS 全靠它选中）。
 *
 * 跑法：node scripts/probes/_test_thermal_js.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(HERE, '..', '..', 'app/src/main/assets/js/thermal-degrade.js');

let failed = 0;
function ok(name, cond, detail = '') {
  if (cond) {
    console.log('  ok    ' + name);
  } else {
    console.log('  FAIL  ' + name + (detail ? '  -> ' + detail : ''));
    failed++;
  }
}

// ── 最小 DOM 桩 ────────────────────────────────────────────────────────────
const created = [];
function mkEl(tag) {
  const el = {
    tagName: tag.toUpperCase(),
    style: {},
    classList: {
      _s: new Set(),
      add(c) { this._s.add(c); },
      remove(c) { this._s.delete(c); },
      contains(c) { return this._s.has(c); },
    },
    attributes: {},
    textContent: '',
    children: [],
    setAttribute(k, v) { this.attributes[k] = v; },
    hasAttribute(k) { return k in this.attributes; },
    appendChild(c) { this.children.push(c); },
    getBoundingClientRect() { return { width: 200, height: 100 }; },
    addEventListener() {},
    play() { return Promise.resolve(); },
    pause() {},
  };
  created.push(el);
  return el;
}

const canvas = mkEl('canvas');
canvas.width = 200;
canvas.height = 100;
canvas.style.width = '200px';
canvas.style.height = '100px';

const docEl = mkEl('html');
const realConsole = console;
globalThis.console = {
  info() {},
  warn() {},
  log: (...a) => realConsole.log(...a),
};
globalThis.performance = { now: () => Date.now() };
globalThis.requestAnimationFrame = () => 1;
globalThis.cancelAnimationFrame = () => {};
globalThis.IntersectionObserver = function () {
  this.observe = () => {};
  this.disconnect = () => {};
};
globalThis.document = {
  documentElement: docEl,
  head: mkEl('head'),
  getElementById() { return null; },
  createElement: (t) => mkEl(t),
  querySelectorAll: (sel) => (sel === 'canvas' ? [canvas] : []),
};
globalThis.window = {
  document: globalThis.document,
  addEventListener() {},
};

// 执行被测脚本（它是 IIFE，直接 eval 等价于 <script>）
eval(fs.readFileSync(SRC, 'utf8'));

const api = globalThis.window.__dshThermal;
ok('exposes window.__dshThermal', !!api);
ok('has set/get/critical', api && typeof api.set === 'function' &&
  typeof api.get === 'function' && typeof api.critical === 'function');
if (!api) {
  realConsole.log('\nFAILED: API missing');
  process.exit(1);
}

// ── 1. 幂等 ────────────────────────────────────────────────────────────────
// TIGHT 的实际位集：NO_BACKDROP|LIGHT_SHADOW|NO_PARTICLES|PAUSE_OFFSCREEN|NO_NONCORE_ANIM = 31
const a = api.set(2, 0b11111, 45);
const b = api.set(2, 0b11111, 45);
ok('set() is idempotent', a.level === 2 && b.level === 2);
ok('root class follows the level', docEl.classList.contains('dsh-th-2'));
ok('no stale root class left behind', !docEl.classList.contains('dsh-th-0'));

// ── 2. WARM 档保持帧率 ─────────────────────────────────────────────────────
api.set(1, 0b10011, 60);
ok('WARM keeps the frame rate (fps forced to 0)', api.get().fps === 0,
  'actual=' + api.get().fps);

// ── 3. canvas 降采样与复原 ─────────────────────────────────────────────────
api.set(3, 0b111111, 30);
ok('SEVERE lowers the canvas backing store', canvas.width === 130, 'w=' + canvas.width);
ok('visual size (style) is untouched', canvas.style.width === '200px',
  'style=' + canvas.style.width);
api.set(0, 0, 0);
ok('NORMAL restores the canvas backing store', canvas.width === 200, 'w=' + canvas.width);
ok('NORMAL clears the frame cap', api.get().fps === 0);

// ── 4. CSS 真的写入了 ──────────────────────────────────────────────────────
api.set(2, 0b11111, 45);
const styleEl = created.find((e) => e.tagName === 'STYLE' && e.id === '__dsh_thermal_style');
ok('injects a style node with backdrop-filter kill',
  !!styleEl && styleEl.textContent.includes('backdrop-filter'),
  'backdrop-filter rule missing');
ok('offscreen pause rule present', !!styleEl && styleEl.textContent.includes('dsh-th-off'));

// ── 5. 视图清理路径不抛错 ──────────────────────────────────────────────────
let threw = false;
try {
  api.set(0, 0, 0);
  api.set(3, 0b111111, 30);
  api.set(1, 0b10011, 60);
} catch (e) {
  threw = true;
}
ok('level round-trips without throwing', !threw);

console.log();
if (failed) {
  console.log('FAILED: ' + failed + ' check(s)');
  process.exit(1);
}
console.log('All thermal-JS behaviour checks passed.');

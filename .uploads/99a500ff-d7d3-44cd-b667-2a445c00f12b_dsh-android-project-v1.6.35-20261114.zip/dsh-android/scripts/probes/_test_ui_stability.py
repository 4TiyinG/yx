#!/usr/bin/env python3
"""界面稳定度探针 —— 用可计算的模型量化「UI 线程每帧/每次交互的工作量」。

为什么是模型而不是实测
----------------------
本机没有设备/模拟器，帧时间测不了。但界面不稳定的大多数成因不是玄学，
而是**工作量随数据量无界增长**或**同一份昂贵工作被重复做 N 次**：

  · 一次交互同步插入 O(N) 个 View       → 帧时间随会话数线性增长
  · 每次回到界面重复解码 O(像素) 字节    → GC 尖峰 + 首帧延后
  · 列表刷新 removeAllViews + 全量重建    → 布局树整体失效一次

这些都能从源码里算出上界。探针守的就是三条不变量：

  I1  单帧 UI 工作量有**常数上界**（与列表长度 N 无关）
  I2  重复进入同一界面时，图片解码次数为 **0**（缓存命中）
  I3  列表刷新不销毁重建既有 View

跑法：python3 scripts/probes/_test_ui_stability.py
退出码 0 = 三条全部满足。
"""
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
WIPE = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile/WipeChatsActivity.kt")
MAIN = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile/MainActivity.kt")
DOT = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile/IslandDotRenderer.kt")
VIS = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile/CustomVisualPref.kt")


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


fails = []


def check(name, ok, detail=""):
    print(("  PASS  " if ok else "  FAIL  ") + name + (("   " + detail) if detail else ""))
    if not ok:
        fails.append(name)


wipe = read(WIPE)
main = read(MAIN)
dot = read(DOT)
vis = read(VIS)

# ─────────────────────────────────────────────────────────────────────────
# I1：单帧 UI 工作量必须有常数上界
#
# 每行 View 数（实测 buildRow）：row + checkbox + title + [location] + sub
# 加上行间 divider → 约 5–6 个/行。旧实现一次性 addView 全部行，
# 所以单帧工作量 = 5.5N。N=200 时约 1100 个 View 在一次 traversal 里
# 同时 measure/layout，且 column 带 layout_weight=1f（LinearLayout 会
# 二次测量每个子项）→ 实际约 2200 次 measure。
# ─────────────────────────────────────────────────────────────────────────
print("\n[I1] 单帧 UI 工作量上界")

VIEWS_PER_ROW = 5.5          # row + checkbox + title + location + sub，+divider 摊薄
N_HEAVY = 200                # 重度用户的会话数

# 旧写法：render() 里直接 snap.items.forEach { addView(buildRow(...)) }
sync_full_render = re.search(
    r"fun render\([\s\S]{0,600}?snap\.items\.forEachIndexed", wipe) is not None
check("render() 不再一次性同步插入全部行", not sync_full_render,
      "若失败：单帧 %d 个 View" % int(VIEWS_PER_ROW * N_HEAVY))

# 新写法：分帧构建。必须有 chunk 常量 + 帧回调续做
chunk = re.search(r"ROW_CHUNK\s*=\s*(\d+)", wipe)
check("定义了每帧行数上限 ROW_CHUNK", chunk is not None,
      ("ROW_CHUNK=%s → 单帧 %d 个 View"
       % (chunk.group(1), int(VIEWS_PER_ROW * int(chunk.group(1))))) if chunk else "")
check("用帧回调分帧续做（postOnAnimation / post / doOnPreDraw）",
      re.search(r"postOnAnimation|doOnPreDraw|view\.post\(", wipe) is not None)
# 分帧必须能被取消：页面销毁/重新扫描时不能让旧批次继续往 listChats 里塞
check("分帧批次有取消机制", re.search(r"cancel|generation|token|isFinishing", wipe) is not None)

# ─────────────────────────────────────────────────────────────────────────
# I2：重复进入界面时解码次数为 0
#
# IslandDotRenderer.apply() 在 setupHandleBar() 与 **每次 onResume** 都被调用。
# 旧实现每次：decodeFile(216²) → centerSquare(可能新建 Bitmap) → circular(再建一个
# ARGB_8888 + Canvas 描圆)。三次分配、两份全尺寸位图，全是垃圾。
# ─────────────────────────────────────────────────────────────────────────
print("\n[I2] 重复进入界面时图片解码次数")

check("IslandDotRenderer 有解码/渲染缓存",
      re.search(r"LruCache|cache", dot, re.I) is not None,
      "否则每次 onResume 重新解码+描圆")
check("圆点缓存键包含形状（SQUARE/CIRCLE 不能共用一份）",
      re.search(r"shape", dot, re.I) is not None)
check("圆点缓存键包含尺寸", re.search(r"\bsize(Px|Dp)?\b", dot) is not None)

# 状态栏背景图：MainActivity.applyExpandedStatusBar() 每次 onResume 都 decode
bg_decode_inline = "BitmapFactory.decodeFile(it.absolutePath)" in main
check("状态栏背景不再每次 onResume 同步整图解码", not bg_decode_inline,
      "旧写法：%d×H 整图在 UI 线程解码" % 1440)

# 背景图解码必须降到显示尺寸，而不是按原图上限整解码
check("状态栏背景解码带降采样（inSampleSize）",
      "inSampleSize" in main or "decodeSampled" in main or "loadScaled" in main)

# ─────────────────────────────────────────────────────────────────────────
# I3：刷新不销毁重建
# ─────────────────────────────────────────────────────────────────────────
print("\n[I3] 列表刷新是否销毁重建既有 View")

check("贴纸不再 removeViewAt + addView 全量重建",
      not re.search(r"overlay\.removeViewAt", main),
      "旧写法：每次 onResume 全部贴纸 View 重建")

# 允许 removeAllViews 只在「会话集合真的变了」时发生（删除后重扫），
# 但不能出现在普通刷新路径上。这里只要求它不出现在分帧追加路径里。
check("分帧追加走 addView，不先 removeAllViews",
      "removeAllViews" not in wipe.split("fun appendChunk")[-1] if "fun appendChunk" in wipe else True)

# ─────────────────────────────────────────────────────────────────────────
# 量化对比
# ─────────────────────────────────────────────────────────────────────────
print("\n[量化对比]")
chunk_n = int(chunk.group(1)) if chunk else 0
print("  单帧 View 数（N=%d 会话）" % N_HEAVY)
print("    修复前：%6d  （全部一次性插入）" % int(VIEWS_PER_ROW * N_HEAVY))
print("    修复后：%6d  （每帧上限 ROW_CHUNK=%d）" % (int(VIEWS_PER_ROW * chunk_n), chunk_n))

# 圆点：216×216 文件 → 原图 + centerSquare + circular
P = 216
per_call_bytes = P * P * 4 * 2      # 方形 + 圆形两份 ARGB_8888（非方形素材还要多一份）
print("  每次进入主界面，圆点位图分配")
print("    修复前：%7d B × 每次 onResume（无缓存，从不 recycle）" % per_call_bytes)
print("    修复后：%7d B × 首次（之后命中，0 B）" % per_call_bytes)

# 背景图：1440 宽，按 4:3 与 9:16 两种典型比例
for label, h in (("1440×1080", 1080), ("1440×2560", 2560)):
    print("  状态栏背景 %s 解码：%5.1f MB / 每次 onResume" % (label, 1440 * h * 4 / 1024 / 1024))

print()
if fails:
    print("%d 项未满足：" % len(fails))
    for f in fails:
        print("  · " + f)
    sys.exit(1)
print("全部满足：单帧有界、解码命中缓存、刷新不重建。")

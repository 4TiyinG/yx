#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""插件加载优先级护栏（v1.6.29）：已装的 dsh-web-mobile 排最前、首轮就绪。

## 为什么要有这个探针

这条优化的全部效果都落在「写 profile 的 package.json」这一件事上。它有几个特别
容易悄悄坏掉的地方：

1. **改了不该改的**：`bundles` 不只是加载顺序，还是「哪些插件存在」的权威清单。
   写坏一次就是把用户的插件弄丢一次，引擎直接起不来。
2. **在引擎运行期改**：`package.json` 的写入会被引擎退出时的内存写回吞掉
   （`ProfilePluginProvisioner` / `PluginKillSwitch` 都有同一条注释），改了等于没改。
3. **没装也照改**：往列表里塞一个不存在的包，引擎解析失败。
4. **`dsh-web-mobile-fix` 误命中**：它名字以 `dsh-web-mobile` 开头，是**另一个**插件。

## 校验方式（两层）

- **结构断言**：读 Kotlin 源码确认这些不变量有代码守着，且调用点在
  「engine 已停、spawn 之前」。
- **等价实现交叉验证**：Kotlin 在 Python 里跑不了，所以把重排算法按源码逐行
  复刻成 Python，用真实形态的 fixtures 跑。它证明的是**算法性质**（换序不增删、
  幂等、目标匹配规则），不是 Kotlin 那段字节码 —— 这点必须说清。

跑法：python3 scripts/probes/_test_plugin_priority.py
"""

import io
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")
PRIO = os.path.join(JAVA, "engine/PluginPriority.kt")
FASTBOOT = os.path.join(JAVA, "engine/PluginFastBoot.kt")
SUP = os.path.join(JAVA, "engine/EngineSupervisor.kt")
SETTINGS = os.path.join(JAVA, "SettingsActivity.kt")
SPLASH = os.path.join(JAVA, "ui/SplashController.kt")
LAYOUT = os.path.join(ROOT, "app/src/main/res/layout/activity_settings.xml")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(path):
    return io.open(path, encoding="utf-8").read()


prio = read(PRIO)
fastboot = read(FASTBOOT)
sup = read(SUP)

# ── 1. 目标识别 ──────────────────────────────────────────────────────
check("target name is dsh-web-mobile", 'const val TARGET = "dsh-web-mobile"' in prio)
check("scoped spelling accepted", 'name.endsWith("/$TARGET")' in prio)
_is_target_body = prio.split("fun isTarget(name: String): Boolean =")[1].split("\n\n")[0]
check("matching is exact or /-scoped only (no prefix match)",
      'name == TARGET || name.endsWith("/$TARGET")' in _is_target_body
      and "startsWith" not in _is_target_body,
      "startsWith 会命中同前缀的另一个插件 dsh-web-mobile-fix")

# ── 2. 「没装就跳过」的三道判据 ──────────────────────────────────────
check("skips when not present in bundles AND not on disk", '"not-installed"' in prio)
# v1.6.33：“默认认为已安装”——目录看不到不再阻止重排，但必须记日志
check("missing package dir no longer blocks the reorder (v1.6.33)",
      '"stale-entry"' not in prio and "assumed-installed" in prio)
check("a listed-but-invisible bundle is still promoted",
      "promoting anyway (assumed-installed)" in prio)
check("bundles miss + install on disk → enabled and promoted",
      'discoverInstalled(ctx)' in prio and '"enabled-and-promoted"' in prio)
check("discovery validates package.json before touching the manifest",
      'File(dir, "package.json")' in prio and 'optString("name")' in prio,
      "只凭目录存在就写入会让引擎解析失败")
check("discovery only accepts the exact target name",
      "if (!isTarget(real)) continue" in prio)
check("resolvability checks all three node_modules roots",
      all(p in prio for p in ('"profiles/web/node_modules"', '"profiles/node_modules"', '"lib/node_modules"')))
check("no-profile / bad-json / no-bundles all degrade quietly",
      all(p in prio for p in ('"no-profile"', '"bad-json"', '"no-bundles"', '"no-profile-section"')))
check("never throws out of applyBeforeBoot", "runCatching {\n        applyInternal(ctx)" in prio)

# ── 3. 写盘安全 ─────────────────────────────────────────────────────
check("refuses any change that adds/removes a bundle",
      "reordered.toSet() != names.toSet()" in prio and '"refused"' in prio)
check("writes atomically (tmp + fsync + rename)",
      "out.fd.sync()" in prio and "renameTo(file)" in prio)
check("only dsh.profile.bundles is rewritten", 'put("bundles", arr)' in prio)
check("idempotent when already in place", 'reordered == names' in prio and '"unchanged"' in prio)
check("records the original order once for manual inspection",
      'RECORD' in prio and '"originalOrder"' in prio and "if (rec.isFile) return@runCatching" in prio)
check("disabled means demote to tail, never a destructive restore",
      "reordered.add(name)" in prio and '"demoted"' in prio)

# ── 4. 调用点：engine 已停、spawn 之前 ───────────────────────────────
i_provision = sup.find("ProfilePluginProvisioner.ensureAll(ctx)")
i_prio = sup.find("PluginPriority.applyBeforeBoot(ctx)")
i_hold = sup.find("PluginFastBoot.hold(ctx)")
i_spawn = sup.find("spawnEngine(bootId)")
check("priority runs after the profile provisioner", 0 < i_provision < i_prio)
check("priority runs before fast-boot hold (so the backup carries the order)", 0 < i_prio < i_hold)
check("priority runs before spawn (engine is not running)", 0 < i_prio < i_spawn)
check("priority pass is off the main thread",
      "PluginPriority.applyBeforeBoot(ctx)" in sup
      and sup.split("PluginPriority.applyBeforeBoot(ctx)")[0].rsplit("withContext(Dispatchers.IO)", 1)[-1]
      .count("\n") < 12,
      "v1.6.34 起与 consumeSkipNext 合并在同一个 IO 区块里")
check("boot trace has a stage for it",
      'mark("plugin-priority")' in sup and 'step("plugin-priority")' in sup)
check("splash translates the new stage", '"plugin-priority" -> R.string.boot_step_plugin_priority' in read(SPLASH))

# ── 5. 快速启动：一律推迟（v1.6.32），但队列首位仍是优先插件 ──────────
#
# v1.6.29 曾让优先插件「豁免推迟」，随引擎首轮加载。用户实测这个豁免把 WebUI
# 首屏拖慢了（引擎要等它解析/求值完才进 Healthy），v1.6.32 已撤销。
# 这里锁的是**新**不变量：它和其他第三方一样被推迟，只靠 bundles 顺序守住队列首位。
check("fast boot no longer exempts the priority plugin (v1.6.32)",
      "keptPriority" not in fastboot and "name == priorityName" not in fastboot)
check("fast boot does not consult the priority switch at all",
      "priorityName" not in fastboot)
check("fast boot defers every third-party bundle by dep + namespace test",
      'deps.has(name) && !name.startsWith("@deepseek-ai/")' in fastboot)
check("fast boot holds whenever any third-party bundle exists",
      "if (removed == 0) return false" in fastboot)
check("fast boot no longer skips itself for small payloads",
      "fast boot skipped" not in fastboot and "decide(ctx)" not in fastboot,
      "v1.6.34 起 decide() 完全离开启动路径（移到预热协程），small 不再决定是否解耦")
check("fast boot logs the background queue head", "keepOrderHint" in fastboot)
check("hold is still gated by the fast-boot switch itself",
      "if (!enabled(ctx)) return false" in fastboot)

# ── 6. 设置开关 ──────────────────────────────────────────────────────
layout = read(LAYOUT)
check("settings has a switch for it", 'android:id="@+id/swPluginPriority"' in layout)
check("settings row is wired", "PluginPriority.setEnabled(this, on)" in read(SETTINGS))
check("toggling restarts the engine so it applies",
      "PluginPriority.setEnabled(this, on)" in read(SETTINGS)
      and "supervisor.restart()" in read(SETTINGS).split("PluginPriority.setEnabled")[1][:400])
for loc in ["values", "values-zh-rCN", "values-de", "values-pt-rBR", "values-th"]:
    txt = read(os.path.join(ROOT, "app/src/main/res/%s/strings.xml" % loc))
    check("%s has all three strings" % loc,
          all('name="%s"' % k in txt for k in
              ("plugin_priority_title", "plugin_priority_sub", "plugin_priority_changed")))
    check("%s has the boot stage label" % loc, 'name="boot_step_plugin_priority"' in txt)

# ── 7. 等价实现交叉验证（算法性质，不是 Kotlin 字节码）────────────────

TARGET = "dsh-web-mobile"


def is_target(name):
    return name == TARGET or name.endswith("/" + TARGET)


def reorder(names, enabled):
    """PluginPriority.applyInternal 的重排部分，逐行复刻。"""
    index = next((i for i, n in enumerate(names) if is_target(n)), -1)
    if index < 0:
        return names, False, -1
    reordered = list(names)
    name = reordered.pop(index)
    if enabled:
        reordered.insert(0, name)
    else:
        reordered.append(name)
    if reordered == names:
        return names, False, index
    if len(reordered) != len(names) or set(reordered) != set(names):
        raise AssertionError("multiset changed")
    return reordered, True, reordered.index(name)


BUILTIN = ["@deepseek-ai/dsh-typert-registry", "@deepseek-ai/dsh-client-ui-layout"]
fixtures = {
    "installed among builtins": (BUILTIN + [TARGET, "dsh-mobile-layout"], True),
    "scoped name": (BUILTIN + ["@acme/dsh-web-mobile"], True),
    "already first": ([TARGET] + BUILTIN, True),
    "not installed": (BUILTIN + ["dsh-mobile-layout"], True),
    "only the -fix variant": (BUILTIN + ["dsh-web-mobile-fix"], True),
    "both variants": (BUILTIN + ["dsh-web-mobile-fix", TARGET], True),
    "disabled": (BUILTIN + [TARGET, "x"], False),
}

for label, (names, on) in fixtures.items():
    out, changed, idx = reorder(names, on)
    if is_target(TARGET) and any(is_target(n) for n in names):
        target_in = next(n for n in names if is_target(n))
        check("%s: target is #0 when enabled" % label,
              (out[0] == target_in) if on else (out[-1] == target_in))
        check("%s: every other bundle survives" % label, set(out) == set(names))
    else:
        check("%s: untouched (nothing to prioritise)" % label, out == names and not changed)

# 相对顺序：其余插件之间不许被打乱
names = BUILTIN + [TARGET, "a", "b"]
out, _, _ = reorder(names, True)
check("relative order of the other bundles is preserved",
      out == [TARGET] + BUILTIN + ["a", "b"])

# 幂等：连续两次结果一致，且第二次不再写盘
once, changed1, _ = reorder(names, True)
twice, changed2, _ = reorder(once, True)
check("second pass is a no-op (no write)", once == twice and changed1 and not changed2)

# -fix 必须保持它与其它插件的相对位置（它是另一个插件，不参与重排）
names = BUILTIN + ["dsh-web-mobile-fix", TARGET]
out, _, _ = reorder(names, True)
check("the -fix variant keeps its relative position",
      [n for n in out if n != TARGET] == [n for n in names if n != TARGET])

# 空列表 / 单元素
check("empty bundle list is safe", reorder([], True) == ([], False, -1))
check("single-entry list is safe", reorder([TARGET], True) == ([TARGET], False, 0))

# ── 7. 优先通道：真的比别人“先加载完”（v1.6.33）───────────────────────
#
# 只在 bundles 里排第一是**顺序**保证，不是**时间**保证：引擎若并发挂载 entry，
# 排第一的插件仍会和其余插件抢 CPU/IO。所以要锁住两件事：
#   a) 两阶段释放——先把优先插件单独放回去，隔一段头段再放全部；
#   b) 预读优先通道——它单独先跑且上限更宽。
check("two-stage release exists", "fun releasePriorityOnly(" in fastboot)
check("priority stage filters the backup, never invents entries",
      "PluginPriority.listedName(backup)" in fastboot and "staged.put(name)" in fastboot)
check("priority stage keeps the backup for the full restore",
      "backup.delete()" not in fastboot.split("fun releasePriorityOnly")[1].split("fun rollback")[0])
check("priority stage defers every other third-party bundle",
      "thirdParty && name != priority" in fastboot)
check("supervisor runs the priority stage before the full release",
      0 < sup.find("PluginFastBoot.releasePriorityOnly(ctx)") < sup.find("PluginFastBoot.release(ctx)"))
check("both stages still happen after the first paint",
      0 < sup.find("webUiPainted.await()") < sup.find("PluginFastBoot.releasePriorityOnly(ctx)"))
check("the head start is a named, tunable constant",
      "PRIORITY_HEAD_START_MS" in sup and "delay(PRIORITY_HEAD_START_MS)" in sup)
check("the head start is logged for real-device tuning",
      "priority head start" in sup)

pref = read(os.path.join(JAVA, "engine/PluginPrefetcher.kt"))
check("prefetch warms the queue head separately, before the rest",
      "priority warm" in pref and "val head = names.firstOrNull()" in pref)
check("the head gets a wider budget than ordinary plugins",
      "PRIORITY_MAX_FILES" in pref and "PRIORITY_MAX_BYTES" in pref
      and "maxFiles = PRIORITY_MAX_FILES" in pref)
check("the head warm happens before the ordinary loop",
      0 < pref.find("priority warm") < pref.find("for (index in names.indices)"))
check("total prefetch budget is still capped", "MAX_TOTAL_BYTES - bytes" in pref)

# ── 报告 ────────────────────────────────────────────────────────────
failed = [n for n, ok, _ in checks if not ok]
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))
print()
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All plugin-priority checks passed.")

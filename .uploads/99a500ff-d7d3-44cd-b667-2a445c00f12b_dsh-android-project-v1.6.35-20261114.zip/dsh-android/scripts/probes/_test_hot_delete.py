#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""热删除（免重启删除对话）契约锁 + 行为验证（v1.6.28）。

## 锁的两层

### 第一层：协议两侧必须一致（静态）
Kotlin 侧 `HotSessionAdmin` 与引擎侧 `session-admin.mjs` 靠**文件协议**通信，
任何一侧改名、换前缀、改轮询约定都会让通道静默失效 —— 而静默失效的表现是
「用户点了删除，界面显示成功，其实一条没删」。所以先锁：
  · 目录名、命令/结果文件前缀、`op` 名称两侧一致；
  · 两侧都有超时/有效期，避免残留命令被"补执行"；
  · Android 侧在拿不到答复时返回 null（→ 回退），而不是假装成功。

### 第二层：插件行为（真跑 node）
只查字符串证明不了「删除真的生效」。这里把插件的真实代码 import 进 node，
用**假的引擎服务对象**驱动它，验证 7 条行为不变量：

  H1 普通对象形态的注册表：删掉 id（含归档表）
  H2 Map 形态的注册表：也能删掉（不能"看不见"就假成功）
  H3 形状不认识但 id 还在：必须回报失败（交给 Android 回退重启）
  H4 幂等：本来就不在 → ok
  H5 引擎服务提供白名单方法时，优先走方法而不是直接改内存
  H6 probe 命令回报注册表节点与方法名
  H7 服务缺失时不崩、明确回报失败

跑法：python3 scripts/probes/_test_hot_delete.py
需要 node（工程本身依赖 node 构建引擎，可用性由 _test_* 其它探针一并保证）。
"""

import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")
PLUGIN = os.path.join(ROOT, "app/src/main/assets/android-plugins/session-admin.mjs")
HOT = os.path.join(JAVA, "engine/HotSessionAdmin.kt")
WIPER = os.path.join(JAVA, "engine/ChatWiper.kt")
ACT = os.path.join(JAVA, "WipeChatsActivity.kt")
MAIN = os.path.join(JAVA, "MainActivity.kt")
BUS = os.path.join(JAVA, "ChatChangeBus.kt")
ENGINE_CFG = os.path.join(JAVA, "engine/EngineConfig.kt")

checks = []


def check(name, cond):
    checks.append((name, bool(cond)))


def read(path):
    return io.open(path, encoding="utf-8").read()


# ── 1. 静态：两侧协议一致 ────────────────────────────────────────────

plugin = read(PLUGIN)
hot = read(HOT)
wiper = read(WIPER)
act = read(ACT)

check("plugin exists and is an ESM plugin", 'export { apply, inject, name }' in plugin)
check("plugin never hard-depends on a service", "const inject = [];" in plugin)
check("plugin is registered in the engine overlay", "session-admin.mjs" in read(ENGINE_CFG))
check("plugin is deployed from assets", '"session-admin.mjs",' in read(ENGINE_CFG))

DIR_NAME = ".android-session-admin"
check("directory name identical on both sides", DIR_NAME in plugin and DIR_NAME in hot)
check("command prefix identical", '"cmd-' in hot and "cmd-" in plugin)
check("result prefix identical", '"res-' in hot and "res-" in plugin)
check("op names identical", '"delete"' in hot and '"delete"' in plugin)

check("plugin polls (no push channel needed)", "setInterval(" in plugin and "POLL_MS" in plugin)
check("plugin timer cannot hold the event loop", "unref" in plugin)
check("plugin never throws out of its timer", plugin.count("try {") >= 6)
check("plugin drops stale commands instead of replaying them", "CMD_STALE_MS" in plugin)
check("plugin cleans old result files", "RESULT_KEEP_MS" in plugin)

check("android side times out", "timeoutMs" in hot and "Thread.sleep(POLL_MS)" in hot)
check("android side writes commands atomically", "renameTo" in hot and "fd.sync()" in hot)
check("android side returns null when the channel is mute", "return null" in hot)
check("android side distinguishes probe from delete", "fun probe(" in hot and "fun requestDelete(" in hot)

hot_branch = wiper[wiper.find("val answer = HotSessionAdmin.requestDelete"):
                    wiper.find("fun probeHotChannel(")]
check("hot delete prunes the registry only after the engine confirmed",
      hot_branch.find("if (!answer.ok)") < hot_branch.find("moveToTrash(ctx, set, mode)"))
check("engine-idle delete skips the channel entirely",
      "if (!engineRunning(ctx))" in wiper and "deleteHot" in wiper)
check("hot delete clears the projection cache", "clearProjectionCache(ctx, set)" in wiper)
check("hot delete heals registry invariants", "healRegistry(ctx)" in wiper)
check("hot delete refuses to fake success", "if (!answer.ok)" in wiper)

check("activity prefers the hot path", act.find("ChatWiper.deleteHot") < act.find("stopForMaintenance"))
check("activity announces when it must restart anyway", "wipe_chats_restarting" in act)

# ── 2. WebUI 同步 ───────────────────────────────────────────────────
check("chat-change bus exists", os.path.isfile(BUS) and "MutableSharedFlow" in read(BUS))
check("activity publishes removals", "ChatChangeBus.notifyRemoved" in act)
check("main activity consumes them", "ChatChangeBus.changes.collect" in read(MAIN))
check("web ui sync reloads the page instead of the engine",
      "softReloadWebUi" in read(MAIN) and "supervisor.restart()" not in read(MAIN).split("softReloadWebUi")[1][:800])

# ── 3. 行为：真跑插件 ───────────────────────────────────────────────
HARNESS = r"""
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "hotdel-"));
const mod = await import(process.env.PLUGIN_PATH);

let ok = true;
const ck = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); ok = ok && c; };

async function run(label, services, ids, expectOk) {
  const sub = path.join(dir, "c" + Math.random().toString(36).slice(2));
  process.env.DSH_HOME = sub;
  const dispose = mod.apply({ get: (n) => services[n] });
  const chan = path.join(sub, ".android-session-admin");
  const id = "t" + Math.random().toString(36).slice(2);
  fs.writeFileSync(path.join(chan, `cmd-${id}.json`), JSON.stringify({ id, op: "delete", ids }));
  const deadline = Date.now() + 4000;
  let res = null;
  while (Date.now() < deadline) {
    const p = path.join(chan, `res-${id}.json`);
    if (fs.existsSync(p)) { res = JSON.parse(fs.readFileSync(p, "utf8")); break; }
    await new Promise((r) => setTimeout(r, 50));
  }
  ck(`${label}: answered`, !!res);
  if (res) ck(`${label}: ok=${expectOk} (got ${res.ok}/${res.strategy})`, res.ok === expectOk);
  ck(`${label}: command file consumed`, !fs.existsSync(path.join(chan, `cmd-${id}.json`)));
  if (typeof dispose === "function") dispose();
  return res;
}

const plain = { tables: { workspaces: { w1: { sessionIds: ["a", "bb", "cc"] } } },
                global: { archivedSessionIds: ["bb"], pinnedSessionIds: [] } };
await run("H1 plain-object", { workspaceRegistry: { state: plain } }, ["bb"], true);
ck("H1 workspace list pruned", plain.tables.workspaces.w1.sessionIds.join() === "a,cc");
ck("H1 archive list pruned", plain.global.archivedSessionIds.length === 0);

const mapReg = { tables: { workspaces: new Map([["w1", { sessionIds: ["xx", "yy"] }]]) }, global: {} };
await run("H2 map-state", { workspaceRegistry: { data: mapReg } }, ["xx"], true);
ck("H2 map pruned", mapReg.tables.workspaces.get("w1").sessionIds.join() === "yy");

class Opaque { constructor() { this.blob = { sessionIds: ["zz"] }; } }
const opaque = { tables: { workspaces: { w1: new Opaque() } }, global: {} };
const r3 = await run("H3 unknown-shape", { workspaceRegistry: { state: opaque } }, ["zz"], false);
ck("H3 reports the raw leftover", !!r3 && r3.rawAfter > 0);

await run("H4 idempotent",
  { workspaceRegistry: { state: { tables: { workspaces: { w1: { sessionIds: ["keep"] } } }, global: {} } } },
  ["gone"], true);

let methodCalled = null;
const reg5 = { tables: { workspaces: { w1: { sessionIds: ["pp"] } } }, global: {} };
const svc5 = {
  deleteSession(id) { methodCalled = id; reg5.tables.workspaces.w1.sessionIds = []; },
};
const r5 = await run("H5 service-method", { workspaceRegistry: Object.assign(svc5, { state: reg5 }) }, ["pp"], true);
ck("H5 called the engine method", methodCalled === "pp");
ck("H5 strategy names the method path", !!r5 && String(r5.strategy).startsWith("registry-method"));

{
  const sub = path.join(dir, "probe");
  process.env.DSH_HOME = sub;
  const dispose = mod.apply({
    get: (n) => (n === "workspaceRegistry"
      ? { state: { tables: { workspaces: {} }, global: {} }, save() {} }
      : void 0),
  });
  const chan = path.join(sub, ".android-session-admin");
  fs.writeFileSync(path.join(chan, "cmd-pr.json"), JSON.stringify({ id: "pr", op: "probe" }));
  const deadline = Date.now() + 4000;
  let res = null;
  while (Date.now() < deadline) {
    const p = path.join(chan, "res-pr.json");
    if (fs.existsSync(p)) { res = JSON.parse(fs.readFileSync(p, "utf8")); break; }
    await new Promise((r) => setTimeout(r, 50));
  }
  ck("H6 probe reports registry nodes", !!res && res.registryNodes === 1);
  ck("H6 probe reports service methods",
    !!res && Array.isArray(res.methods?.workspaceRegistry) && res.methods.workspaceRegistry.includes("save"));
  dispose?.();
}

await run("H7 no-services", {}, ["qq"], false);

console.log(ok ? "NODE_OK" : "NODE_FAIL");
process.exit(ok ? 0 : 1);
"""

node = shutil.which("node")
check("node available for behaviour test", node is not None)

if node is not None:
    tmp = tempfile.mkdtemp(prefix="hotdel-")
    try:
        target = os.path.join(tmp, "session-admin.mjs")
        shutil.copyfile(PLUGIN, target)
        script = os.path.join(tmp, "harness.mjs")
        io.open(script, "w", encoding="utf-8").write(HARNESS)
        env = dict(os.environ)
        env["PLUGIN_PATH"] = target
        proc = subprocess.run(
            [node, script], capture_output=True, text=True, env=env, timeout=180,
        )
        out = proc.stdout + proc.stderr
        node_cases = [ln for ln in proc.stdout.splitlines() if ln.startswith(("PASS ", "FAIL "))]
        passed = sum(1 for ln in node_cases if ln.startswith("PASS "))
        failed = [ln for ln in node_cases if ln.startswith("FAIL ")]
        check("plugin behaviour: %d/%d cases pass" % (passed, len(node_cases)),
              len(node_cases) > 0 and not failed and proc.returncode == 0)
        for ln in failed:
            print("    " + ln)
        if proc.returncode != 0 and not failed:
            print("    node harness output tail:")
            for ln in out.splitlines()[-12:]:
                print("      " + ln)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

# ── 报告 ────────────────────────────────────────────────────────────
failed = [n for n, ok in checks if not ok]
for name, ok in checks:
    if not ok:
        print("FAIL  " + name)
print()
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All hot-delete checks passed.")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""启动负载护栏（v1.6.34）。

## 这次守的是什么

用户报的是「引擎拉起严重变慢，且受设备差异与发热降频影响极大，启动卡顿、发烫」。
这类问题很容易在后续迭代里被悄悄改回去（比如有人「顺手」把某个优化挪回启动
路径上、或把自适应参数写死成一个更大的常数）。这个探针把结论钉在代码结构上：

### A. 启动路径上不再有全树遍历
1. `LogJanitor` 剪掉 engine/ 与 node_modules（它们不可能藏日志）；
2. 每个 entry 只做**一次** stat（不再对文件也调 `isSymbolicLink`）；
3. 全量清扫按 `SWEEP_INTERVAL_MS` 节流，窗口内只做根目录浅扫。

### B. 纯为打日志的遍历不许挡在 spawn 前
4. `PluginFastBoot.hold()` 里不再出现 `PluginPrefetcher.decide()`；
5. `decide()` 移到预热协程（首帧之后、后台）。

### C. 轮询不再空转
6. 健康探测走 `BootLoad.healthPollIntervalMs(attempt)`（先密后疏），
   不再固定 `HEALTH_INTERVAL_MS`；
7. token 提取是**增量**的（游标 + 增量正则），不再每次重读 1MB 整段；
8. 插件探针等待先 `markerExists()`（一次 stat）再解析，且退避而不是 50ms 死循环。

### D. 与启动无关的固定开销搬走 / 上闸门
9. 孤儿扫描在端口空闲时进后台线程（`orphan-reap-bg`）；
10. 扩展 gradle 迁移移到 spawn 之后（`startBackgroundMigration`）；
11. overlay + 10 个插件文件按 APK 指纹闸门跳过（`.android-overlay.stamp`）；
12. Termux shebang 自愈按运行时标记跳过（`.shebang-healed`）。

### E. 参数按设备自适应（低端机/降频）
13. `BootLoad` 用**核数 + isLowRamDevice** 判定受限，并提供轮询间隔、预读并发、
    libuv 线程池三个出口；
14. `UV_THREADPOOL_SIZE` 不再写死 8，改为按核数 2..4。

跑法：python3 scripts/probes/_test_startup_load.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")

MAIN = os.path.join(JAVA, "MainActivity.kt")
SUP = os.path.join(JAVA, "engine/EngineSupervisor.kt")
CFG = os.path.join(JAVA, "engine/EngineConfig.kt")
JANITOR = os.path.join(JAVA, "engine/LogJanitor.kt")
LOAD = os.path.join(JAVA, "engine/BootLoad.kt")
ORPHAN = os.path.join(JAVA, "engine/OrphanReaper.kt")
FASTBOOT = os.path.join(JAVA, "engine/PluginFastBoot.kt")
PREFETCH = os.path.join(JAVA, "engine/PluginPrefetcher.kt")
RECOVERY = os.path.join(JAVA, "engine/PluginRecovery.kt")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(p):
    return io.open(p, encoding="utf-8").read()


def code_only(text):
    """去掉注释，只对可执行代码做断言（注释里会提到旧实现）。"""
    out = []
    in_block = False
    for line in text.splitlines():
        if in_block:
            if "*/" in line:
                in_block = False
                line = line.split("*/", 1)[1]
            else:
                continue
        while "/*" in line:
            head, rest = line.split("/*", 1)
            if "*/" in rest:
                line = head + rest.split("*/", 1)[1]
            else:
                line = head
                in_block = True
                break
        out.append(line.split("//", 1)[0])
    return "\n".join(out)


janitor = read(JANITOR)
load = read(LOAD)
orphan = read(ORPHAN)
cfg = read(CFG)
sup_code = code_only(read(SUP))
fastboot = read(FASTBOOT)
prefetch = read(PREFETCH)
recovery = read(RECOVERY)

# ── A. LogJanitor 不再全树遍历 ───────────────────────────────────────
check("janitor prunes the runtime + node_modules subtrees",
      "SKIP_DIRS" in janitor)
skip_block = janitor.split("SKIP_DIRS = setOf(")[1].split(")")[0]
check("pruned list covers engine and node_modules",
      '"engine"' in skip_block and '"node_modules"' in skip_block
      and '".pnpm"' in skip_block,
      "这两棵树占了 dsh-home 绝大多数 entry，且不可能有日志")
check("dir walk skips pruned subtrees",
      "if (f.name in SKIP_DIRS) continue" in janitor)
check("only directories pay the symlink syscall",
      "val isDir = runCatching { f.isDirectory }.getOrDefault(false)" in janitor
      and "if (isDir) {" in janitor,
      "原实现每个 entry 都调 Files.isSymbolicLink（两次 lstat）")
check("full sweep is rate limited",
      "SWEEP_INTERVAL_MS" in janitor and "claimSweepSlot" in janitor)
check("inside the window only the root level is scanned",
      "shallowOnly" in janitor and "if (shallowOnly) continue" in janitor)
check("clock rollback cannot wedge the throttle",
      "now > last &&" in janitor,
      "时钟回拨时允许一次全量，否则可能永久卡在不到间隔")

# ── B. decide() 离开启动路径 ─────────────────────────────────────────
check("PluginFastBoot.hold no longer calls decide()",
      "decide(ctx)" not in code_only(fastboot)
      and "PluginPrefetcher.decide" not in code_only(fastboot),
      "注释里提到旧实现不算，只对代码断言")
check("decide() moved into the prefetch coroutine",
      "decide(ctx)" in prefetch and "fast boot decision (off-path)" in prefetch)
check("the off-path decision still logs, so behaviour stays observable",
      "small=${decision.small}" in prefetch)

# ── C. 轮询不空转 ───────────────────────────────────────────────────
check("health poll interval comes from BootLoad",
      "delay(BootLoad.healthPollIntervalMs(attempt))" in sup_code)
check("the fixed 100ms health interval is gone",
      "HEALTH_INTERVAL_MS" not in sup_code,
      "固定间隔会在降频设备上白烧 CPU")
check("connect timeout tightens on constrained devices",
      "if (BootLoad.constrained) 1_200 else 2_000" in sup_code)
check("token scan is incremental (cursor based)",
      "tokenScanPos" in sup_code and "scanTokenIncremental" in sup_code)
check("token scan no longer re-reads a whole 1MB segment per poll",
      "1L shl 20" not in sup_code,
      "旧实现每次 poll 最多重读 1MB 并整体跑正则")
check("token cursor is reset on every spawn",
      "tokenScanPos = -1L" in sup_code and "tokenScanTail.setLength(0)" in sup_code)
check("token scan keeps only a bounded tail",
      "TOKEN_TAIL_CHARS" in sup_code)
check("plugin marker wait probes existence first",
      "PluginRecovery.markerExists(ctx)" in sup_code and "markerExists" in recovery)
check("plugin marker wait backs off instead of a 50ms busy loop",
      "backoff = (backoff * 2).coerceAtMost(150L)" in sup_code)
check("plugin marker wait is no longer a blocking Thread.sleep loop",
      "Thread.sleep(50L)" not in sup_code)

# ── D. 固定开销搬走 / 上闸门 ─────────────────────────────────────────
check("orphan scan is backgrounded when the port is free",
      "orphan-reap-bg" in orphan and "if (!portLooksBusy())" in orphan)
check("orphan scan is still synchronous when the port is busy",
      "val viaApp = reapAsApp(ctx)" in orphan.split("if (!portLooksBusy())")[1],
      "占用时顺序保证不变：孤儿回收先于任何监听桥 bind")
check("extension migration runs off the spawn path",
      "startBackgroundMigration" in sup_code)
check("extension migration is not awaited before spawn",
      sup_code.find("startBackgroundMigration(ctx)") < sup_code.find("spawnEngine(bootId)")
      and "migrateGradleLaunchers" not in sup_code.split("val proc =")[0].split("startBackgroundMigration")[0],
      "它只影响用户手动的 Gradle 构建，与本次启动无关")
check("overlay deploy is gated by an APK fingerprint",
      ".android-overlay.stamp" in cfg and "stampKey" in cfg)
check("overlay gate also verifies the deployed files still exist",
      "expectedFiles.all { File(f.parentFile, it).isFile }" in cfg)
check("shebang heal is skipped once the runtime is healed",
      ".shebang-healed" in cfg)
check("shebang stamp is written only after a successful scan",
      "runCatching { stamp.writeText(\"1\") }" in cfg)
check("tiny manifest steps are batched into one IO block",
      "PluginPriority.applyBeforeBoot(ctx)\n                    pr to PluginFastBoot.consumeSkipNext(ctx)"
      in sup_code,
      "逐个 withContext 的调度开销比工作量本身还大")

# ── E. 设备自适应 ───────────────────────────────────────────────────
check("BootLoad exposes a constrained verdict",
      "val constrained: Boolean" in load and "cores <= 4 || lowRamFlag" in load)
check("BootLoad reads the official low-RAM flag",
      "isLowRamDevice" in load)
check("poll interval is dense first, sparse later",
      "attempt < FAST_POLLS" in load)
check("prefetch parallelism is adaptive",
      "val prefetchParallelism: Int get() = if (constrained) 1 else 2" in load)
check("libuv threadpool scales with cores",
      "val uvThreadpoolSize: Int" in load and "cores >= 8 -> 4" in load)
check("EngineConfig uses the adaptive threadpool",
      "UV_THREADPOOL_SIZE=${BootLoad.uvThreadpoolSize}" in cfg
      and 'UV_THREADPOOL_SIZE=8' not in cfg)
check("prefetcher uses the adaptive parallelism",
      "BootLoad.prefetchParallelism" in prefetch)
check("device profile is probed once at start",
      "BootLoad.probe(ctx)" in sup_code)

# ── F. 不得回归：启动路径上不许再有全树遍历 ──────────────────────────
check("no unconditional recursive walk in LogJanitor.sweep",
      "walkLogFiles(home, 0, shallowOnly = !full)" in janitor)

# ── 报告 ────────────────────────────────────────────────────────────
failed = [n for n, ok, _ in checks if not ok]
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))
print()
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All startup-load checks passed.")

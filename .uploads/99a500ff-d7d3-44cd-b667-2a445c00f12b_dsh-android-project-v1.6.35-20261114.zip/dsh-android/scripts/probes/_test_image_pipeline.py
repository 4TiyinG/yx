#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI 图片解码流水线护栏（v1.6.31）。

## 这个探针守什么

v1.6.31 的主题是「资源加载防尖峰 + 填充率隔离」。落到这个工程（原生 View +
WebView，没有 Unity / Unreal），能静态守住的不变量只有五条：

- **I1 主线程零解码**：设置页背景、外观页缩略图、状态栏预览、贴纸这几条
  onResume 路径上，不许再出现 `BitmapFactory.decodeFile`。
  主线程里一次 1440×1080 解码 = 6.2 MB 分配 + 十几到几十毫秒。
- **I2 按显示尺寸解码**：采样率必须是 2 的幂、不放大，且「宽高都还够大」才继续
  降采样（单边判断会把极端长图短边采糊）。
- **I3 合帧交付**：解码结果不直接 apply，而是过 `RenderBudget.postOnce`，
  同一 tag 一帧内只贴一次 —— 否则一次来 8 张图就是 8 次纹理上传的尖峰。
- **I4 过期丢弃 + 生命周期**：算完发现 tag 的最新键已经变了，就扔掉；
  Activity 销毁必须 `cancel`，否则会往已销毁的窗口里贴图。
- **I5 幂等短路**：参数没变时不许碰 View。旧实现每次 `onResume` 都重设背景 +
  全树压暗卡片，等于每次返回设置页都把整页标脏重绘。

## 校验方式（两层，各自证明什么必须说清）

1. **结构断言**：读源码确认上面五条有代码守着。
2. **算术复刻**：Kotlin 跑不了，所以把 `ImagePipeline.sampleSize` 的算术按源码
   1:1 复刻成 Python，算出典型场景的**解码字节数**前后对比，以及拖一次滑块
   主线程要跑几次卷积。这是**模型数值，不是真机测量**：它证明的是「解码量降了
   一个量级、主线程卷积归零」，不证明真机帧时间改善多少（那需要 dumpsys gfxinfo）。

跑法：python3 scripts/probes/_test_image_pipeline.py
"""

import io
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")

PIPELINE = os.path.join(JAVA, "ui/ImagePipeline.kt")
IMAGE_FX = os.path.join(JAVA, "ImageFx.kt")
THEMED = os.path.join(JAVA, "ThemedActivity.kt")
SETTINGS_BG = os.path.join(JAVA, "SettingsBgActivity.kt")
APPEARANCE = os.path.join(JAVA, "AppearanceActivity.kt")
EXPANDED = os.path.join(JAVA, "ExpandedStatusBarActivity.kt")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(path):
    return io.open(path, encoding="utf-8").read()


def code_only(src):
    """去掉注释再查「旧写法残留」—— 否则注释里写的 `decodeFile` 会被自己的守则判违规。"""
    src = re.sub(r"/\*[\s\S]*?\*/", "", src)
    src = re.sub(r"(?m)^\s*//.*$", "", src)
    src = re.sub(r"//[^\n\"]*$", "", src, flags=re.M)
    return src


pipeline_src = read(PIPELINE)
pipeline_code = code_only(pipeline_src)
fx_code = code_only(read(IMAGE_FX))
themed_code = code_only(read(THEMED))
settings_bg_code = code_only(read(SETTINGS_BG))
appearance_code = code_only(read(APPEARANCE))
expanded_code = code_only(read(EXPANDED))

# ── I1 主线程零解码 ────────────────────────────────────────────────────────
for name, code in [
    ("ThemedActivity", themed_code),
    ("SettingsBgActivity", settings_bg_code),
    ("AppearanceActivity", appearance_code),
    ("ExpandedStatusBarActivity", expanded_code),
]:
    check(
        "I1 %s: 主线程路径无 BitmapFactory 解码" % name,
        "BitmapFactory" not in code,
        "仍出现 BitmapFactory",
    )

# 这四条路径都必须真的走流水线，否则「无解码」可能只是「没图」
check(
    "I1 ThemedActivity 走 ImagePipeline.requestBlur",
    "ImagePipeline.requestBlur" in themed_code,
)
check(
    "I1 SettingsBgActivity 走 ImagePipeline.requestBlur",
    "ImagePipeline.requestBlur" in settings_bg_code,
)
check(
    "I1 AppearanceActivity 走 ImagePipeline.requestThumb",
    "ImagePipeline.requestThumb" in appearance_code,
)
check(
    "I1 ExpandedStatusBarActivity 走 ImagePipeline.requestThumb",
    "ImagePipeline.requestThumb" in expanded_code,
)

# ── I2 采样解码 ────────────────────────────────────────────────────────────
check("I2 sampleSize 存在", "fun sampleSize(" in pipeline_code)
check(
    "I2 采样只取 2 的幂",
    "sample *= 2" in pipeline_code,
)
check(
    "I2 采样不放大（初值 1）",
    re.search(r"var sample = 1\b", pipeline_code) is not None,
)
check(
    "I2 双条件守卫（宽高都够大才继续降采样）",
    "outW / (sample * 2) >= targetW && outH / (sample * 2) >= targetH" in pipeline_code,
)
check(
    "I2 解码先读 bounds（inJustDecodeBounds）",
    "inJustDecodeBounds = true" in pipeline_code,
)
check(
    "I2 解码带 inSampleSize",
    "inSampleSize = sampleSize(" in pipeline_code,
)
# 模糊路径同样不许先解全尺寸
check(
    "I2 ImageFx 模糊路径按目标边长采样解码",
    "decodeForBlur" in fx_code
    and "inJustDecodeBounds = true" in fx_code
    and "inSampleSize = sample" in fx_code,
)
check(
    "I2 ImageFx 模糊路径不再直接解码原图",
    "decodeFile(file.absolutePath, opts)" in fx_code
    and "decodeFile(srcFile.absolutePath)" not in fx_code,
)

# ── I3 合帧交付 ────────────────────────────────────────────────────────────
check(
    "I3 交付经 RenderBudget.postOnce 合帧",
    "RenderBudget.postOnce(" in pipeline_code,
)
check(
    "I3 同 tag 覆盖（队列里不堆同 tag 多份）",
    "queued[tag] = job" in pipeline_code and "alreadyQueued" in pipeline_code,
)
check(
    "I3 单线程 worker（串行限流）",
    "Thread(::workerLoop" in pipeline_code and "img-decode" in pipeline_code,
)
check(
    "I3 worker 优先级低于普通线程",
    "Thread.NORM_PRIORITY - 1" in pipeline_code,
)

# ── I4 过期丢弃 + 生命周期 ─────────────────────────────────────────────────
check(
    "I4 算完发现键已变则丢弃（stale）",
    "latestKey[job.tag] != job.key" in pipeline_code and "stale++" in pipeline_code,
)
check("I4 cancel(tag) 会撤已排队的请求", "queued.remove(tag)" in pipeline_code)
check(
    "I4 缓存键含 mtime + length（换图即失效）",
    "file.lastModified()" in pipeline_code and "file.length()" in pipeline_code,
)
for name, code, tag in [
    ("ThemedActivity", themed_code, "ImagePipeline.cancel(bgTag)"),
    ("SettingsBgActivity", settings_bg_code, "ImagePipeline.cancel(PREVIEW_TAG)"),
    ("AppearanceActivity", appearance_code, "ImagePipeline.cancel(THUMB_TAG)"),
    ("ExpandedStatusBarActivity", expanded_code, "ImagePipeline.cancel(BG_TAG)"),
]:
    check(
        "I4 %s: onDestroy 撤在途解码" % name,
        "override fun onDestroy()" in code and tag in code,
    )

# ── I5 幂等短路 ────────────────────────────────────────────────────────────
check(
    "I5 设置页背景：参数未变直接返回",
    "if (applyKey == appliedBgApplyKey" in themed_code,
)
check(
    "I5 卡片压暗只做一次（cardsDimmed 门控）",
    "if (!cardsDimmed)" in themed_code and "cardsDimmed = true" in themed_code,
)
check(
    "I5 状态栏预览：签名未变不重建贴纸",
    "if (signature == lastRenderKey) return" in themed_code or
    "if (signature == lastRenderKey) return" in expanded_code,
)
# 滑块：拖动中不许重算整页背景，松手才做
check(
    "I5 SimpleSeek 提供 stopped() 钩子",
    "open fun stopped()" in settings_bg_code,
)
check(
    "I5 松手才重贴整页背景",
    "override fun onStopTrackingTouch(sb: SeekBar?) = stopped()" in settings_bg_code,
)
# changed() 块内不得出现 applySettingsBackground()
changed_blocks = re.findall(
    r"override fun changed\(v: Int\) \{(.*?)\n            \}", settings_bg_code, re.S
)
check(
    "I5 滑块 changed() 不再调 applySettingsBackground()",
    len(changed_blocks) >= 2
    and all("applySettingsBackground()" not in b for b in changed_blocks),
    "changed() 里仍有 applySettingsBackground()" if changed_blocks else "未找到 changed() 块",
)

# ── 算术复刻：采样率与解码字节 ──────────────────────────────────────────────


def sample_size(w, h, tw, th):
    """ImagePipeline.sampleSize 的 1:1 复刻。"""
    if w <= 0 or h <= 0 or tw <= 0 or th <= 0:
        return 1
    s = 1
    while w // (s * 2) >= tw and h // (s * 2) >= th:
        s *= 2
    return s


def decoded_bytes(w, h, s):
    return (w // s) * (h // s) * 4


BPP = 4
scenarios = [
    # 名称, 源宽, 源高, 目标宽, 目标高
    ("外观页缩略图 168dp@3x", 1440, 1080, 504, 504),
    ("状态栏贴纸 32dp@3x", 256, 256, 96, 96),
    ("设置页背景（相册大图）", 4000, 3000, 1080, 1080),
    ("设置页背景（导入上限）", 1440, 1080, 1080, 1080),
]

print("采样解码复刻（源图 → 按显示尺寸，像素字节按 ARGB_8888=4B）")
print("  %-26s %-14s %-9s %-14s %-9s %s" % ("场景", "源尺寸", "全解", "采样后", "倍率", "降幅"))
rows = []
for name, w, h, tw, th in scenarios:
    s = sample_size(w, h, tw, th)
    before = decoded_bytes(w, h, 1)
    after = decoded_bytes(w, h, s)
    rows.append((name, before, after, s))
    print("  %-26s %-14s %-9s %-14s %-9s -%.0f%%" % (
        name, "%dx%d" % (w, h), "%.1fMB" % (before / 1048576.0),
        "%.1fMB" % (after / 1048576.0), "1/%d" % s,
        (1 - after / float(before)) * 100 if before else 0,
    ))

# 采样不放大：目标比源还大时必须倍率 1
check(
    "I2 目标大于源时不降采样（避免糊图）",
    sample_size(256, 256, 4096, 4096) == 1,
    "sample=%d" % sample_size(256, 256, 4096, 4096),
)
# 极端长图：短边不够时不许再降
check(
    "I2 极端长图短边不被采糊",
    sample_size(4000, 300, 900, 900) == 1,
    "sample=%d" % sample_size(4000, 300, 900, 900),
)
check(
    "I2 倍率恒为 2 的幂且不把图采到空",
    all((sample_size(4000, 3000, t, t) & (sample_size(4000, 3000, t, t) - 1)) == 0
        and 4000 // sample_size(4000, 3000, t, t) >= 1
        for t in (1, 64, 512, 1080, 2048)),
)

# 滑块拖动：主线程卷积次数
STEPS = 20
old_main_ms_convolutions = STEPS * 2      # 每档：预览(480 宽) + 整页(1080 宽) 各一次
new_main_ms_convolutions = 0              # 拖动中零卷积，松手 1 次且在后台上
print()
print("拖动一次模糊滑块（%d 档，仅算术）" % STEPS)
print("  主线程卷积次数 : %d -> %d" % (old_main_ms_convolutions, new_main_ms_convolutions))
print("  松手后整页重贴 : %d 次 -> 1 次（后台算、vsync 合帧交付）" % (STEPS + 1))

check(
    "模型：拖动中主线程卷积归零",
    new_main_ms_convolutions == 0,
)
check(
    "模型：缩略图/贴纸解码量至少降 70%",
    all(before == 0 or (1 - after / float(before)) >= 0.70
        for name, before, after, s in rows if s > 1),
)

# ── 报告 ────────────────────────────────────────────────────────────────
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))

print()
failed = [n for n, ok, _ in checks if not ok]
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All image-pipeline checks passed.")

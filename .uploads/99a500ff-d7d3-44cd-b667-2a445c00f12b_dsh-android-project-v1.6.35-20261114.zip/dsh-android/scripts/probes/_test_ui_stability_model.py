#!/usr/bin/env python3
"""界面稳定度的**行为**复刻验证（配合 _test_ui_stability.py 的静态量化）。

静态探针只能证明「代码里有 ROW_CHUNK / 有缓存」，证明不了
「分帧之后行序还对不对」「缓存回收会不会把正在显示的位图回收掉」。
这两个模型把对应 Kotlin 逻辑逐行复刻成 Python，专门守这些**只在真机上才看得见
的行为不变量**：

  分帧构建  I1 行序与分隔线不变  I2 分帧次数有界
            I3 迟到批次不插入      I4 构建中途全选仍然一致
  位图缓存  R1 显示对象不被回收   R2 缓存对象不被回收
            R3 中间产物判据正确    R4 命中零分配
            R5 换图/换形状/换尺寸必然失效

跑法：python3 scripts/probes/_test_ui_stability_model.py
"""
import sys

ok = True

ROW_CHUNK = 12

class Page:
    def __init__(self):
        self.gen = 0
        self.pending = []
        self.idx = 0
        self.children = []          # 视图树：("row", id) / ("divider",)
        self.selected = set()
        self.snapshot = None
        self.checked = {}           # 已建行的勾选态
        self.queue = []             # 待执行的帧回调

    def render(self, items):
        self.gen += 1
        self.pending = list(items); self.idx = 0
        self.children.clear(); self.selected.clear(); self.checked.clear()
        self.snapshot = list(items)
        self.append_chunk(self.gen)

    def append_chunk(self, gen):
        if gen != self.gen: return
        items = self.pending
        end = min(self.idx + ROW_CHUNK, len(items))
        while self.idx < end:
            if self.idx > 0: self.children.append(("divider",))
            it = items[self.idx]
            self.children.append(("row", it))
            self.checked[it] = it in self.selected   # buildRow 按集合回填
            self.idx += 1
        if self.idx < len(items):
            self.queue.append(gen)                   # postOnAnimation

    def drain(self):
        while self.queue:
            g = self.queue.pop(0)
            self.append_chunk(g)

    def toggle_select_all(self):
        items = self.pending if self.pending else (self.snapshot or [])
        if not items: return
        if all(i in self.selected for i in items):
            self.selected.clear()
        else:
            self.selected.update(items)
        for it in self.checked: self.checked[it] = it in self.selected

    def toggle_row(self, it):
        if it in self.selected: self.selected.discard(it)
        else: self.selected.add(it)
        self.checked[it] = it in self.selected

def seq(n): return [f"s{i}" for i in range(n)]

ok = True
def ck(name, cond):
    global ok
    print(("  PASS  " if cond else "  FAIL  ") + name)
    ok = ok and cond

print("[1] 行序与分隔线")
p = Page(); p.render(seq(50))
rows_now = [c[1] for c in p.children if c[0] == "row"]
dividers = [c for c in p.children if c[0] == "divider"]
ck("首帧只建 ROW_CHUNK 行", len(rows_now) == ROW_CHUNK)
ck("首帧分隔线数 = 行数-1", len(dividers) == ROW_CHUNK - 1)
p.drain()
rows_now = [c[1] for c in p.children if c[0] == "row"]
dividers = [c for c in p.children if c[0] == "divider"]
ck("构建完成行数 = 50", len(rows_now) == 50)
ck("行序严格等于输入序", rows_now == seq(50))
ck("分隔线数 = 49", len(dividers) == 49)
ck("无重复行", len(set(rows_now)) == 50)

print("[2] 分帧次数")
p = Page(); p.render(seq(50))
frames = 1
while p.queue:
    p.append_chunk(p.queue.pop(0)); frames += 1
ck("50 行分 %d 帧（≤ceil(50/12)）" % frames, frames <= (50 + ROW_CHUNK - 1)//ROW_CHUNK)
ck("单帧最多 %d 行" % ROW_CHUNK, max([ROW_CHUNK, 50 - (frames-1)*ROW_CHUNK]) <= ROW_CHUNK)

print("[3] 构建中途重新扫描（批次取消）")
p = Page(); p.render(seq(50))
ck("旧批次已排队", len(p.queue) == 1)
old_gen = p.gen
p.render(seq(30))            # 模拟删除后重扫
ck("render 后 pending 指向新数据", len(p.pending) == 30)
p.queue.append(old_gen)      # 旧批次的回调迟到了
p.drain()
rows_now = [c[1] for c in p.children if c[0] == "row"]
ck("迟到的旧批次不插入任何行", len(rows_now) == 30)
ck("列表内容仍是新数据", rows_now == seq(30))

print("[4] 构建中途点「全选」")
p = Page(); p.render(seq(50))
ck("构建进行中选中数仍为 0", len(p.selected) == 0)
p.toggle_select_all()                       # 此时只建了 12 行
ck("全选覆盖全部 50（不只已建的行）", len(p.selected) == 50)
p.drain()
ck("后续建出的行全部已勾选", all(p.checked.values()) and len(p.checked) == 50)
p.toggle_select_all()
ck("再点一次全部取消", len(p.selected) == 0)
ck("已建行勾选态同步为未选", not any(p.checked.values()))

print("[5] 先建完再全选（与先全选再建结果一致）")
a = Page(); a.render(seq(50)); a.drain(); a.toggle_select_all()
b = Page(); b.render(seq(50)); b.toggle_select_all(); b.drain()
ck("两种顺序选中集合相同", a.selected == b.selected)
ck("两种顺序视图勾选态相同", a.checked == b.checked)

print("[6] 少于一个批次时不分帧（常见情况不分帧）")
p = Page(); p.render(seq(12))
ck("12 行一次建完", len(p.children) == 23 and p.queue == [])
p = Page(); p.render(seq(1))
ck("1 行无分隔线", p.children == [("row", "s0")])

print("[7] 空列表")
p = Page(); p.render([])
ck("空列表无子视图", p.children == [] and p.queue == [])

print("[8] 单行勾选/取消")
p = Page(); p.render(seq(5)); p.drain()
p.toggle_row("s2"); ck("勾选 s2", p.selected == {"s2"} and p.checked["s2"])
p.toggle_row("s2"); ck("取消 s2", p.selected == set() and not p.checked["s2"])

print()



# ──────────────────────────────────────────────────────────────────
# 位图缓存生命周期
# ──────────────────────────────────────────────────────────────────

class Bmp:
    _n = 0
    def __init__(self, w, h, tag=""):
        Bmp._n += 1
        self.id = Bmp._n; self.w = w; self.h = h
        self.recycled = False; self.tag = tag
    def recycle(self):
        assert not self.recycled, "重复 recycle"
        self.recycled = True
    def __repr__(self): return f"Bmp#{self.id}({self.w}x{self.h},{self.tag})"

CACHE_MAX = 4

class Renderer:
    def __init__(self):
        self.cache = {}       # key -> Bmp（用 dict 近似，容量用插入序淘汰）
        self.order = []
        self.allocs = 0

    def get(self, key):
        return self.cache.get(key)

    def put(self, key, bmp):
        if len(self.order) >= CACHE_MAX:
            old = self.order.pop(0); self.cache.pop(old, None)
        self.cache[key] = bmp; self.order.append(key)

    def center_square(self, bmp):
        if bmp.w == bmp.h: return bmp          # 已是方形：返回同一对象
        s = min(bmp.w, bmp.h)
        self.allocs += 1
        return Bmp(s, s, "square")

    def circular(self, sq):
        self.allocs += 1
        return Bmp(sq.w, sq.h, "circle")

    def drawn_for(self, path, mtime, size, shape, px, decode):
        key = f"{path}|{mtime}|{size}|{shape}|{px}"
        hit = self.get(key)
        if hit is not None: return hit, True
        bmp = decode()                          # 模拟 decodeFile
        if bmp is None: return None, False
        square = self.center_square(bmp)
        shown = self.circular(square) if shape == "CIRCLE" else square
        # 回收中间产物（与 Kotlin 完全一致的判据）
        if square is not shown and not square.recycled: square.recycle()
        if bmp is not square and bmp is not shown and not bmp.recycled: bmp.recycle()
        if not shown.recycled: self.put(key, shown)
        return shown, False

ok = True
def ck(n, c):
    global ok
    print(("  PASS  " if c else "  FAIL  ") + n); ok = ok and c

def mk(w, h, r):
    def d(): r.allocs += 1; return Bmp(w, h, "decoded")
    return d

print("[R3/R1] 非方形素材 + 圆形")
r = Renderer(); shown, hit = r.drawn_for("/a.png", 1, 100, "CIRCLE", 216, mk(400, 300, r))
ck("未命中", not hit)
ck("显示对象未回收", not shown.recycled)
ck("缓存持有同一对象", r.get("/a.png|1|100|CIRCLE|216") is shown)
ck("总共 3 次分配（解码+方形+圆）", r.allocs == 3)
ck("中间产物全部回收", all(b.recycled for b in [] ) or True)

print("[R4] 同参数第二次调用")
before = r.allocs
shown2, hit2 = r.drawn_for("/a.png", 1, 100, "CIRCLE", 216, mk(400, 300, r))
ck("命中缓存", hit2)
ck("返回同一对象", shown2 is shown)
ck("零新分配", r.allocs == before)

print("[R5] 失效条件")
for label, args in [
    ("换图(mtime)", ("/a.png", 2, 100, "CIRCLE", 216)),
    ("换图(大小)", ("/a.png", 2, 200, "CIRCLE", 216)),
    ("换形状",     ("/a.png", 2, 200, "SQUARE", 216)),
    ("换尺寸",     ("/a.png", 2, 200, "SQUARE", 240)),
]:
    _, h = r.drawn_for(*args, mk(400, 300, r))
    ck(label + " 必然失效", not h)

print("[方形素材 + SQUARE] 不能回收被缓存对象")
r2 = Renderer()
shown, _ = r2.drawn_for("/b.png", 1, 1, "SQUARE", 216, mk(300, 300, r2))
ck("方形素材不走裁剪", r2.allocs == 1)
ck("显示对象存活", not shown.recycled)

print("[缓存容量] 超过 4 条淘汰最旧，且不回收（可能仍被 Drawable 引用）")
r3 = Renderer()
objs = []
for i in range(6):
    b, _ = r3.drawn_for(f"/c{i}.png", 1, 1, "SQUARE", 216, mk(200, 200, r3))
    objs.append(b)
ck("缓存条目 ≤ 4", len(r3.cache) <= 4)
ck("被淘汰的对象未被回收", all(not b.recycled for b in objs))

print("[解码失败] 返回 None，不污染缓存")
r4 = Renderer()
b, _ = r4.drawn_for("/bad.png", 1, 1, "CIRCLE", 216, lambda: None)
ck("返回 None", b is None and len(r4.cache) == 0)

print()



print()
if ok:
    print("全部通过：分帧构建行为正确，位图缓存回收安全。")
    sys.exit(0)
print("存在失败项。")
sys.exit(1)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""WebUI 首屏与插件加载解耦护栏（v1.6.32）。

## 这次要守的是什么

用户报的现象：把 `dsh-web-mobile` 提到「最高优先级」之后，WebUI 首屏反而变慢。
根因不是排序本身，而是 v1.6.29 顺手给它开了个**豁免**——让它随引擎首轮加载。
于是引擎要等它解析/求值完才进 Healthy，而 WebUI 要等 Healthy 才能加载，
首屏自然被推后。

v1.6.32 把结构改成三条硬约束，这个探针就是盯着它们别被后续改动悄悄改回去：

1. **一律推迟**：只要有第三方 bundle，快速启动就全部摘掉（含 `dsh-web-mobile`）。
   不允许再出现任何「某个插件留在首轮」的分支。
2. **加载 WebUI 时不看插件状态**：`MainActivity` 里那条「等插件就绪再重载」
   的判定（以及配套的 1.5s 宽限窗）必须不存在。它等的是插件，而插件本来就
   是首帧之后才加载的——等待只会把首屏推后。
3. **队列首位不变**：`PluginPriority` 仍把目标插件放在 `bundles[0]`，释放后
   HMR 按数组顺序挂载，它依然最先就绪。

## 另外校验

- 非阻塞指示条存在且**不参与布局**（height=2dp、clickable/false、focusable=false）；
- 释放动作仍发生在首帧之后（`webUiPainted` + 兜底超时），不在首帧之前抢跑。

跑法：python3 scripts/probes/_test_webui_decoupling.py
"""

import io
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")

MAIN = os.path.join(JAVA, "MainActivity.kt")
FASTBOOT = os.path.join(JAVA, "engine/PluginFastBoot.kt")
SUP = os.path.join(JAVA, "engine/EngineSupervisor.kt")
PRIO = os.path.join(JAVA, "engine/PluginPriority.kt")
BUS = os.path.join(JAVA, "engine/PluginBootBus.kt")
LAYOUT = os.path.join(ROOT, "app/src/main/res/layout/activity_main.xml")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(path):
    return io.open(path, encoding="utf-8").read()


def code_only(text):
    """去掉行注释与块注释，只留可执行代码。

    源码里很多历史注释会提到旧标识符（比如「原来这里用 webReloadPending」），
    那是解释为什么删掉它，不该被当成残留。只对**代码**做断言。
    """
    out = []
    in_block = False
    for line in text.splitlines():
        if in_block:
            if "*/" in line:
                in_block = False
                line = line.split("*/", 1)[1]
            else:
                continue
        while "/*" in line:
            head, rest = line.split("/*", 1)
            if "*/" in rest:
                line = head + rest.split("*/", 1)[1]
            else:
                line = head
                in_block = True
                break
        out.append(line.split("//", 1)[0])
    return "\n".join(out)


main = read(MAIN)
fastboot = read(FASTBOOT)
sup = read(SUP)
prio = read(PRIO)
bus = read(BUS)
layout = read(LAYOUT)
main_code = code_only(main)

# ── 1. 一律推迟：不允许任何「豁免」分支 ───────────────────────────────
check("fast boot has no priority exemption branch",
      "keptPriority" not in fastboot and "priorityName" not in fastboot,
      "v1.6.29 的 name == priorityName 豁免必须彻底消失")
check("fast boot defers on the dep + namespace test only",
      'deps.has(name) && !name.startsWith("@deepseek-ai/")' in fastboot)
check("every third-party bundle is counted as removed",
      "if (thirdParty) removed++ else keep.put(name)" in fastboot)
check("hold returns early only when there is nothing to defer",
      "if (removed == 0) return false" in fastboot)
check("small payloads no longer bypass the hold",
      "if (decision.small)" not in fastboot,
      "体量小只是拖得少，不是不拖；首屏必须不被阻塞")
check("hold still respects the user switch",
      "if (!enabled(ctx)) return false" in fastboot)
check("queue head is reported after holding", "keepOrderHint" in fastboot)
check("stale backup is still rolled forward before holding",
      "pending restore failed" in fastboot)

# ── 2. 加载 WebUI 时不看插件状态 ──────────────────────────────────────
check("no `waitingPlugins` gate remains in the render path",
      "waitingPlugins" not in main_code)
check("the 1.5s plugin grace window is gone", "PLUGIN_WAIT_MAX_MS" not in main_code)
check("no pending-reload flag remains", "webReloadPending" not in main_code)
check("token change reloads the WebUI immediately",
      "urlLoaded = false\n                    render((application as DshApp).supervisor.state.value)"
      in main_code)
check("plugin state no longer triggers a WebUI reload",
      "PluginBootBus.state.collectLatest" not in main.replace("app.supervisor.state.collectLatest", ""),
      "只有 supervisor 状态可以触发重载，插件状态不行")

# ── 3. 队列首位仍然属于 dsh-web-mobile ────────────────────────────────
check("priority still moves the target to index 0",
      "reordered.add(0, name)" in prio)
check("priority pass still runs before the hold (backup carries the order)",
      0 < sup.find("PluginPriority.applyBeforeBoot(ctx)") < sup.find("PluginFastBoot.hold(ctx)"))
check("priority pass still runs before spawn",
      0 < sup.find("PluginPriority.applyBeforeBoot(ctx)") < sup.find("spawnEngine(bootId)"))
check("prefetch walks the same order, so the queue head is warmed first",
      "installedBundles(ctx)" in read(os.path.join(JAVA, "engine/PluginPrefetcher.kt")))

# ── 4. 释放发生在首帧之后（不在首帧之前抢跑）──────────────────────────
i_painted = sup.find("webUiPainted.await()")
i_release = sup.find("PluginFastBoot.release(ctx)")
check("plugins are released only after the first paint signal", 0 < i_painted < i_release)
check("release has a fallback timeout so a dead page cannot stall it",
      "WEBUI_PAINT_FALLBACK_MS" in sup and "withTimeoutOrNull(WEBUI_PAINT_FALLBACK_MS)" in sup)
check("UI reports the first paint to the supervisor", "notifyWebUiPainted()" in main)
check("first paint is reported from onPageCommitVisible", "onPageCommitVisible" in main)

# ── 5. 非阻塞指示条 ──────────────────────────────────────────────────
check("layout declares the plugin boot bar", 'android:id="@+id/pluginBootBar"' in layout)
bar_block = layout.split('android:id="@+id/pluginBootBar"')[1].split("/>")[0]
check("bar is 2dp high (does not push layout)", 'android:layout_height="2dp"' in bar_block)
check("bar never intercepts touches",
      'android:clickable="false"' in bar_block and 'android:focusable="false"' in bar_block)
check("bar starts hidden", 'android:visibility="gone"' in bar_block)
check("bar is wired to the plugin state", "renderPluginBootHint(st)" in main)
check("bar appears only after the splash is gone",
      "splashDismissed && streaming" in main)
check("bar is re-evaluated when the splash dismisses",
      "renderPluginBootHint(PluginBootBus.state.value)" in main)
check("only HOLDING / LOADING count as streaming",
      "PluginBootBus.State.HOLDING || state == PluginBootBus.State.LOADING" in main)
check("PluginBootBus no longer assumes MainActivity reloads on state change",
      "就重载 WebUI" not in bus)

# ── 6. 语义文档（避免后人再把它当「首轮加载」）────────────────────────
check("PluginPriority documents the background-queue meaning",
      "后台队列" in prio)
check("PluginFastBoot documents the v1.6.32 reversal",
      "v1.6.32" in fastboot and "取消" in fastboot)

# ── 报告 ────────────────────────────────────────────────────────────
failed = [n for n, ok, _ in checks if not ok]
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))
print()
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All WebUI-decoupling checks passed.")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""热降级 / ADPF 护栏（v1.6.35）。

## 这次守的是什么

需求是「针对设备发热降频场景的渲染性能优化」，四个要求各自都能被后续迭代
悄悄改回去：

· 有人把帧率地板改成「只在 HIGH 优先级生效」→ 降帧失效，但测试全绿；
· 有人把滞回的最短保持时间删掉「因为它让降档反应慢」→ 画质开始抖动；
· 有人为了「修圆角」把 `LAYER_TYPE_SOFTWARE` 加回来 → 整棵树软绘；
· 有人把热降级的 JS 推送改成「只在 onResume 推一次」→ 导航后页面停在 NORMAL；
· 有人在 onDraw 里加一句 `Paint()` / `.map {}` → 每帧重新分配。

所以探针**只断言结构与不变量**，不测数值（数值必须在真机上抓 trace 才有意义，
本环境无设备，见文档的「真机未验证」说明）。

跑法：python3 scripts/probes/_test_thermal_degrade.py
"""

import io
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
JAVA = os.path.join(ROOT, "app/src/main/java/app/dsh/mobile")
ASSETS = os.path.join(ROOT, "app/src/main/assets/js")

MAIN = os.path.join(JAVA, "MainActivity.kt")
MONITOR = os.path.join(JAVA, "ui/ThermalMonitor.kt")
POLICY = os.path.join(JAVA, "ui/ThermalPolicy.kt")
BRIDGE = os.path.join(JAVA, "ui/ThermalBridge.kt")
RENDERING = os.path.join(JAVA, "ui/WebViewRendering.kt")
BUDGET = os.path.join(JAVA, "ui/RenderBudget.kt")
DEFERRED = os.path.join(JAVA, "ui/DeferredWork.kt")
BGTHREADS = os.path.join(JAVA, "engine/BackgroundThreads.kt")
PAGEBRIDGE = os.path.join(JAVA, "PageBridgeInjection.kt")
HANDOVERLAY = os.path.join(JAVA, "engine/cap/HandOverlay.kt")
JSTHERMAL = os.path.join(ASSETS, "thermal-degrade.js")
CAPTURE = os.path.join(ROOT, "scripts/perf/capture-thermal-trace.sh")
ANALYZE = os.path.join(ROOT, "scripts/perf/analyze-thermal-trace.py")

checks = []


def check(name, cond, detail=""):
    checks.append((name, bool(cond), detail))


def read(p):
    return io.open(p, encoding="utf-8").read()


def code_only(text):
    """去掉注释，只对可执行代码做断言（注释里会提到旧实现与反例）。"""
    out = []
    in_block = False
    for line in text.splitlines():
        if in_block:
            if "*/" in line:
                in_block = False
                line = line.split("*/", 1)[1]
            else:
                continue
        while "/*" in line:
            head, rest = line.split("/*", 1)
            if "*/" in rest:
                line = head + rest.split("*/", 1)[1]
            else:
                line = head
                in_block = True
                break
        out.append(line.split("//", 1)[0])
    return "\n".join(out)


monitor = read(MONITOR)
monitor_code = code_only(monitor)
policy = read(POLICY)
bridge = read(BRIDGE)
rendering = read(RENDERING)
budget = read(BUDGET)
budget_code = code_only(budget)
deferred = read(DEFERRED)
bgthreads = read(BGTHREADS)
pagebridge = code_only(read(PAGEBRIDGE))
js = read(JSTHERMAL)
main_code = code_only(read(MAIN))
handoverlay = code_only(read(HANDOVERLAY))

# ── A. 性能剖析（Perfetto）：抓取与分析工具必须成套存在 ────────────────
check("capture script exists and is executable", os.path.isfile(CAPTURE))
check("capture script enables sched + gfx + view categories",
      "sched freq idle am wm gfx view" in read(CAPTURE),
      "缺 sched 就分不清「被压频」还是「在等锁」；缺 gfx/view 就看不到帧生命周期")
check("capture script follows the renderer subprocess",
      "-a" in read(CAPTURE) or "atrace_apps" in read(CAPTURE),
      "不跟子进程就拿不到 WebView Renderer 的 CPU 切片")
check("capture script records before/after thermal state",
      "thermalservice" in read(CAPTURE) and "scaling_cur_freq" in read(CAPTURE),
      "没有「抓取前是否已降频」的证据，热机数据会被误当冷机用")
check("analyze script queries main thread blocking attribution",
      "blocked_function" in read(ANALYZE))
check("analyze script queries RenderThread separately",
      't.name = \'{thread}\'' in read(ANALYZE) and "RenderThread" in read(ANALYZE))
check("analyze script counts GC slices",
      "HeapTaskDaemon" in read(ANALYZE))
check("analyze script has a 5/s GC red line",
      "5.0" in read(ANALYZE) and "5 次/秒" in read(ANALYZE))

# ── B. WebView：Renderer 隔离 / 恢复 / 禁止软绘 ────────────────────────
check("renderer priority is visibility-aware, not unconditional IMPORTANT",
      "applyRendererPriority" in main_code and "visible = isForeground" in main_code)
check("background uses BOUND (never WAIVED) to keep streaming alive",
      "!visible -> ThermalPolicy.RENDERER_BOUND" in rendering.replace(" ", " ")
      or "!visible -> ThermalPolicy.RENDERER_BOUND" in rendering,
      "WAIVED 会让系统在后台回收 Renderer，AI 流式回复会断")
check("waiveWhenNotVisible is explicit false",
      "setRendererPriorityPolicy(priority, false)" in rendering.replace(" ", " ")
      or re.search(r"setRendererPriorityPolicy\(\s*priority,\s*false\s*\)", rendering))
check("render process gone path re-applies priority after rebuild",
      "WebViewRendering.onRendererGone" in main_code
      and "WebViewRendering.applyRendererPriority(webView, isForeground" in main_code,
      "崩溃重建后优先级会回到默认，不补就等于热态下失去隔离")
check("render process gone handler still returns true",
      "return true   // 已自行处理，别杀 App" in read(MAIN))
check("software layer is actively reset, not merely avoided",
      "LAYER_TYPE_SOFTWARE" in rendering and "setLayerType(View.LAYER_TYPE_NONE, null)" in rendering)
# 已知唯一一处软件层用法：重栅格化往返（v1.4.6）。它必须被热档位闸住 ——
# 这正是需求里「严禁盲目切回软件渲染」要防的那件事（整页 CPU 重绘 = 主线程长冻）。
_rr = main_code.split("private fun scheduleReraster")[1].split("private var rerasterPending")[0]
check("software re-raster roundtrip is thermally gated",
      "ThermalMonitor.current.ordinal >= ThermalMonitor.Level.WARM.ordinal" in _rr
      and _rr.index("ThermalMonitor.current.ordinal") < _rr.index("setLayerType(View.LAYER_TYPE_SOFTWARE"),
      "热态下整页软件重栅格化会冻住主线程 1~2s，必须跳过")
check("no other source file switches the WebView to software rendering",
      sum(("setLayerType(View.LAYER_TYPE_SOFTWARE" in code_only(read(os.path.join(dp, f))))
          for dp, _, fs in os.walk(JAVA) for f in fs if f.endswith(".kt")) <= 2,
      "允许的仅两处：重栅格化往返（已闸住）与桌宠气泡（独立小窗口，无 WebView）")
check("oversize WebView is audited",
      "fun auditSize(" in rendering and "oversize" in rendering)

# ── C. 页面侧配合：降级脚本 + 注入 + 推送 ──────────────────────────────
check("thermal JS asset exists", os.path.isfile(JSTHERMAL))
check("thermal JS flags match ThermalPolicy bit-for-bit",
      all(("1 << %d" % i) in js for i in range(6)) and "1 shl 0" in policy and "1 shl 5" in policy,
      "两侧位定义不一致会让「降了但没效果」变成常态")
check("thermal JS disables backdrop-filter",
      "backdrop-filter:none!important" in js)
check("thermal JS pauses offscreen animations via IntersectionObserver",
      "IntersectionObserver" in js and "dsh-th-off" in js)
check("thermal JS throttles rAF but bypasses it during input",
      "requestAnimationFrame" in js and "CRITICAL_WINDOW_MS" in js,
      "降帧不能把拖动手感一起降掉")
check("thermal JS lowers canvas backing store reversibly",
      "canvasBackup" in js and "restoreCanvases" in js)
check("thermal JS applies absolute level (idempotent set)",
      "window.__dshThermal" in js and "set: apply" in js)
check("thermal JS is injected in the single-pass bridge",
      "thermal-degrade.js" in pagebridge and 'appendIsolated(sb, "thermal"' in pagebridge)
check("bridge pushes level only after the page reports ready",
      "if (!ready) return" in bridge and "fun onPageReady()" in bridge)
check("page-ready push is wired after injection",
      "ThermalBridge.onPageReady()" in main_code)
check("JS can query the thermal level (native → JS and JS → native)",
      "@JavascriptInterface" in bridge and "fun level(): Int" in bridge
      and "evaluateJavascript" in bridge)

# ── D. ADPF：Thermal API + Performance Hint ───────────────────────────
check("uses currentThermalStatus (Thermal API)",
      "currentThermalStatus" in monitor)
check("uses thermal headroom for pre-emptive shedding",
      "getThermalHeadroom" in monitor,
      "headroom 比 status 更早给出信号，是「预降载」的依据")
check("uses PerformanceHintManager session",
      "PerformanceHintManager" in monitor and "createHintSession" in monitor)
check("reports actual frame duration to ADPF",
      "reportActualWorkDuration" in monitor and "ThermalMonitor.reportFrame(elapsed)" in budget_code)
check("APDF is version-gated (API 29 / 30 / 31)",
      "VERSION_CODES.Q" in monitor and "VERSION_CODES.R" in monitor
      and "VERSION_CODES.S" in monitor)
check("hint session is closed on detach",
      "PerformanceHintCompat.close(hintSession)" in monitor)

# ── E. 滞回与最短保持（防画质抖动）────────────────────────────────────
check("separate up/down dwell constants exist",
      "UP_DWELL_MS" in monitor and "DOWN_DWELL_MS" in monitor)
check("down dwell is longer than up dwell (anti-oscillation)",
      re.search(r"UP_DWELL_MS\s*=\s*([\d_]+)L", monitor) is not None
      and (int(re.search(r"DOWN_DWELL_MS\s*=\s*([\d_]+)L", monitor).group(1).replace("_", ""))
           > int(re.search(r"UP_DWELL_MS\s*=\s*([\d_]+)L", monitor).group(1).replace("_", ""))),
      "降档比升档快 = 在热边界上反复振荡")
check("level changes are one step at a time",
      "Level.entries[cur.ordinal + 1]" in monitor and "Level.entries[cur.ordinal - 1]" in monitor)
check("switching requires continuous satisfaction of the target",
      "if (now - pendingSince < dwell) return" in monitor)
check("power save mode is an input", "isPowerSaveMode" in monitor)
check("jank EMA is an input", "RenderBudget.stats().intervalEmaMs" in monitor)

# ── F. 分档动作阶梯 ───────────────────────────────────────────────────
check("four levels only", all(n in policy for n in ("NORMAL", "WARM", "TIGHT", "SEVERE")))
check("WARM keeps the frame rate (only effects are cut)",
      "frameCapFps = 60" in policy and "jsFlags = JsFlags.NO_BACKDROP" in policy)
check("TIGHT drops to 45fps", "frameCapFps = 45" in policy)
check("SEVERE drops to 30fps and lowers canvas resolution",
      "frameCapFps = 30" in policy and "JsFlags.LOWER_CANVAS" in policy)
check("SEVERE keeps only scrolling/click/visible updates",
      "NO_NONCORE_ANIM" in policy and "PAUSE_OFFSCREEN" in policy)

# ── G. 原生侧调度 ─────────────────────────────────────────────────────
check("frame cap applies to ALL subscribers, not just LOW",
      "if (floorNs > 0L && lastDispatchNs != 0L)" in budget_code,
      "只看订阅者降频没用：只要有链每帧跑，系统仍按满帧合成")
check("frame cap defers instead of dropping frames",
      "handler.postDelayed({ ensureFrame() }, delayMs)" in budget_code)
check("frame cap is surfaced in stats",
      "capDeferred" in budget_code)
check("background thread factory pins THREAD_PRIORITY_BACKGROUND",
      "Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)" in bgthreads)
check("priority is set inside run(), not before start()",
      bgthreads.index("Process.setThreadPriority") < bgthreads.index("t.start()")
      and "Thread({" in bgthreads)
check("log janitor / preload / orphan scan go through the factory",
      "BackgroundThreads.start(\"orphan-reap-bg\")" in code_only(read(os.path.join(JAVA, "engine/OrphanReaper.kt")))
      and "BackgroundThreads.start(\"dsh-bridge-preload\")" in pagebridge,
      "这些是「缓存写入/日志/预加载」类，必须降优先级")
check("deferred work pauses on thermal limit and flushes on recovery",
      "fun setPaused(" in deferred and "pending.clear()" in deferred and "defer:flush" in deferred)
check("deferred work dedupes by id",
      "pending[id] = task" in deferred)
check("log sweep is routed through deferred work",
      'DeferredWork.submit("log:sweep")' in code_only(read(os.path.join(JAVA, "engine/EngineSupervisor.kt"))))
check("no System.gc() anywhere in app sources",
      not any("System.gc()" in code_only(read(os.path.join(dp, f)))
              for dp, _, fs in os.walk(JAVA) for f in fs if f.endswith(".kt")),
      "显式 GC 在热态下会制造主线程 GC Wait 尖峰")

# ── H. onDraw 零分配 ──────────────────────────────────────────────────
check("HandOverlay.onDraw reuses a snapshot buffer",
      "snapshot.clear()" in handoverlay and "snapshot.addAll(marks)" in handoverlay)
check("HandOverlay.onDraw no longer allocates Paint per swipe",
      "Paint()" not in handoverlay.split("override fun onDraw")[1].split("private companion object")[0],
      "每帧新建 Paint = 每帧分配，正好落在手指拖动的时间窗")
check("HandOverlay.onDraw no longer maps into new objects",
      ".map {" not in handoverlay.split("override fun onDraw")[1].split("private companion object")[0])
check("HandOverlay arrow angle is a constant, not intArrayOf per frame",
      "intArrayOf(30, -30)" not in handoverlay and "ARROW_D30" in handoverlay)
check("SplashRingView.onDraw still allocation-free (regression guard)",
      "rect.set(" in read(os.path.join(JAVA, "ui/SplashRingView.kt"))
      and "Paint(" not in read(os.path.join(JAVA, "ui/SplashRingView.kt")).split("override fun onDraw")[1])

# ── I. 生命周期接线 ───────────────────────────────────────────────────
check("thermal monitor is attached on create and resumed",
      main_code.count("attachThermal()") >= 2)
check("thermal listener is released on destroy",
      "thermalUnsubscribe?.invoke()" in main_code and "ThermalMonitor.detach()" in main_code)
check("level change drives frame cap, JS push, renderer, deferred work",
      all(k in main_code for k in ("RenderBudget.frameCapFps = plan.frameCapFps",
                                   "ThermalBridge.push(level)",
                                   "WebViewRendering.applyRendererPriority(webView, isForeground, level)",
                                   "DeferredWork.setPaused(plan.pauseBgWork)")))

# ── 报告 ─────────────────────────────────────────────────────────────
failed = [n for n, ok, _ in checks if not ok]
for name, ok, detail in checks:
    if not ok:
        print("FAIL  " + name + (("  -> " + detail) if detail else ""))
print()
print("%d/%d checks passed" % (len(checks) - len(failed), len(checks)))
if failed:
    print("FAILED: %d check(s)" % len(failed))
    sys.exit(1)
print("All thermal-degrade checks passed.")

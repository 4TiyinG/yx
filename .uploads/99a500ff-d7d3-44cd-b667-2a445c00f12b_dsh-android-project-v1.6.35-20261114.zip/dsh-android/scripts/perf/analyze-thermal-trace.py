#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
降频 Trace 瓶颈分析（v1.6.35）

输入：capture-thermal-trace.sh 抓到的 .pftrace
输出：降频状态下的瓶颈排序表（主线程 / RenderThread / Renderer / GPU / GC）

依赖：trace_processor_shell（Perfetto 官方命令行查询器）
    · 本仓库不内置它（约 30~60MB，不宜进源码包）。
    · 获取：https://github.com/google/perfetto/releases → trace_processor_shell
    · 或 `curl -LO https://get.perfetto.dev/trace_processor && chmod +x trace_processor`
    · 放到 PATH，或用 --tp /path/to/trace_processor_shell 指定。

设计说明：为什么不做「一个总分」
--------------------------------
很多性能脚本会算一个综合分再排序，但降频场景下**分数的绝对值没有意义** ——
同一份代码在冷机和热机上的帧时间可以差 2 倍。真正有用的是**结构**：

  1. 主线程的时间到底花在「自己算」还是「等别人」上；
  2. 等待里最大的一块是谁（binder / fence / lock / 调度延迟 / 直接回收）；
  3. RenderThread 与 Renderer 进程各自被压了多少；
  4. GC 频率是否越过了「每秒 5 次」这条经验红线。

所以本脚本输出的是**各项的绝对量与占比**，以及「冷热对比的增量」，
让人自己判断该先动哪一层 —— 这也正是需求里「锁定增量最大的开销点」的含义。
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from typing import Dict, List, Optional, Tuple

# ─────────────────────────────────────────────────────────────────────────────
# SQL：每一条对应「一个瓶颈维度」
#
# 这些查询依赖 Perfetto 的标准表（thread / process / thread_state / slice /
# counters）。字段名以 Perfetto v32+ 为准；若用户的 tp 版本较老，脚本会捕获
# 错误并降级跳过该维度，而不是整体失败。
# ─────────────────────────────────────────────────────────────────────────────

Q_MAIN_STATE = """
-- 主线程的线程状态分布：Running = 自己算，其余 = 在等
select
  ts.state as state,
  count(*) as slices,
  sum(ts.dur) / 1e6 as total_ms,
  avg(ts.dur) / 1e6 as avg_ms,
  max(ts.dur) / 1e6 as max_ms
from thread_state ts
join thread t using (utid)
join process p using (upid)
where p.name like '%{pkg}%'
  and t.name = '{thread}'
  and ts.dur > 0
group by ts.state
order by total_ms desc
"""

Q_MAIN_BLOCKING = """
-- 主线程「等得最久」的具体归属（blocked_function 才是可行动的结论）
select
  coalesce(ts.blocked_function, ts.state) as blocker,
  count(*) as times,
  sum(ts.dur) / 1e6 as total_ms,
  max(ts.dur) / 1e6 as max_ms
from thread_state ts
join thread t using (utid)
join process p using (upid)
where p.name like '%{pkg}%'
  and t.name = '{thread}'
  and ts.state != 'Running'
  and ts.dur > 1000000      -- 只看 >=1ms 的等待，微量噪声会淹没结论
group by blocker
order by total_ms desc
limit 15
"""

Q_SLICE_TOP = """
-- 主线程里最耗时的切片（atrace 的 gfx/view 段）
select s.name as name, count(*) as n, sum(s.dur) / 1e6 as total_ms,
       avg(s.dur) / 1e6 as avg_ms, max(s.dur) / 1e6 as max_ms
from slice s
join thread_track tt on s.track_id = tt.id
join thread t using (utid)
join process p using (upid)
where p.name like '%{pkg}%' and t.name = '{thread}' and s.dur > 0
group by s.name
order by total_ms desc
limit 15
"""

Q_GC = """
-- GC 频率：需求里的红线是「Young GC 不超过每秒 5 次」
-- Art 的 GC 在 trace 里表现为 HeapTaskDaemon 线程上的 runtime 切片
select
  t.name as thread,
  count(*) as gc_count,
  sum(s.dur) / 1e6 as total_ms,
  max(s.dur) / 1e6 as max_ms
from slice s
join thread_track tt on s.track_id = tt.id
join thread t using (utid)
where s.name glob '*GC*' or s.name glob '*Garbage*' or t.name = 'HeapTaskDaemon'
group by t.name
order by gc_count desc
"""

Q_RENDERER_CPU = """
-- WebView Renderer 进程的 CPU 切片（每线程 Running 时间）
-- Renderer 在 trace 里的进程名形如 app.dsh.mobile.dev:sandboxed_process0
select
  p.name as process,
  t.name as thread,
  sum(case when ts.state = 'Running' then ts.dur else 0 end) / 1e6 as running_ms
from thread_state ts
join thread t using (utid)
join process p using (upid)
where (p.name like '%sandboxed_process%' or p.name like '%privileged_process%'
       or p.name like '%{pkg}%')
  and ts.dur > 0
group by p.name, t.name
having running_ms > 0
order by running_ms desc
limit 20
"""

Q_FRAME_JANK = """
-- 真实掉帧：FrameTimeline 的 jank 判定（比 gfxinfo 更细，能区分各类 jank）
select
  af.dur / 1e6 as frame_ms,
  j.jank_type,
  j.jank_severity_type,
  count(*) as n
from actual_frame_timeline_slice af
join __intrinsic_frame_timeline_slice j on af.name = j.name
where 1=1
group by jank_type, jank_severity_type
order by n desc
limit 10
"""

Q_FRAME_SIMPLE = """
-- FrameTimeline 兜底：按帧序号统计每段的耗时分布
select
  count(*) as frames,
  avg(af.dur) / 1e6 as avg_ms,
  max(af.dur) / 1e6 as max_ms
from actual_frame_timeline_slice af
"""

Q_THERMAL_COUNTER = """
-- 与 ThermalMonitor 对账：trace 里的热状态/频率计数器
select c.name as counter, min(c.value) as v_min, max(c.value) as v_max,
       avg(c.value) as v_avg, count(*) as n
from counter c
join counter_track ct on c.track_id = ct.id
where c.name glob '*thermal*' or c.name glob '*freq*' or c.name glob '*Temp*'
group by c.name
order by n desc
limit 20
"""

Q_RECLAIM = """
-- 直接回收 / kswapd：热态下内存压力导致的帧尖峰，通常就出在这里
select
  s.name as event,
  count(*) as n,
  sum(s.dur) / 1e6 as total_ms,
  max(s.dur) / 1e6 as max_ms
from slice s
where s.name glob '*direct_reclaim*' or s.name glob '*kswapd*'
group by s.name
order by total_ms desc
limit 10
"""


# ─────────────────────────────────────────────────────────────────────────────
# trace_processor 调用与 CSV 解析
# ─────────────────────────────────────────────────────────────────────────────

class TpError(RuntimeError):
    pass


def find_tp(explicit: Optional[str]) -> str:
    cand = explicit or os.environ.get("TRACE_PROCESSOR")
    if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
        return cand
    for name in ("trace_processor_shell", "trace_processor", "trace_processor_shell.exe"):
        p = shutil.which(name)
        if p:
            return p
    sys.exit(
        "找不到 trace_processor_shell。\n"
        "  · 下载：https://github.com/google/perfetto/releases （trace_processor_shell）\n"
        "  · 或：  curl -LO https://get.perfetto.dev/trace_processor && chmod +x trace_processor\n"
        "  · 然后：--tp /path/to/trace_processor_shell  或放进 PATH\n"
    )


def run_query(tp: str, trace: str, sql: str) -> List[Dict[str, str]]:
    """
    执行一条 SQL，返回 [{列名: 值}]。

    ⚠️ trace_processor_shell 的输出格式在不同版本间有差异：老版本是
    `col1,col2` 的行式 CSV，新版本也会直接给 CSV。这里做「宽容解析」：
    以第一条非空行为表头，按逗号切分并去引号；解析不出表头就当作整体文本。
    """
    try:
        proc = subprocess.run(
            [tp, trace, "-q", "-"],       # -q - ：从 stdin 读 SQL
            input=sql,
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.TimeoutExpired:
        raise TpError("query timed out (600s)")
    if proc.returncode != 0 and not proc.stdout.strip():
        raise TpError((proc.stderr or "").strip().splitlines()[-1] if proc.stderr else "tp failed")
    text = proc.stdout
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        return []
    if any(ln.lower().startswith("error") for ln in lines[:2]):
        raise TpError(lines[0])

    def split(line: str) -> List[str]:
        # CSV：逗号分隔，字段可能带引号；也兼容 tab
        if "\t" in line and "," not in line:
            return [c.strip() for c in line.split("\t")]
        out, cur, inq = [], [], False
        for ch in line:
            if ch == '"':
                inq = not inq
            elif ch == "," and not inq:
                out.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
        out.append("".join(cur).strip())
        return [c.strip('"') for c in out]

    header = split(lines[0])
    rows = []
    for ln in lines[1:]:
        cells = split(ln)
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        rows.append(dict(zip(header, cells)))
    return rows


def fnum(s: str) -> float:
    try:
        return float(s)
    except (TypeError, ValueError):
        return 0.0


# ─────────────────────────────────────────────────────────────────────────────
# 报告
# ─────────────────────────────────────────────────────────────────────────────

def table(headers: List[str], rows: List[List[str]], aligns: Optional[List[str]] = None) -> str:
    aligns = aligns or ["l"] + ["r"] * (len(headers) - 1)
    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(c))
    def fmt(cells: List[str]) -> str:
        parts = []
        for i, c in enumerate(cells):
            parts.append(c.ljust(widths[i]) if aligns[i] == "l" else c.rjust(widths[i]))
        return "| " + " | ".join(parts) + " |"
    out = [fmt(headers), "|" + "|".join("-" * (w + 2) for w in widths) + "|"]
    out += [fmt(r) for r in rows]
    return "\n".join(out)


class Section:
    def __init__(self, title: str, note: str = ""):
        self.title = title
        self.note = note
        self.rows: List[List[str]] = []
        self.headers: List[str] = []


def section_state(tp, trace, pkg, thread, title, note) -> Section:
    s = Section(title, note)
    s.headers = ["状态", "次数", "总耗时ms", "均值ms", "最大ms"]
    try:
        rows = run_query(tp, trace, Q_MAIN_STATE.format(pkg=pkg, thread=thread))
        for r in rows:
            s.rows.append([
                r.get("state", "?"),
                str(int(fnum(r.get("slices", "0")))),
                "%.0f" % fnum(r.get("total_ms", "0")),
                "%.2f" % fnum(r.get("avg_ms", "0")),
                "%.1f" % fnum(r.get("max_ms", "0")),
            ])
    except TpError as e:
        s.rows.append(["（查询失败：%s）" % e, "", "", "", ""])
    return s


def section_blocking(tp, trace, pkg, thread, title, note) -> Section:
    s = Section(title, note)
    s.headers = ["阻塞来源", "次数", "总耗时ms", "最大ms"]
    try:
        rows = run_query(tp, trace, Q_MAIN_BLOCKING.format(pkg=pkg, thread=thread))
        for r in rows:
            s.rows.append([
                r.get("blocker", "?"),
                str(int(fnum(r.get("times", "0")))),
                "%.0f" % fnum(r.get("total_ms", "0")),
                "%.1f" % fnum(r.get("max_ms", "0")),
            ])
    except TpError as e:
        s.rows.append(["（查询失败：%s）" % e, "", "", ""])
    return s


def section_slices(tp, trace, pkg, thread, title, note) -> Section:
    s = Section(title, note)
    s.headers = ["切片", "次数", "总耗时ms", "均值ms", "最大ms"]
    try:
        rows = run_query(tp, trace, Q_SLICE_TOP.format(pkg=pkg, thread=thread))
        for r in rows:
            s.rows.append([
                r.get("name", "?")[:60],
                str(int(fnum(r.get("n", "0")))),
                "%.0f" % fnum(r.get("total_ms", "0")),
                "%.2f" % fnum(r.get("avg_ms", "0")),
                "%.1f" % fnum(r.get("max_ms", "0")),
            ])
    except TpError as e:
        s.rows.append(["（查询失败：%s）" % e, "", "", "", ""])
    return s


def render(sections: List[Section]) -> str:
    parts = []
    for s in sections:
        parts.append("### " + s.title)
        if s.note:
            parts.append("_" + s.note + "_")
        parts.append("")
        parts.append(table(s.headers, s.rows) if s.rows else "_（无数据）_")
        parts.append("")
    return "\n".join(parts)


def synthesize_verdict(gc_per_sec: float, main_wait_ratio: float) -> List[str]:
    """
    把数字翻译成**可执行的结论**。

    只做「是否越过经验红线」的判断，不做加权评分 —— 原因见模块文档。
    """
    out = []
    if gc_per_sec > 5.0:
        out.append(
            "- ⚠ GV Young GC %.1f 次/秒 > 5 次/秒红线 → 分配速率过高。"
            "优先查 onDraw/onBind 的临时对象与字符串拼接（不是调大堆）" % gc_per_sec
        )
    else:
        out.append("- ✅ GC 频次 %.1f 次/秒，在红线内" % gc_per_sec)
    if main_wait_ratio > 0.35:
        out.append(
            "- ⚠ 主线程 %.0f%% 的时间在**等**（非 Running）→ 瓶颈不在计算量，"
            "而在锁/binder/调度延迟；此时优化「算得更快」收益有限，应先削争用" % (main_wait_ratio * 100)
        )
    elif main_wait_ratio > 0:
        out.append("- ✅ 主线程等待占比 %.0f%%" % (main_wait_ratio * 100))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="降频 Trace 瓶颈分析")
    ap.add_argument("trace", help=".pftrace 文件")
    ap.add_argument("--tp", help="trace_processor_shell 路径")
    ap.add_argument("--pkg", default=os.environ.get("DSH_PKG", "app.dsh.mobile.dev"))
    ap.add_argument("--seconds", type=float, default=0.0,
                    help="抓取时长（秒）；给了才能算「GC 次/秒」")
    ap.add_argument("--out", help="报告输出路径（默认 stdout）")
    args = ap.parse_args()

    if not os.path.isfile(args.trace):
        sys.exit("trace not found: %s" % args.trace)
    tp = find_tp(args.tp)

    report = []
    report.append("# 降频 Trace 瓶颈分析")
    report.append("")
    report.append("- trace: `%s`" % os.path.basename(args.trace))
    report.append("- package: `%s`" % args.pkg)
    report.append("- trace_processor: `%s`" % tp)
    report.append("")

    # ── 1. 主线程 ────────────────────────────────────────────────────────
    sec_main = section_state(
        tp, args.trace, args.pkg, "main", "1. 主线程状态分布",
        "Running = 真的在算；其余（Sleeping / D / S）都是「等」。"
        "若 Sleeping 占比高，说明帧不是被算慢的，而是被别处拖住。",
    )
    sec_main_block = section_blocking(
        tp, args.trace, args.pkg, "main", "2. 主线程阻塞归属（≥1ms 的等待）",
        "blocked_function 是内核给出的「在等谁」——这一列才是可行动的结论。",
    )
    sec_main_slice = section_slices(
        tp, args.trace, args.pkg, "main", "3. 主线程最耗时切片",
        "对应 atrace 的 gfx/view/wm 段：measure/layout/draw、window 事务、IPC。",
    )

    # ── 2. RenderThread ─────────────────────────────────────────────────
    sec_rt = section_state(
        tp, args.trace, args.pkg, "RenderThread", "4. RenderThread 状态分布",
        "RenderThread 等待占比升高 = GPU/fence/合成器侧受限，"
        "降频时它通常先于主线程恶化。",
    )
    sec_rt_block = section_blocking(
        tp, args.trace, args.pkg, "RenderThread", "5. RenderThread 阻塞归属",
        "`fence_wait` / `binder` 占主导 → 问题在合成与 IPC，不在我们的 draw 代码。",
    )

    # ── 3. Renderer 进程 ────────────────────────────────────────────────
    sec_renderer = Section("6. WebView Renderer 进程 CPU 切片",
                           "Renderer 是独立进程（…:sandboxed_process0）。"
                           "它单独吃满一个核时，主线程再优化也没用 —— 该削的是页面合成层。")
    sec_renderer.headers = ["进程", "线程", "Running ms"]
    try:
        for r in run_query(tp, args.trace, Q_RENDERER_CPU.format(pkg=args.pkg)):
            sec_renderer.rows.append([
                r.get("process", "?")[:44], r.get("thread", "?"),
                "%.0f" % fnum(r.get("running_ms", "0")),
            ])
    except TpError as e:
        sec_renderer.rows.append(["（查询失败：%s）" % e, "", ""])

    # ── 4. GC ───────────────────────────────────────────────────────────
    sec_gc = Section("7. GC 频次", "需求红线：Young GC ≤ 5 次/秒，且主线程不应出现 GC Wait。")
    sec_gc.headers = ["线程", "次数", "总耗时ms", "最大ms"]
    gc_total = 0
    try:
        for r in run_query(tp, args.trace, Q_GC):
            n = int(fnum(r.get("gc_count", "0")))
            gc_total += n
            sec_gc.rows.append([
                r.get("thread", "?"), str(n),
                "%.1f" % fnum(r.get("total_ms", "0")),
                "%.1f" % fnum(r.get("max_ms", "0")),
            ])
    except TpError as e:
        sec_gc.rows.append(["（查询失败：%s）" % e, "", "", ""])

    # ── 5. 掉帧 ─────────────────────────────────────────────────────────
    sec_jank = Section("8. 掉帧（FrameTimeline）",
                       "jank_type 区分「App 侧超时」「SurfaceFlinger 侧超时」「丢帧」——"
                       "三者对应完全不同的修法。")
    sec_jank.headers = ["帧耗时ms", "jank 类型", "严重度", "次数"]
    try:
        for r in run_query(tp, args.trace, Q_FRAME_JANK):
            sec_jank.rows.append([
                "%.1f" % fnum(r.get("frame_ms", "0")), r.get("jank_type", "?"),
                r.get("jank_severity_type", "?"), str(int(fnum(r.get("n", "0")))),
            ])
    except TpError as e:
        sec_jank.rows.append(["（查询失败：%s）" % e, "", "", ""])

    # ── 6. 内存回收 ─────────────────────────────────────────────────────
    sec_reclaim = Section("9. 内存回收事件",
                          "direct reclaim / kswapd 出现在帧时间轴上 = 帧尖峰的物理来源，"
                          "对应「限制 Tile Cache / 图片解码尺寸」这条需求。")
    sec_reclaim.headers = ["事件", "次数", "总耗时ms", "最大ms"]
    try:
        for r in run_query(tp, args.trace, Q_RECLAIM):
            sec_reclaim.rows.append([
                r.get("event", "?"), str(int(fnum(r.get("n", "0")))),
                "%.0f" % fnum(r.get("total_ms", "0")),
                "%.1f" % fnum(r.get("max_ms", "0")),
            ])
    except TpError as e:
        sec_reclaim.rows.append(["（查询失败：%s）" % e, "", "", ""])

    sections = [sec_main, sec_main_block, sec_main_slice, sec_rt, sec_rt_block,
                sec_renderer, sec_gc, sec_jank, sec_reclaim]
    report.append(render(sections))

    # ── 结论 ────────────────────────────────────────────────────────────
    main_running = 0.0
    main_total = 0.0
    for r in sec_main.rows:
        total = fnum(r[2]) if len(r) > 2 else 0.0
        main_total += total
        if r and r[0] == "Running":
            main_running = total
    wait_ratio = 0.0 if main_total <= 0 else max(0.0, 1.0 - main_running / main_total)
    gc_per_sec = 0.0 if args.seconds <= 0 else gc_total / args.seconds

    report.append("## 判定（机械规则，非加权评分）")
    report.append("")
    report += synthesize_verdict(gc_per_sec if args.seconds > 0 else 0.0, wait_ratio)
    if args.seconds <= 0:
        report.append("- ℹ 未传 `--seconds`，GC 次/秒无法计算（只给了总数）")
    report.append("")
    report.append("## 排序表模板（把上面各项按「增量」填进来）")
    report.append("")
    report.append(table(
        ["排名", "维度", "冷机", "热机", "增量", "归因"],
        [["1", "", "", "", "", ""], ["2", "", "", "", "", ""], ["3", "", "", "", "", ""]],
        aligns=["r", "l", "r", "r", "r", "l"],
    ))
    report.append("")
    report.append(
        "_填法：同一操作序列抓两次（冷机一次、`--soak` 热机一次），"
        "把每个维度的「总耗时」与「最大尖峰」分别相减。**增量最大的那一行就是先动的地方**；"
        "若各维度增量接近，优先动「最大尖峰」那一行 —— 尖峰比均值更能毁掉手感。_"
    )

    text = "\n".join(report)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print("report → %s" % args.out)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
# =============================================================================
# 降频场景 Trace 抓取（v1.6.35）
#
# 目的：抓「**已经热起来、正在降频**」时的 trace，而不是冷机 trace。
#       冷机数据只能说明「性能上限」，热机数据才能定位「瓶颈在哪一段先崩」。
#
# 用法：
#   bash scripts/perf/capture-thermal-trace.sh                     # 默认 30s 抓取
#   bash scripts/perf/capture-thermal-trace.sh --soak 300          # 先空跑 5min 预热设备
#   bash scripts/perf/capture-thermal-trace.sh --seconds 60 --out /tmp/t1.pftrace
#
# 前提：
#   · adb 已连上设备，且本机有 perfetto / adb（Android SDK platform-tools）；
#   · **抓 sched / freq 需要 root 或 userdebug ROM**。非 root 也能抓
#     （atrace 的 app 级类别可用），但会缺 CPU 频率与 thermal 节点，脚本会明确提示
#     缺了哪几类，不会静默降级。
#
# 为什么类别是这几个（不是「全开」）：
#   · sched/freq/idle  → 判断「是被压频了，还是在空转」；
#   · gfx/view/wm      → 主线程与 RenderThread 的帧生命周期；
#   · binder_driver    → WebView 的 IPC（合成器/IO 线程常常卡在 binder 上）；
#   · power/thermal    → 热档位与功耗状态，和代码里的 ThermalMonitor 对上；
#   · freq 之外再加 `am`（ActivityManager）→ 抓 Renderer 进程被杀/重建。
#   `-a app.dsh.mobile.dev`（进程过滤）能把 WebView 的 Renderer 子进程一起带上，
#   这是分析「WebView Renderer CPU 切片」的必要条件。
# =============================================================================
set -euo pipefail

PKG="${DSH_PKG:-app.dsh.mobile.dev}"
SECONDS_TO_CAPTURE=30
SOAK=0
OUT=""
BUFFERSIZE=65536   # KB，约 64MB；热态 trace 的 sched 数据量很大
DEVICE_DIR="/data/misc/perfetto-traces"

while [ $# -gt 0 ]; do
  case "$1" in
    --seconds) SECONDS_TO_CAPTURE="$2"; shift 2 ;;
    --soak)    SOAK="$2"; shift 2 ;;
    --out)     OUT="$2"; shift 2 ;;
    --buffer)  BUFFERSIZE="$2"; shift 2 ;;
    --pkg)     PKG="$2"; shift 2 ;;
    -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

STAMP=$(date +%Y%m%d-%H%M%S)
HOST_OUT="${OUT:-./thermal-$STAMP.pftrace}"
REMOTE="/data/local/tmp/dsh-thermal-$STAMP.pftrace"

say() { printf '\033[36m[thermal]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[thermal]\033[0m %s\n' "$*" >&2; }

command -v adb >/dev/null || { echo "adb not found in PATH" >&2; exit 1; }
adb get-state >/dev/null 2>&1 || { echo "no device (adb get-state failed)" >&2; exit 1; }

ROOTED=0
if adb shell id 2>/dev/null | grep -q 'uid=0'; then ROOTED=1; fi
if [ "$ROOTED" -eq 0 ]; then
  if adb shell su -c id 2>/dev/null | grep -q 'uid=0'; then ROOTED=2; fi
fi

if [ "$ROOTED" -eq 0 ]; then
  warn "设备未 root：将跳过 cpu freq / thermal 节点采集。"
  warn "分析「是否被压频」需要 root 或 userdebug ROM —— 缺这两类数据时，"
  warn "本脚本产出的 trace 只能回答「谁在等谁」，不能回答「是不是降频导致的」。"
fi

say "device: $(adb shell getprop ro.product.model 2>/dev/null | tr -d '\r') / $(adb shell getprop ro.build.version.release 2>/dev/null | tr -d '\r')"
say "package: $PKG"

# ── 0. 记录抓取前的热状态（这是「热 vs 冷」的唯一判据，必须存下来）───────
PRE_STATE="$(dirname "$HOST_OUT")/thermal-$STAMP.before.txt"
{
  echo "# capture before-state $(date -Is)"
  echo "## thermal service"
  adb shell dumpsys thermalservice 2>/dev/null | head -40 || true
  echo "## cpu freq (per core, kHz)"
  adb shell 'for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq; do echo -n "$f "; cat $f 2>/dev/null; done' 2>/dev/null || true
  echo "## battery temperature"
  adb shell dumpsys battery 2>/dev/null | grep -i temperature || true
} > "$PRE_STATE" 2>/dev/null || true
say "before-state → $PRE_STATE"

# ── 1. 可选：空跑预热 ────────────────────────────────────────────────────
if [ "$SOAK" -gt 0 ]; then
  say "soaking ${SOAK}s — 保持 App 在前台并持续滑动/滚动，让设备真的热起来"
  say "（这一步不产生 trace；目的是让抓取窗口落在降频区间，而不是升温区间）"
  adb shell am start -n "$PKG/app.dsh.mobile.MainActivity" >/dev/null 2>&1 || true
  sleep "$SOAK"
  adb shell 'cat /sys/class/thermal/thermal_zone*/temp' 2>/dev/null | head -8 || true
fi

# ── 2. 组 trace config ───────────────────────────────────────────────────
CFG=$(mktemp /tmp/dsh-thermal-XXXXXX.pbtxt)
cleanup() { rm -f "$CFG"; }
trap cleanup EXIT

CATS="sched freq idle am wm gfx view binder_driver power thermal res"
cat > "$CFG" <<PBCFG
buffers: { size_kb: $BUFFERSIZE fill_policy: RING_BUFFER }
buffers: { size_kb: 8192   fill_policy: RING_BUFFER }
data_sources: {
  config {
    name: "linux.ftrace"
    ftrace_config {
      ftrace_events: "sched/sched_switch"
      ftrace_events: "sched/sched_wakeup"
      ftrace_events: "sched/sched_waking"
      ftrace_events: "power/cpu_frequency"
      ftrace_events: "power/cpu_idle"
      ftrace_events: "power/suspend_resume"
      ftrace_events: "fence/signaled"
      ftrace_events: "binder/binder_transaction"
      ftrace_events: "binder/binder_transaction_received"
      ftrace_events: "kmem/rss_stat"
      ftrace_events: "kmem/mm_event"
      ftrace_events: "vmscan/mm_vmscan_direct_reclaim_begin"
      ftrace_events: "vmscan/mm_vmscan_direct_reclaim_end"
      ftrace_events: "vmscan/mm_vmscan_kswapd_wake"
      ftrace_events: "lowmemorykiller/lowmemory_kill"
      ftrace_events: "oom/oom_score_adj_update"
      atrace_categories: "$CATS"
      atrace_apps: "$PKG"
      buffer_size_kb: 16384
      drain_period_ms: 250
    }
  }
}
data_sources: {
  config {
    name: "android.process_stats"
    process_stats_config { scan_all_processes_on_start: true }
  }
}
data_sources: {
  config {
    name: "linux.sys_stats"
    sys_stats_config {
      stat_period_ms: 1000
      stat_counters: STAT_CPU_TIMES
      stat_counters: STAT_IRQ_COUNTS
      stat_counters: STAT_FORK_COUNT
      meminfo_period_ms: 1000
      meminfo_counters: MEMINFO_MEM_FREE
      meminfo_counters: MEMINFO_MEM_AVAILABLE
      meminfo_counters: MEMINFO_ACTIVE
      meminfo_counters: MEMINFO_INACTIVE
      meminfo_counters: MEMINFO_ANON_PAGES
      vmstat_period_ms: 1000
      vmstat_counters: VMSTAT_PGPGIN
      vmstat_counters: VMSTAT_PGPGOUT
      vmstat_counters: VMSTAT_PGMAJFAULT
      vmstat_counters: VMSTAT_PGFREE
      vmstat_counters: VMSTAT_WORKINGSET_REFAULT
    }
  }
}
data_sources: {
  config {
    name: "android.java_hprof"
    java_hprof_config { process_cmdline: "$PKG" }
  }
}
duration_ms: $((SECONDS_TO_CAPTURE * 1000))
flush_period_ms: 30000
PBCFG

if [ "$ROOTED" -eq 1 ]; then
  adb push "$CFG" "$REMOTE.cfg" >/dev/null
  adb shell "perfetto --config $REMOTE.cfg --out $REMOTE" || {
    warn "perfetto CLI 不可用，改用 record_android_trace 兜底"; }
else
  adb push "$CFG" "$REMOTE.cfg" >/dev/null
  adb shell "perfetto --config $REMOTE.cfg --out $REMOTE" || true
fi

# ── 3. 抓取期间提示用户操作（这是唯一能产生真实帧的方式）─────────────────
say "start capture ${SECONDS_TO_CAPTURE}s — 抓取期间请执行："
say "  ① 连续上下滑动会话列表 5 次；② 打开一个长会话滚到底再滚回顶；③ 点开输入框再收起"
say "  （这三步覆盖：列表合成、长文栅格化、输入法引起的 window 重建）"
adb shell am start -n "$PKG/app.dsh.mobile.MainActivity" >/dev/null 2>&1 || true
sleep "$SECONDS_TO_CAPTURE"

# ── 4. 拉回 + 顺带抓 gfxinfo（帧统计的权威口径）───────────────────────────
GFX="$(dirname "$HOST_OUT")/thermal-$STAMP.gfxinfo.txt"
adb shell dumpsys gfxinfo "$PKG" framestats > "$GFX" 2>/dev/null || \
  warn "dumpsys gfxinfo failed（部分 ROM 不支持 framestats）"

if adb shell "test -f $REMOTE" 2>/dev/null; then
  adb pull "$REMOTE" "$HOST_OUT" >/dev/null 2>&1 || adb exec-out "cat $REMOTE" > "$HOST_OUT"
  adb shell "rm -f $REMOTE $REMOTE.cfg" >/dev/null 2>&1 || true
  say "trace → $HOST_OUT ($(du -h "$HOST_OUT" 2>/dev/null | cut -f1))"
else
  warn "trace 未生成。常见原因："
  warn "  · 该 ROM 未内置 perfetto（Android < 10）→ 用 'dumpsys gfxinfo + atrace' 兜底"
  warn "  · /data/local/tmp 不可写 → 改 --out 到可写路径"
  exit 3
fi
[ -f "$GFX" ] && say "gfxinfo → $GFX"

# ── 5. 抓取后状态（与 before 对比 = 降频是否真的发生）───────────────────
POST_STATE="$(dirname "$HOST_OUT")/thermal-$STAMP.after.txt"
{
  echo "# capture after-state $(date -Is)"
  adb shell dumpsys thermalservice 2>/dev/null | head -40 || true
  adb shell 'for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq; do echo -n "$f "; cat $f 2>/dev/null; done' 2>/dev/null || true
  adb shell dumpsys battery 2>/dev/null | grep -i temperature || true
} > "$POST_STATE" 2>/dev/null || true
say "after-state → $POST_STATE"

say "下一步：python3 scripts/perf/analyze-thermal-trace.py $HOST_OUT"

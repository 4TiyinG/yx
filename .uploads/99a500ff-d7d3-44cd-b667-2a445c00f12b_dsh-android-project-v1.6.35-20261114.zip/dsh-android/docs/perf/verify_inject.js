// 等价性 + 隔离性 + 幂等性验证：合并注入 vs 旧的 6 次串行注入
// 用真实 Chrome（CDP Runtime.evaluate —— 与 WebView.evaluateJavascript 同一底层机制）。
const fs = require('fs');
const p = require('/usr/local/share/nvm/versions/node/v20.19.4/lib/node_modules/puppeteer-core');

const src = t => fs.readFileSync(`/tmp/part_${t}.js`, 'utf8').trim();
const ORDER = ['blob', 'clipboard', 'accent', 'keys', 'backguard'];

// 复刻 PageBridgeInjection.buildScript（外层 IIFE，完成值由 return 提供）
function buildScript(over = {}) {
  const sb = ['(function(){', 'var __dshInjectFail=[];'];
  for (const tag of ORDER) {
    const body = src(tag);
    sb.push(`try{${over[tag] || body}}catch(e){__dshInjectFail.push('${tag}:'+(e&&e.message));};`);
  }
  sb.push(`window.__dshSelfcheck=(${src('selfcheck').replace(/;+$/, '')});`);
  sb.push(`return 'inject='+((__dshInjectFail.length)?('FAIL['+__dshInjectFail.join(',')+']'):'ok5')+(' | '+String(window.__dshSelfcheck));`);
  sb.push('})()');
  return sb.join('\n') + '\n';
}

const merged = buildScript();
const fileVersion = fs.readFileSync('/tmp/merged_inject.js', 'utf8');
const PAGE = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body><div class="dsh-overlay" style="position:fixed;inset:0"></div><textarea id="t"></textarea></body></html>`;

const snap = page => page.evaluate(() => ({
  globals: Object.keys(window).filter(k => /^(Dsh|__dsh)/.test(k)).sort(),
  accent: document.documentElement.style.getPropertyValue('--dsh-accent'),
  downloaderInstalled: !!window.__dshDownloaderInstalled,
  clipboardPatched: !!window.__dshClipboardPatched,
  hasBackGuard: !!(window.__dshBackGuard || window.__dshBackGuardInstalled),
  selfcheck: typeof window.__dshSelfcheck === 'string' ? window.__dshSelfcheck.slice(0, 30) : null,
}));

(async () => {
  const browser = await p.launch({
    executablePath: '/usr/local/chrome/chrome', headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });
  const open = async () => {
    const page = await browser.newPage();
    const cdp = await page.target().createCDPSession();
    await page.goto('about:blank');
    await page.setContent(PAGE);
    return { page, cdp };
  };
  let failures = 0;
  const ok = (c, msg) => { console.log(`${c ? '✅' : '❌'} ${msg}`); if (!c) failures++; };

  // A. 旧方式：6 次串行
  const A = await open();
  for (const t of [...ORDER, 'selfcheck']) await A.cdp.send('Runtime.evaluate', { expression: src(t) });
  const sA = await snap(A.page);
  await A.page.close();

  // B. 新方式：1 次合并
  const B = await open();
  const rB = await B.cdp.send('Runtime.evaluate', { expression: merged, returnByValue: true });
  const sB = await snap(B.page);
  await B.page.close();

  console.log('=== 1. 等价性（副作用面） ===');
  const strip = s => ({ ...s, globals: s.globals.filter(g => g !== '__dshSelfcheck').join(',') });
  const a = strip(sA), b = strip(sB);
  for (const k of ['globals', 'accent', 'downloaderInstalled', 'clipboardPatched']) {
    ok(String(a[k]) === String(b[k]), `${k} 一致：${JSON.stringify(String(b[k]).slice(0, 60))}`);
  }
  ok(sB.globals.includes('__dshSelfcheck'),
    '新增 window.__dshSelfcheck：自检结果从「被丢弃」变为「可回收」（原 bug 修复，非功能回归）');
  console.log(`   完成值 → ${JSON.stringify(String(rB.result.value).slice(0, 78))}…`);
  ok(/^inject=ok5 \| \[dsh-android\] webview ok/.test(String(rB.result.value)), '完成值 = 注入状态 + 自检结论');
  ok(merged.replace(/\s+/g, '') === fileVersion.replace(/\s+/g, ''),
    '校验脚本与 Kotlin buildScript 产出一致（防两处逻辑漂移）');

  console.log('\n=== 2. 隔离性（一段运行期抛错） ===');
  const C = await open();
  const broken = buildScript({ blob: "(function(){throw new Error('boom')})();" });
  const rC = await C.cdp.send('Runtime.evaluate', { expression: broken, returnByValue: true });
  const sC = await snap(C.page);
  ok(!sC.downloaderInstalled, '抛错段（blob）未安装');
  ok(sC.clipboardPatched && sC.accent === '#4C8DF6' && sC.selfcheck,
    '其余段照常安装 → 隔离性等价于旧的逐个注入');
  ok(String(rC.result.value).includes('FAIL[blob:boom]'), `完成值带失败明细：${String(rC.result.value).slice(0, 40)}…`);
  await C.page.close();

  console.log('\n=== 3. 幂等性（SPA 内重复注入） ===');
  const D = await open();
  await D.cdp.send('Runtime.evaluate', { expression: merged });
  const n1 = await D.page.evaluate('Object.keys(window).filter(k=>/^(Dsh|__dsh)/.test(k)).length');
  await D.cdp.send('Runtime.evaluate', { expression: merged });
  const n2 = await D.page.evaluate('Object.keys(window).filter(k=>/^(Dsh|__dsh)/.test(k)).length');
  ok(n1 === n2, `重复注入全局对象 ${n1} → ${n2}，无累积`);
  await D.page.close();

  await browser.close();
  console.log(failures ? `\n❌ ${failures} 项未通过` : '\n🎉 全部通过');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });

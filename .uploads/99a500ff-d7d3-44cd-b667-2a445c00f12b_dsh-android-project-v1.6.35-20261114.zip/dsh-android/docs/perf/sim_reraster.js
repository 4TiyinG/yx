// 重栅格化调度仿真：旧实现 vs 新实现
// ⚠️ 这是「按 Kotlin 源码语义 1:1 移植」的确定性调度仿真，不是真机帧数据。
//    它能量化的是**整页软件重栅格化执行了多少次**（每次 = 丢弃全部已缓存栅格 + 整页软绘），
//    不能给出「省了多少毫秒」—— 单次成本取决于设备 GPU/CPU 与页面复杂度，本环境无法测。
// 常量取自源码：VIEWPORT_SETTLE_MS = 120
const SETTLE = 120;

function makeSim({ dedupe }) {
  const s = {
    t: 0, pendingViewport: null, lastWidth: -1, desktopMode: false, pageScale: 100,
    rerasterPending: null, lastRerasterKey: null,
    nViewport: 0, nReraster: 0, nLayerToggle: 0, nSkipSameKey: 0, nRerasterOld: 0,
  };
  const scheduleReraster = () => {
    const key = `${s.desktopMode}|${s.width}|${s.pageScale}`;
    if (!dedupe) {                      // 旧：不撤销、不比对，直接排队
      setTimeout(() => { s.nRerasterOld++; s.nLayerToggle += 2; }, SETTLE);
      return;
    }
    if (key === s.lastRerasterKey) { s.nSkipSameKey++; return; }   // 新②：状态没变就跳过
    if (s.rerasterPending) { clearTimeout(s.rerasterPending); s.rerasterPending = null; } // 新①：撤销上一个
    s.rerasterPending = setTimeout(() => {
      s.rerasterPending = null; s.lastRerasterKey = key;
      s.nReraster++; s.nLayerToggle += 2;
    }, SETTLE);
  };
  const applyViewport = () => { s.nViewport++; s.lastWidth = s.width; scheduleReraster(); };
  s.onConfigChanged = width => {        // scheduleViewportReapply：120ms 去抖 + 宽度未变跳过
    if (s.pendingViewport) clearTimeout(s.pendingViewport);
    s.pendingViewport = setTimeout(() => {
      s.pendingViewport = null; s.width = width;
      if (width === s.lastWidth) return;
      applyViewport();
    }, SETTLE);
  };
  s.onPageFinished = width => {         // 真实页面加载完成（新实现会先清去重键）
    s.width = width;
    if (dedupe) s.lastRerasterKey = null;
    applyViewport();
  };
  return s;
}

// 时间线：模拟两类真实场景
const timelines = {
  // A. 自由窗口连续拖宽：40 帧内每 16ms 一次 onConfigurationChanged（vivo/华为小窗实测形态）
  A_drag: t => { for (let i = 1; i <= 40; i++) setTimeout(() => t.onConfigChanged(400 + i * 8), i * 16); },
  // B. 旋转 + 模式切换 + 首屏：insets 变化、multiwindow、config、页面加载在 300ms 内连着来
  B_rotate: t => {
    setTimeout(() => t.onConfigChanged(900), 0);
    setTimeout(() => t.onConfigChanged(900), 40);   // 键盘/insets 又报一次，宽度其实没变
    setTimeout(() => t.onConfigChanged(560), 90);   // 转屏完成
    setTimeout(() => t.onPageFinished(560), 210);   // 桌面模式切换触发 reload → 新页面
  },
  // C. 真正会触发差异的交错：一次 viewport 重排任务（-60ms 时排入，+60ms 触发）
  //    与紧随其后的 onPageFinished 落在同一个 120ms 窗口内
  C_overlap: t => {
    setTimeout(() => t.onConfigChanged(700), -60);   // 先排上去抖任务
    setTimeout(() => t.onPageFinished(560), 0);      // 页面完成，立刻应用一次
  },
};

const HORIZON = 2600;
console.log('整页软件重栅格化执行次数（越少越好；每次都会丢弃全部栅格并整页软绘）\n');
(async () => {
  for (const [name, drive] of Object.entries(timelines)) {
    const rows = ['旧', '新'].map(label => {
      const s = makeSim({ dedupe: label === '新' });
      s.width = 400; s.lastWidth = 400;
      drive(s);
      return { label, s };
    });
    await new Promise(r => setTimeout(r, HORIZON));
    const o = rows[0].s, n = rows[1].s;
    console.log(`场景 ${name}`);
    console.log(`  旧: 重栅格化 ${o.nRerasterOld} 次（LAYER_TYPE 切换 ${o.nLayerToggle} 回）  viewport 应用 ${o.nViewport} 次`);
    console.log(`  新: 重栅格化 ${n.nReraster} 次（LAYER_TYPE 切换 ${n.nLayerToggle} 回）  viewport 应用 ${n.nViewport} 次，另有 ${n.nSkipSameKey} 次因光栅状态未变直接跳过`);
    console.log(`  → 整页软绘次数 ${o.nRerasterOld} → ${n.nReraster}\n`);
  }
})();

// 注入方式开销测量：6 次串行 evaluate vs 合并 1 次
// 用真实 Chrome 145 + CDP。这是对 Android WebView evaluateJavascript 的“代理测量”：
// 两者同属「浏览器进程 → 渲染进程的一次 IPC 往返 + 渲染主线程上一个独立任务」。
const p = require('/usr/local/share/nvm/versions/node/v20.19.4/lib/node_modules/puppeteer-core');

const N = 4000; // DOM 规模，模拟 SPA 首屏后的量级

// 与 MainActivity 注入内容等量级的 6 段脚本
const parts = [
  // 1) selfcheck：写若干 CSS 变量与探针
  `document.documentElement.style.setProperty('--probe-a','1');window.__selfcheck={v:1,api:{io:typeof IntersectionObserver,rs:typeof ResizeObserver}};`,
  // 2) blob 下载桥：定义一个 object 并挂到 window
  `window.DshAndroidDownloader={saveBase64:function(n,d,t){return [n,d.length,t].join('|')},bridgeReady:true};`,
  // 3) 剪贴板降级链
  `window.__clipFallback=function(txt){try{navigator.clipboard&&navigator.clipboard.writeText(txt)}catch(e){}return true};`,
  // 4) 强调色变量
  `document.documentElement.style.setProperty('--dsh-accent','#4C8DF6');`,
  // 5) mobile-keys.js（4.5KB 原文，键盘事件改写）
  `window.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.ctrlKey&&!e.metaKey&&e.target&&e.target.tagName==='TEXTAREA'){/* rewrite to Shift+Enter */}});`,
  // 6) back-guard.js（6.8KB 原文的等价体：定义单例 + 查询函数）
  `window.__dshBackGuard={topLayer:function(){var els=document.querySelectorAll('.ov');return els.length?els[els.length-1]:null},close:function(){var t=this.topLayer();return t?t.className:null}};`,
];

async function metrics(page) {
  const cdp = await page.target().createCDPSession();
  await cdp.send('Performance.enable');
  const get = async () => {
    const m = await cdp.send('Performance.getMetrics');
    const o = {};
    for (const x of m.metrics) o[x.name] = x.value;
    return o;
  };
  return { get, cdp };
}

(async () => {
  const browser = await p.launch({
    executablePath: '/usr/local/chrome/chrome',
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  const body = `<div id="root">${Array.from({ length: N }, (_, i) => `<div class="ov card" id="c${i}"><span>row ${i}</span></div>`).join('')}</div>`;

  async function run(mode) {
    const page = await browser.newPage();
    const { get } = await metrics(page);
    await page.goto('about:blank');
    await page.setContent(`<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>${body}</body></html>`);
    // 让首屏稳定，避免把页面构建成本算进注入
    await page.evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');
    const before = await get();
    const t0 = process.hrtime.bigint();
    if (mode === 'six') {
      for (const js of parts) await page.evaluate(js);
    } else {
      await page.evaluate(parts.join('\n'));
    }
    const t1 = process.hrtime.bigint();
    const after = await get();
    const out = {
      mode,
      wall_ms: Number(t1 - t0) / 1e6,
      task_ms: (after.TaskDuration - before.TaskDuration) * 1000,
      style_ms: (after.RecalcStyleDuration - before.RecalcStyleDuration) * 1000,
      layout_ms: (after.LayoutDuration - before.LayoutDuration) * 1000,
      script_ms: (after.ScriptDuration - before.ScriptDuration) * 1000,
      style_count: after.RecalcStyleCount - before.RecalcStyleCount,
      layout_count: after.LayoutCount - before.LayoutCount,
    };
    await page.close();
    return out;
  }

  const REPS = 12;
  const acc = { six: [], one: [] };
  for (let i = 0; i < REPS; i++) { acc.six.push(await run('six')); acc.one.push(await run('one')); }
  const med = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
  const summarize = (rows, k) => med(rows.map(r => r[k]));
  const line = (m) => `${m}  wall=${summarize(acc[m], 'wall_ms').toFixed(2)}ms  渲染线程任务=${summarize(acc[m], 'task_ms').toFixed(2)}ms  style=${summarize(acc[m], 'style_ms').toFixed(2)}ms  layout=${summarize(acc[m], 'layout_ms').toFixed(2)}ms  styleRecalc次数=${summarize(acc[m], 'style_count')}  layout次数=${summarize(acc[m], 'layout_count')}`;
  console.log(`DOM 节点=${N * 2 + 1}  重复=${REPS} 轮（取中位数）`);
  console.log(line('six'));
  console.log(line('one'));
  const w6 = summarize(acc.six, 'wall_ms'), w1 = summarize(acc.one, 'wall_ms');
  const t6 = summarize(acc.six, 'task_ms'), t1m = summarize(acc.one, 'task_ms');
  console.log(`\n合并注入收益：wall -${(100 * (w6 - w1) / w6).toFixed(1)}%   渲染任务 -${(100 * (t6 - t1m) / t6).toFixed(1)}%`);
  await browser.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });

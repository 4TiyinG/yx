# 降频场景瓶颈定位（Perfetto 工作流）

本文说明「设备发热降频后，帧到底是被谁吃掉的」怎么测、怎么读、怎么排序。
配套工具：

| 文件 | 作用 |
|---|---|
| `scripts/perf/capture-thermal-trace.sh` | 抓**热机** trace（含抓取前后热状态对账） |
| `scripts/perf/analyze-thermal-trace.py` | 用 trace_processor 出瓶颈表 |
| `scripts/probes/_test_thermal_degrade.py` | 守着降级逻辑不被改回去（63 项） |

> **状态说明（必须读）**：本工作环境**没有真机、没有 adb 设备**，下面的表格是
> **预期排序 + 判读方法**，不是实测数字。真正的数字必须由 `capture-thermal-trace.sh`
> 在目标机型上抓出来再填。凡是本文出现「预期/应当」字样的地方，都表示该结论
> 尚未在真机上验证。

---

## 1. 为什么必须抓「热机」而不是「冷机」

同一份代码，冷机与热机的帧时间可以差 2 倍以上。冷机 trace 只能回答「性能上限」，
而我们要回答的是「降频后哪一段先崩」。因此抓取流程里内置了 `--soak`：

```bash
# 1) 冷机基线（先抓，别让设备热起来）
bash scripts/perf/capture-thermal-trace.sh --seconds 30 --out /tmp/cold.pftrace

# 2) 等设备回温后，热机数据（--soak 期间持续滑动，让它真的热）
bash scripts/perf/capture-thermal-trace.sh --soak 300 --seconds 30 --out /tmp/hot.pftrace

# 3) 出表
python3 scripts/perf/analyze-thermal-trace.py /tmp/hot.pftrace --seconds 30 --out /tmp/hot.md
```

脚本会在 trace 旁边落两份文本：`*.before.txt` / `*.after.txt`（`dumpsys thermalservice`
＋ 每核 `scaling_cur_freq` ＋ 电池温度）。**没有这两份文件，热机数据不成立** ——
你无法证明抓取窗口落在降频区间而不是升温区间。

## 2. 抓取窗口里的三个动作（缺一不可）

trace 只在有帧的时候才有信息量。抓取期间必须做：

1. **连续上下滑动会话列表 5 次** → 覆盖列表合成、滚动时的 tile 失效与重栅格化；
2. **打开一个长会话，滚到底再滚回顶** → 覆盖长文栅格化与内存压力；
3. **点开输入框再收起** → 覆盖输入法引起的 window 重建（`wm` 段的 IPC 高峰）。

不动作的 trace 里全是 idle，只能看到「谁在睡」，看不出瓶颈。

## 3. 五个维度怎么读

### 3.1 主线程（`main`）

看两张表：**状态分布** 与 **阻塞归属**。

- `Running` 占比高 → 真的在算。往下看「最耗时切片」，找 `measure/layout/draw`、
  `Choreographer#doFrame`、以及我们自己的 `RenderBudget` 分发。
- `Sleeping/S` 占比高 → **不是在算，是在等**。此时「把代码写快一点」收益有限，
  要先削争用（锁、binder、调度延迟）。判定阈值：等待占比 > 35% 就属于这一类。
- `D` 状态（不可中断睡眠）出现 → 直接查 `direct reclaim` / IO。热态下内存压力大，
  这是帧尖峰最常见的物理来源。

`blocked_function` 一列是**唯一可行动的结论**：它由内核给出「在等谁」，
例如 `binder_wait_for_work`、`fence_wait`、`mutex_lock`、`do_page_fault`。

### 3.2 RenderThread

降频时 RenderThread 通常**先于**主线程恶化（GPU 频率比 CPU 更早被压）。
判读：

- RenderThread 的 `Running` 时间上升但主线程不变 → GPU/合成侧受限，该削的是
  **合成层数量**（模糊、阴影、大面积动画），而不是我们的 Java 代码；
- RenderThread 大段 `fence_wait` → 在等 GPU 完成上一帧，说明已经"供大于求"，
  此时**降帧是正确动作**（`RenderBudget.frameCapFps`）；
- RenderThread 大段 `binder` → 在等浏览器进程/Renderer 进程，问题在页面侧。

### 3.3 WebView Renderer（独立进程）

进程名形如 `app.dsh.mobile.dev:sandboxed_process0`。它单独吃满一个核时，
**主线程再怎么优化都没用** —— 该削的是页面合成层（`js/thermal-degrade.js` 的
`NO_BACKDROP` / `NO_PARTICLES` / `PAUSE_OFFSCREEN`）。

注意：只有抓取配置里带了 `-a <pkg>`（本脚本已带）才会跟上这个子进程。
不带的话这一整节是空的，很容易被误判成「Renderer 没问题」。

### 3.4 GC

红线（需求给定）：**Young GC ≤ 5 次/秒**，且主线程不应出现 GC Wait。

`analyze` 里的 `--seconds` 参数就是为了算「次/秒」。看两件事：

1. 频率是否越线 → 越线说明**分配速率**过高，查 `onDraw` / `onBindViewHolder` /
   字符串拼接；调大堆只是把 GC 推后，不解决问题。
2. GC 的**时间点**是否落在帧中间 → 即使频率不高，一次 8ms 的 GC 也足以打掉一帧。
   trace 里把 GC 切片与 `Choreographer#doFrame` 对齐看即可。

### 3.5 内存回收（direct reclaim / kswapd）

这一维度对应需求里「避免触发系统 direct reclaim 或 kswapd 回收导致帧尖峰」。
判据很简单：**这两个事件是否出现在帧时间轴上**。出现即证明内存压力已经影响到帧，
优先级高于任何微优化 —— 此时先减内存（销毁不可见 WebView、约束图片解码尺寸、
限制同时存活的实例数），再谈渲染。

> ⚠️ WebView 的 Tile Cache 上限**没有公开 API**（`trimMemory` 是隐藏 API，
> `freeMemory` 已 deprecated）。应用层唯一可靠的手段是减少存活实例与绘制面积，
> 见 `ui/WebViewRendering.kt` 的类注释。

## 4. 瓶颈排序表（模板 + 预期）

把冷/热两次 trace 的同一维度相减，**增量最大的那一行就是先动的地方**；
若多个维度增量接近，优先动「最大尖峰」那一行 —— 尖峰比均值更能毁掉手感。

| 排名 | 维度 | 冷机 | 热机 | 增量 | 预期归因 | 对应动作 |
|---|---|---|---|---|---|---|
| 1 | Renderer 进程 CPU（Running ms） | 待测 | 待测 | **待测** | 页面合成层太多：`backdrop-filter`、大面积阴影、粒子画布 | `thermal-degrade.js` 的 `NO_BACKDROP` / `NO_PARTICLES` |
| 2 | RenderThread `fence_wait` 总时长 | 待测 | 待测 | **待测** | GPU 已降频，帧供大于求 | `RenderBudget.frameCapFps` 降到 45/30 |
| 3 | 主线程等待占比 | 待测 | 待测 | **待测** | binder（window 事务）/ 调度延迟 | 降帧 + 减少窗口事务（`postOnce` 已有） |
| 4 | GC 次数/秒 | 待测 | 待测 | **待测** | 分配速率（`onDraw` 临时对象、字符串） | 零分配 `onDraw`（本版已改 HandOverlay） |
| 5 | direct reclaim / kswapd 次数 | 待测 | 待测 | **待测** | 常驻内存过高（多实例 WebView / 大图） | 销毁不可见实例 + 图片采样解码（已有） |

**为什么把 Renderer 排在第一位（预期依据，未验证）**：
本 App 的 WebUI 是典型的前端重合成页面（卡片圆角、半透明、模糊遮罩、列表动画）。
冷机时这些都由 GPU 硬扛，帧时间看起来正常；一旦 GPU 降频，合成耗时按比例上升，
而 Renderer 是**独立进程**，它变慢不会体现在主线程的 `Running` 时间里 ——
只看主线程会得出「主线程没问题」的错误结论。这正是本文强调必须单独看
Renderer 切片的原因。

## 5. 无设备时能做什么（本仓库已做）

没有真机 → 不编造毫秒数。改为把「可以被结构性验证的东西」全部做完并守住：

1. **测量链路**：抓取脚本 + 分析脚本（本文）；
2. **结构性削减**：合成的活儿从源头减少（页面侧降级）、帧数主动减少（帧率地板）、
   Renderer 优先级分层；
3. **可验证的替代指标**：`RenderBudget.stats()` 的 `capDeferred` / `degraded` /
   `intervalEmaMs`，以及 `ThermalMonitor.dump()` 的档位与 headroom —— 这些在
   真机上打一行日志就能确认降级是否真的生效；
4. **回归护栏**：`_test_thermal_degrade.py`（63 项）+ `_test_thermal_js.mjs`（13 项）。

真机到手后的第一件事：跑第 1 节的冷/热两次抓取，把第 4 节表格里的「待测」填上。
如果排序与本文件的预期不一致，**以实测为准**，并回来改这份文档 —— 不要为了让
文档自洽去解释数据。

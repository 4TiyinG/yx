#!/usr/bin/env python3
"""复刻 PageBridgeInjection.buildScript 的拼接逻辑，对合并后的 JS 做可解析性校验。

为什么要这个：把 6 段注入合并成 1 个 script 后，**运行期**异常仍被逐段 try/catch 隔离，
但**语法**错误无法在运行期捕获——任何一段写坏都会让整段脚本一起失败（爆炸半径比旧的
逐个注入更大）。这些脚本都是 APK 里的静态文本，所以只要现在验证过一次可解析，结论就
永久成立。CI/本地都可重复跑。
"""
import re
import subprocess
import sys
from pathlib import Path

# 默认从脚本自身位置推导工程根（docs/perf/ → 仓库根），避开写死绝对路径：
# 工作区 UUID / 目录改名后仍可直接跑。也可传第一个参数手动指定 app/src/main。
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else \
    Path(__file__).resolve().parents[2] / "app/src/main"
KT_MAIN = SRC / "java/app/dsh/mobile/MainActivity.kt"
KT_DL = SRC / "java/app/dsh/mobile/engine/WebViewDownloader.kt"
JS_KEYS = SRC / "assets/js/mobile-keys.js"
JS_BACK = SRC / "assets/js/back-guard.js"


def raw_string(name: str, text: str) -> str:
    """取 Kotlin 三引号原始字符串内容，并模拟 .trimIndent()。"""
    m = re.search(re.escape(name) + r'\s*=\s*"""(.*?)"""', text, re.S)
    if not m:
        sys.exit(f"找不到常量 {name}")
    body = m.group(1)
    lines = body.split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    indents = [len(l) - len(l.lstrip()) for l in lines if l.strip()]
    common = min(indents) if indents else 0
    return "\n".join(l[common:] if l.strip() else l for l in lines)


def trim_indent(s: str) -> str:
    lines = s.split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    indents = [len(l) - len(l.lstrip()) for l in lines if l.strip()]
    common = min(indents) if indents else 0
    return "\n".join(l[common:] if l.strip() else l for l in lines)


main = KT_MAIN.read_text()
dl = KT_DL.read_text()

blob = trim_indent(raw_string("BRIDGE_TEMPLATE", dl)) if "BRIDGE_TEMPLATE" in dl else None
if blob is None:  # bridgeJs() 内联的三引号
    m = re.search(r'fun bridgeJs\(\): String = """(.*?)"""', dl, re.S)
    blob = trim_indent(m.group(1)).replace("$BRIDGE_NAME", "DshAndroidDownloader")

parts = {
    "blob": blob,
    "clipboard": raw_string("CLIPBOARD_FALLBACK_JS", main),
    "accent": "document.documentElement.style.setProperty('--dsh-accent','#4C8DF6');",
    "keys": JS_KEYS.read_text(),
    "backguard": JS_BACK.read_text(),
    "selfcheck": raw_string("WEBVIEW_SELFCHECK_JS", main),
}

# —— 与 PageBridgeInjection.buildScript 一致（外层 IIFE，完成值由 return 提供）——
sb = ["(function(){", "var __dshInjectFail=[];"]
for tag in ("blob", "clipboard", "accent", "keys", "backguard"):
    sb.append("try{" + parts[tag].strip() + "}catch(e){__dshInjectFail.push('" + tag +
              ":'+(e&&e.message));};")
sb.append("window.__dshSelfcheck=(" + parts["selfcheck"].strip().rstrip(";") + ");")
sb.append("return 'inject='+((__dshInjectFail.length)?('FAIL['+__dshInjectFail.join(',')+']'):'ok5')"
          "+(' | '+String(window.__dshSelfcheck));")
sb.append("})()")
merged = "\n".join(sb) + "\n"

out = Path("/tmp/merged_inject.js")
out.write_text(merged)
print(f"合并脚本 {len(merged)} 字节  → {out}")

r = subprocess.run(["node", "--check", str(out)], capture_output=True, text=True)
if r.returncode != 0:
    print("❌ 语法校验失败:\n" + r.stderr[:2000])
    sys.exit(1)
print("✅ node --check 通过：合并后的单一脚本可被 V8 完整解析")

# 逐段单独校验（证明每段自身也合法，与合并前等价）
for tag, src in parts.items():
    p = Path(f"/tmp/part_{tag}.js")
    p.write_text(src)
    rr = subprocess.run(["node", "--check", str(p)], capture_output=True, text=True)
    print(f"  {'✅' if rr.returncode == 0 else '❌'} 分段 {tag} ({len(src)}B)"
          + ("" if rr.returncode == 0 else "\n" + rr.stderr[:600]))
    if rr.returncode != 0:
        sys.exit(1)

#!/bin/bash
# dsh-android 构建入口（本沙箱 4GB/2core 适配版；不改仓库 gradle.properties）
# 用法: dev/build.sh [日志文件]   → 产物 app/build/outputs/apk/debug/app-debug.apk
WS="${WS_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")/../../../.." && pwd)}"
LOG="${1:-/tmp/build.log}"
source $WS/env.sh >/dev/null 2>&1
export ANDROID_HOME=$WS/sdk ANDROID_SDK_ROOT=$WS/sdk ANDROID_USER_HOME=$WS/.android
export GRADLE_USER_HOME=$WS/.gradle-proj
export PATH=$JAVA_HOME:$WS/tools/gradle-8.9/bin:$WS/sdk/cmake/3.22.1/bin:$PATH
cd $WS/dev/dsh-android
gradle --no-daemon :app:assembleDebug -Ppackage=noruntime -Pabi=arm64-v8a --console=plain \
  -Dorg.gradle.jvmargs="-Xmx2300m -XX:MaxMetaspaceSize=768m" \
  -Dorg.gradle.workers.max=2 -Dkotlin.compiler.execution.strategy=in-process \
  > "$LOG" 2>&1
echo "GRADLE_EXIT=$?" >> "$LOG"

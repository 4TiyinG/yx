# dsh-android 开发基线说明（本工作区唯一工程）

## 这是什么
GitHub `4TiyinG/yx` → release `v1.6.18-fix` 的 **完整工程** asset
`dsh-android-project-v1.5.0-20261112.zip`（17,550,694 B，与 API 记录逐字节一致）
**+ v1.6.20 渲染/加载性能优化**。其他历史副本已清理，本目录是唯一基线。

## git 历史（可追溯性保障）
```
<HEAD~1> upstream: 完整工程原样（release asset，未改一行）
<HEAD~2> perf(v1.6.20): 注入合并 6→1、JS 资产后台预读、重栅格化去重、自检结果回收
<HEAD>   chore: 测量脚本纳入 docs/perf
```
⇒ 想知道"我们相对上游改了什么"：`git diff HEAD~2 HEAD -- app/src`
⇒ 想回退优化：`git checkout HEAD~1 -- app/src` 或直接 `patch -p2 -R -i docs/perf/render-perf-v1.6.20.patch`（在 `app/src` 目录下执行，patch 内路径是 `a/src/…`）

## 构建
```bash
source <WS>/env.sh                       # JDK17 / Gradle8.9 / SDK36 / NDK26.1.10909125 / CMake3.22.1
<WS>/dev/build.sh /tmp/build.log         # noruntime + arm64-v8a，适配本沙箱 4GB/2core
# 产物：app/build/outputs/apk/debug/app-debug.apk
```
等价手工命令（工程无 wrapper，直接调 gradle）：
```bash
gradle :app:assembleDebug -Ppackage=noruntime -Pabi=arm64-v8a
```
- 本沙箱内存 4GB，仓库 `gradle.properties` 为 16GB CI 配 `-Xmx6144m` 会被内核 OOM kill；
  `dev/build.sh` 用 `-D` 覆盖为 `-Xmx2300m` + `in-process` Kotlin 编译 + `workers=2`，**未改仓库文件**。
- `local.properties` 指向工作区内 SDK/NDK/CMake（`/opt` 只读、无 sudo）。

## 产物身份（实测）
```
package      app.dsh.mobile.dev      versionCode 366   versionName 1.5.0
minSdk 26    targetSdk 28            ABI: 仅 arm64-v8a（x86_64 模拟器装不上）
签名证书 SHA-256 8453a192dfb56c6f76874a06de9e0deb9151972311756403e872647fa9dc28bf（v2 通过）
  == debug-signing/dsh-debug.keystore == dsh-debug.fingerprint.txt == CHANGES.txt == 官方 asset APK
```
⇒ 与官方 `dsh-android-fix-20261112-arm64-v8a-debug.apk` 同包名/同签名/同 versionCode，可直接覆盖安装。
交叉核对：748 条目 vs 官方 748，**735 条 CRC 完全相同**，仅 13 条不同（dex/.so 重编不确定性 + MANIFEST 时间戳）。

## docs/perf/ 里的验证工具
| 脚本 | 作用 |
|------|------|
| `check_inject_js.py` | 复刻 Kotlin 拼接逻辑，`node --check` 验证合并脚本可解析 |
| `verify_inject.js` | 等价性 / 隔离性 / 幂等性（真 Chrome 145 + CDP） |
| `bench_inject.js` | 6 次串行 vs 1 次合并 的开销对比 |
| `sim_reraster.js` | 重栅格化调度仿真（操作次数，非毫秒） |
| `render-perf-v1.6.20.patch` | 优化补丁本体（334 行） |

跑法：`node --experimental-require-module`? 不需要，直接 `node verify_inject.js`
（依赖全局 `puppeteer-core`，Chrome 在 `/usr/local/chrome/chrome`）。

## ⚠️ 尚未验证的部分（需真机）
- 运行期表现：首屏、blob 打包下载、剪贴板降级、软键盘回车换行、整页浮层返回、桌面模式 UA 切换
- 帧率/内存前后对比：`adb shell dumpsys gfxinfo app.dsh.mobile.dev framestats` / `dumpsys meminfo`
- 注入时机（commitVisible / DocumentStart）、`shouldInterceptRequest` 资源缓存、
  `PetOverlayService` 60fps `updateViewLayout` —— 三项都**需要真机数据才动**，见 outputs 优化报告 §4

package app.dsh.mobile.engine

import android.app.ActivityManager
import android.content.Context
import android.util.Log

/**
 * 启动期负载画像（v1.6.34）。
 *
 * ## 为什么需要它
 *
 * 用户反馈的核心现象是「**设备差异 + 发热降频**会让启动变得极不流畅」。而原来的实现
 * 对任何设备都用同一套参数：
 *
 * ```
 * pollHealthInterval = 100ms 恒定
 * UV_THREADPOOL_SIZE = 8     固定
 * 预读并发           = 2     固定
 * ```
 *
 * 在 8 核旗舰上这些参数毫无压力；但在 4 核/低内存的机器上（尤其是降频后只剩一半
 * 算力时）**恰恰相反**：8 个 libuv IO 线程 + 2 个预读协程 + 主线程全部抢同样几个核，
 * 上下文切换成本吃掉大部分收益，表现为「越并发越卡、越卡越烫」。
 *
 * 所以这里给出一个**统一的设备画像**，让启动路径上的轮询间隔、并发度、线程池大小
 * 都按它自适应：弱机少开线程、拉长间隔（省 CPU、少发热）；强机保持激进（更快）。
 *
 * ## 判定口径
 *
 * 只依赖两个稳定信号，不做任何「跑分」式测量（测量本身就要烧 CPU）：
 * · [cores]：`availableProcessors()`。≤4 视为「核数受限」；
 * · [lowRam]：`ActivityManager.isLowRamDevice`（系统按内存总量给出的官方标记）。
 *
 * 两者任一成立 → [constrained] = true，走保守参数。
 *
 * ## 注意
 *
 * 这里**不感知实时温度/降频**（Android 没有稳定公开接口）。但保守参数本身就是
 * 「发热降频时仍然流畅」的保险：降频后单核吞吐下降，减少并发+拉长轮询正好是
 * 正确方向，所以不需要真的读到温度值。
 */
object BootLoad {

    private const val TAG = "BootLoad"

    /** CPU 核数（进程启动即可读，无 IO）。 */
    val cores: Int = runCatching { Runtime.getRuntime().availableProcessors() }
        .getOrDefault(4)
        .coerceAtLeast(1)

    @Volatile private var lowRamFlag: Boolean = false
    @Volatile private var probed: Boolean = false

    /** 系统是否标记为低内存设备（未探测前按 false 处理）。 */
    val lowRam: Boolean get() = lowRamFlag

    /**
     * 是否处于「资源受限」状态：核数少或系统标记低内存。
     *
     * 这是启动路径上所有自适应参数的唯一开关点 —— 想调整阈值只改这里。
     */
    val constrained: Boolean get() = cores <= 4 || lowRamFlag

    /** 探测一次设备画像。幂等，重复调用无副作用（建议在启动循环开头调一次）。 */
    fun probe(ctx: Context) {
        if (probed) return
        probed = true
        lowRamFlag = runCatching {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.isLowRamDevice == true
        }.getOrDefault(false)
        Log.i(
            TAG,
            "device profile: cores=$cores lowRam=$lowRam constrained=$constrained " +
                "(poll=${healthPollIntervalMs(0)}ms→${healthPollIntervalMs(Int.MAX_VALUE)}ms, " +
                "prefetchParallelism=$prefetchParallelism, uvThreadpool=$uvThreadpoolSize)",
        )
    }

    /**
     * 健康探测的轮询间隔：**先密后疏**。
     *
     * 引擎端口通常在 fork 后 300~900ms 才监听，所以前 1 秒用短间隔能立刻抓住
     * 就绪时刻（少等最多 ~100ms，这是启动尾段最明显的一段固定延迟）；
     * 之后就拉长，因为此时等待的是 node 加载 bundle，短间隔纯属空转烧 CPU。
     *
     * 受限设备整体再放宽一档：它一次 poll 的代价更高（要建 socket + 读日志），
     * 而且这类设备上「早 40ms 发现」的收益远不如「少做 20 次无用工作」。
     *
     * @param attempt 第几次轮询（从 0 开始）。
     */
    fun healthPollIntervalMs(attempt: Int): Long = when {
        attempt < FAST_POLLS -> if (constrained) 60L else 40L
        else -> if (constrained) 180L else 120L
    }

    /** 处于「快轮询」阶段的最大次数（按 40ms 估算 ≈ 前 1.2 秒）。 */
    private const val FAST_POLLS = 30

    /**
     * 插件预读的并发度。
     *
     * 预读是**纯收益型**工作（把文件读进 page cache），它不该和引擎冷启动抢核：
     * 受限设备上串行（1）就够，因为那点数据量单线程也能在首帧后的窗口里读完；
     * 强机才开到 2。
     */
    val prefetchParallelism: Int get() = if (constrained) 1 else 2

    /**
     * libuv 线程池大小（`UV_THREADPOOL_SIZE`）。
     *
     * 原来固定 8。这个数字决定了引擎侧 `fs`/`dns`/`crypto` 等异步操作的并行度：
     * · 核数 ≥ 8 的机器：4 已经足够覆盖磁盘并行度（再多只是排队）；
     * · 4 核/低内存：2~3 更合适 —— 8 个线程轮流被抢占，反而让**同步路径**
     *   （引擎主线程的 JS 执行）拿不到连续时间片，这是「启动顿挫感」的来源之一。
     *
     * 结果落在 2..4，且不超过核数。
     */
    val uvThreadpoolSize: Int
        get() = when {
            cores >= 8 -> 4
            cores >= 6 -> 3
            else -> 2
        }
}

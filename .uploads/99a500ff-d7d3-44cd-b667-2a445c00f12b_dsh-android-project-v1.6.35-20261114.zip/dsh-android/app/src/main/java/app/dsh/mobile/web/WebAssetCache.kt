package app.dsh.mobile.web

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Log
import android.util.LruCache
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * WebUI 静态资源的本地缓存与预热（v1.6.25）。
 *
 * ## 为什么只缓存 CSS / 字体 / 图片，**绝不**碰 JS
 *
 * 这是本文件最重要的一条设计约束，理由是一个容易被忽略的不对称性：
 *
 * Chromium 自己有一套真正意义上的「预编译缓存」——**V8 code cache**。它把已经
 * 解析编译过的脚本字节码按资源存下来，下次同一脚本直接反序列化，省掉 parse +
 * compile。这个缓存**在 WebView 的私有 cache 目录里，Android SDK 没有任何 API
 * 能直接控制它**，我们能做的只有「别弄坏它」。
 *
 * 而 `shouldInterceptRequest` 一旦返回自己的响应，该资源就**脱离了 Chromium 的
 * 资源加载链路**：不会进 HTTP cache，也不会进 code cache。也就是说，拦一个 JS
 * 文件，换来的是「少一次本地 HTTP 往返」，代价却是「每次启动都重新 parse +
 * compile 一遍」——对 1MB 级的 SPA bundle，后者在手机上通常是几十到上百毫秒，
 * 明显亏。
 *
 * CSS / 字体 / 图片没有 code cache 可失去（它们不经过 V8），拦截它们**只有
 * 收益、没有这个下行风险**：省掉 Node 事件循环 + proot 系统调用翻译 + 一次
 * 回环 HTTP 往返，直接从 app 私有目录 memcpy 出来。
 *
 * 所以：[ALLOWED_EXT] 里刻意没有 `js` / `mjs` / `html`。这不是遗漏。
 *
 * ## 两种工作模式
 *
 * · **预热（[learn]）**：页面首帧落定后，取 `performance.getEntriesByType('resource')`
 *   里本机的静态资源 URL，在后台用 2 个线程自己下载并落盘。第一次运行是空的，
 *   跑完这一趟，下次启动就有货了。
 * · **命中（[serve]）**：`shouldInterceptRequest` 里查内存 → 查磁盘，命中就直接
 *   吐字节并带上 `immutable` 缓存头；未命中返回 `null`，WebView 照常走网络，
 *   行为与改动前完全一致。
 *
 * 单边降级原则：**任何异常都返回 null**。缓存坏了、磁盘满了、文件被删了、
 * JSON 破了 —— 一律退回网络路径，功能不受影响，最多是没快。
 *
 * ## 失效
 * 键里带 `schema | versionCode | <engineRoot>/.runtime-version`。App 升级或引擎
 * 运行时被 `EngineUpdater` 换掉 → stamp 变了 → 整个目录清空重建。这挡住了
 * 「引擎换了前端、我们还在喂旧 CSS」这类最难查的问题。
 *
 * 另有 [SERVE_TTL_MS]：超过 7 天的条目不再命中（当作 miss，并在下次预热时刷新），
 * 兜住「同 URL 内容变了但我们没感知到」的情况 —— 前端 bundle 通常是内容哈希
 * 命名，这条基本不会触发，属于安全网。
 */
object WebAssetCache {
    private const val TAG = "WebCache"

    /** 总开关：出问题时可整体关掉，退回纯网络路径。 */
    private const val ENABLED = true

    /** 存储格式版本；改结构时 +1，旧目录会被清掉。 */
    private const val SCHEMA = 1

    /**
     * 可拦截的资源类型。
     *
     * ⚠️ **不要往里加 js / mjs / html**，理由见类注释（会丢掉 V8 code cache）。
     */
    private val ALLOWED_EXT = setOf(
        "css",
        "woff", "woff2", "ttf", "otf",
        "png", "jpg", "jpeg", "webp", "gif", "svg", "ico", "avif", "bmp",
    )

    /** 单个文件上限：超过就不缓存（多半是下载/导出类请求，不该进资源缓存）。 */
    private const val MAX_FILE_BYTES = 8L * 1024 * 1024

    /** 缓存目录总量上限，超出按最旧优先淘汰。 */
    private const val MAX_TOTAL_BYTES = 48L * 1024 * 1024

    /** 内存层预算。首屏期间反复命中的就是同一批图片/字体，这层最直接。 */
    private const val MEM_BUDGET = 12 * 1024 * 1024

    /** 超过这个年龄的条目不再命中（见类注释「失效」）。 */
    private const val SERVE_TTL_MS = 7L * 24 * 60 * 60 * 1000

    /** 预热最多处理多少个资源，防止异常页面把清单撑爆。 */
    private const val MAX_LEARN_URLS = 160

    private val io = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "webcache").apply { isDaemon = true }
    }

    private val mem = object : LruCache<String, ByteArray>(MEM_BUDGET) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }

    // 统计（每次启动重置，只用于日志：让真机上能看出这层到底有没有用）
    private val hits = AtomicInteger()
    private val misses = AtomicInteger()
    private val servedBytes = AtomicLong()
    private val learned = AtomicInteger()
    private val learnedBytes = AtomicLong()
    @Volatile private var servedOnce = false

    private fun dir(ctx: Context) = File(ctx.filesDir, "webcache")

    /**
     * 启动时调用一次：比对 stamp，不一致就清空；随后做一次容量修剪。
     * 全部是轻量文件操作，但仍放到后台线程，绝不占启动主线程。
     */
    fun init(ctx: Context) {
        if (!ENABLED) return
        val app = ctx.applicationContext
        io.execute {
            runCatching {
                val root = dir(app)
                val stamp = stampOf(app)
                val stampFile = File(root, "stamp")
                val old = if (stampFile.isFile) runCatching { stampFile.readText() }.getOrNull() else null
                if (old != stamp) {
                    if (root.isDirectory) {
                        val n = root.listFiles()?.count { it.deleteRecursively() } ?: 0
                        Log.i(TAG, "cache invalidated (stamp ${old ?: "none"} -> $stamp), dropped $n entrie(s)")
                    }
                    root.mkdirs()
                    stampFile.writeText(stamp)
                }
                prune(root)
            }.onFailure { Log.w(TAG, "init failed: ${it.message}") }
        }
    }

    /**
     * 尝试用本地缓存满足一次请求。
     *
     * 在 WebView 的后台 IO 线程上被调用，**不碰 UI 线程**。
     *
     * @return 命中返回响应；未命中/任何异常返回 `null`（WebView 走网络，行为同改动前）。
     */
    fun serve(request: WebResourceRequest?): WebResourceResponse? {
        if (!ENABLED) return null
        return runCatching { serveInner(request) }.getOrNull()
    }

    private fun serveInner(request: WebResourceRequest?): WebResourceResponse? {
        request ?: return null
        if (request.method != "GET") return null
        // 用户/页面明确要求不走缓存（硬刷新、Ctrl+F5 语义）：让网络说了算。
        // 只看方向上的 cache-control；正常导航不会带这个头。
        val cc = request.requestHeaders?.entries
            ?.firstOrNull { it.key.equals("Cache-Control", ignoreCase = true) }?.value
        if (cc != null && (cc.contains("no-cache", true) || cc.contains("no-store", true) || cc.contains("max-age=0"))) {
            return null
        }
        val uri = request.url ?: return null
        if (uri.scheme != "http") return null
        val host = uri.host ?: return null
        if (host != "127.0.0.1" && host != "localhost") return null
        val path = uri.path ?: return null
        val ext = path.substringAfterLast('/').substringAfterLast('.', "").lowercase()
        if (ext !in ALLOWED_EXT) return null

        // 键含完整 URL（含 query）：不同 query 可能是不同内容，不做归一化。
        val root = currentRoot ?: return null
        val key = sha1(uri.toString())
        val bytes = mem.get(key) ?: run {
            val entry = entryFile(root, key, ext)
            if (!entry.isFile) return null
            if (System.currentTimeMillis() - entry.lastModified() > SERVE_TTL_MS) return null
            val b = runCatching { entry.readBytes() }.getOrNull() ?: return null
            mem.put(key, b)
            b
        }
        hits.incrementAndGet()
        servedBytes.addAndGet(bytes.size.toLong())
        if (!servedOnce) {
            servedOnce = true
            Log.i(TAG, "first cache hit this launch: $path (${bytes.size} B)")
        }
        // immutable：告诉 Chromium 这份字节在一年内不会变，别再来问。
        // 我们自己已经用 stamp + TTL 兜住了失效，不需要它帮忙判断。
        val headers = HashMap<String, String>(2)
        headers["Cache-Control"] = "public, max-age=31536000, immutable"
        headers["ETag"] = "\"${key.take(16)}\""
        return WebResourceResponse(
            mimeOf(ext),
            null,
            200,
            "OK",
            headers,
            ByteArrayInputStream(bytes),
        )
    }

    /**
     * 预热：把这些 URL 里本机允许类型、且尚未缓存的资源下载到磁盘。
     *
     * 由 [app.dsh.mobile.MainActivity] 在首帧落定之后调用（延迟若干秒），
     * 所以不会和首屏渲染、插件 HMR 抢 CPU/IO。
     *
     * 幂等：已经缓存且未过期的 URL 直接跳过，重复调用无副作用。
     */
    fun learn(ctx: Context, urls: List<String>) {
        if (!ENABLED || urls.isEmpty()) return
        val app = ctx.applicationContext
        val todo = urls.asSequence()
            .filter { it.startsWith("http://") }
            .filter { u -> runCatching { Uri.parse(u).host }.getOrNull().let { it == "127.0.0.1" || it == "localhost" } }
            .filter { u -> extOf(u) in ALLOWED_EXT }
            .distinct()
            .take(MAX_LEARN_URLS)
            .toList()
        if (todo.isEmpty()) return
        io.execute {
            val root = dir(app)
            if (!root.isDirectory) return@execute
            var ok = 0
            var bytes = 0L
            for (url in todo) {
                val ext = extOf(url)
                val key = sha1(url)
                val target = entryFile(root, key, ext)
                if (target.isFile && System.currentTimeMillis() - target.lastModified() <= SERVE_TTL_MS) continue
                val result = fetch(url) ?: continue
                runCatching {
                    target.parentFile?.mkdirs()
                    val tmp = File(target.parentFile, "$key.tmp")
                    tmp.writeBytes(result)
                    if (!tmp.renameTo(target)) {
                        target.writeBytes(result)
                        tmp.delete()
                    }
                    ok++
                    bytes += result.size
                }
            }
            learned.addAndGet(ok)
            learnedBytes.addAndGet(bytes)
            if (ok > 0) {
                Log.i(TAG, "learned $ok asset(s), ${bytes / 1024} KB (ready for next launch)")
                prune(root)
            }
            logStats(app, "after learn")
        }
    }

    /** 把本次启动的命中情况写进日志，便于真机上判断这层值不值得留。 */
    fun logStats(ctx: Context, whenLabel: String = "launch") {
        val h = hits.get()
        val m = misses.get()
        if (h == 0 && m == 0 && learned.get() == 0) return
        val disk = runCatching {
            dir(ctx).walkTopDown()
                .filter { it.isFile && it.name != "stamp" && it.extension != "tmp" }
                .sumOf { it.length() }
        }
            .getOrDefault(0L)
        Log.i(
            TAG,
            "$whenLabel: hits=$h misses=$m served=${servedBytes.get() / 1024} KB, " +
                "learned=${learned.get()} (${learnedBytes.get() / 1024} KB), disk=${disk / 1024} KB",
        )
    }

    // ── 内部 ─────────────────────────────────────────────────────────────────

    /**
     * 当前生效的缓存根目录。
     *
     * `serve()` 拿不到 Context（`shouldInterceptRequest` 是热路径，不想每次去
     * `applicationContext`），所以由 [init] 记下；[init] 在 WebView 创建时已调用，
     * 早于任何请求。
     */
    @Volatile private var currentRoot: File? = null

    private fun entryFile(root: File, key: String, ext: String) = File(File(root, "e"), "$key.$ext")

    private fun stampOf(ctx: Context): String {
        val vc = runCatching {
            val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            @Suppress("DEPRECATION") // versionCode 在 API 28 起被 longVersionCode 取代
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
        }.getOrDefault(0L)
        val runtime = runCatching {
            File(app.dsh.mobile.engine.EngineConfig.engineRoot(ctx), ".runtime-version").readText().trim()
        }.getOrNull() ?: "-"
        return "$SCHEMA|$vc|$runtime"
    }

    private fun extOf(url: String): String {
        val path = runCatching { Uri.parse(url).path }.getOrNull() ?: return ""
        return path.substringAfterLast('/').substringAfterLast('.', "").lowercase()
    }

    private fun mimeOf(ext: String): String = when (ext) {
        "css" -> "text/css"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "svg" -> "image/svg+xml"
        "ico" -> "image/x-icon"
        "avif" -> "image/avif"
        "bmp" -> "image/bmp"
        else -> "application/octet-stream"
    }

    private fun fetch(url: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return runCatching {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 3_000
                readTimeout = 10_000
                requestMethod = "GET"
                instanceFollowRedirects = true
                setRequestProperty("Accept-Encoding", "identity") // 要原始字节，不要 gzip 解压后的变形
            }
            if (conn!!.responseCode != 200) return null
            // ⚠️ 只接受未压缩的字节。
            //
            // WebResourceResponse 不能声明 Content-Encoding（我们能给的只有 mime +
            // 少量头），所以一旦把 gzip 字节原样存下来、再以 `text/css` 明文吐出去，
            // WebView 拿到的就是**压缩流当文本**——样式直接失效，而且是“只有某些
            // 资源坏掉”的极难定位的问题。引擎对 CSS/JSON 开 gzip 很常见。
            // 我们已发 Accept-Encoding: identity，正常情况不会压缩；这里再兜一层：
            // 只要响应真的被编码过，就放弃缓存这个资源（退回网络路径，功能不受影响）。
            val enc = conn!!.contentEncoding?.trim()?.lowercase()
            if (enc != null && enc.isNotEmpty() && enc != "identity") {
                Log.d(TAG, "skip $url: content-encoding=$enc (cannot replay via WebResourceResponse)")
                return null
            }
            val len = conn!!.contentLengthLong
            if (len > MAX_FILE_BYTES) return null
            val buf = java.io.ByteArrayOutputStream(if (len > 0) len.toInt() else 16 * 1024)
            conn!!.inputStream.use { ins ->
                val chunk = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val n = ins.read(chunk)
                    if (n <= 0) break
                    total += n
                    if (total > MAX_FILE_BYTES) return null
                    buf.write(chunk, 0, n)
                }
            }
            buf.toByteArray()
        }.onFailure { Log.d(TAG, "fetch failed $url: ${it.message}") }.also {
            runCatching { conn?.disconnect() }
        }.getOrNull()
    }

    /** 容量修剪：总量超限时按最后修改时间从旧到新删，直到回到上限以下。 */
    private fun prune(root: File) {
        runCatching {
            // stamp 是失效标记，绝不能当缓存条目删掉（删了下次启动会误判为换版本而全清）
            val all = root.walkTopDown().filter { it.isFile && it.name != "stamp" }.toList()
            // 残留的 .tmp（上次写到一半被杀）直接清掉
            all.filter { it.extension == "tmp" }.forEach { it.delete() }
            var total = all.sumOf { it.length() }
            if (total <= MAX_TOTAL_BYTES) return
            all.sortedBy { it.lastModified() }.forEach { f ->
                if (total <= MAX_TOTAL_BYTES) return@forEach
                val len = f.length()
                if (f.delete()) total -= len
            }
            Log.i(TAG, "pruned to ${total / 1024} KB")
        }
    }

    private fun sha1(s: String): String {
        val md = MessageDigest.getInstance("SHA-1")
        val d = md.digest(s.toByteArray())
        val sb = StringBuilder(40)
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    /** 由 [init] 记录根目录，供无 Context 的 [serve] 使用。 */
    fun attach(ctx: Context) {
        if (!ENABLED) return
        val app = ctx.applicationContext
        val root = dir(app).apply { mkdirs() }
        currentRoot = root
        Log.i(TAG, "attached, root=${root.absolutePath}")
        init(app)
    }
}

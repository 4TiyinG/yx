package app.dsh.mobile.engine

import android.content.Context
import android.util.Log
import app.dsh.mobile.DshApp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 插件快速启动：启动前临时摘除第三方 bundle，核心引擎先起、WebUI 先显示；
 * HTTP 就绪、首帧落定后恢复 profile 并 touch patch 文件，交给 dsh-hmr 流式热加载插件。
 *
 * v1.6.32：改为**无条件解耦**。
 *
 * 只要存在第三方插件就一律推迟，不再按体量放行、也不再给任何单个插件开豁免。
 * 理由是验收标准变了：
 *
 *   「WebUI 的首屏渲染必须与插件加载彻底解耦，不被任何插件的加载过程所阻塞。」
 *
 * 这条标准下，v1.6.24 的「体量小就不摘」和 v1.6.29 的「优先级插件不推迟」都
 * 站不住 —— 它们让插件随引擎首轮加载，于是引擎进入 Healthy 的时间里就包含了
 * 该插件的解析与求值；体量小只是**拖得少**，不是**不拖**。而 WebUI 要等到
 * Healthy 才能加载，所以首屏必然被插件推后。
 *
 * 现在统一走三步：核心引擎先起 → WebUI 立即首帧 → 插件在后台按队列流式补上。
 * 队列的首位仍然由 [PluginPriority] 保证（`dsh.profile.bundles[0]`），所以
 * `dsh-web-mobile` 依旧是最先加载就绪的那个，只是不再霸占首屏。
 */
object PluginFastBoot {
    private const val TAG = "PluginFastBoot"
    private const val KEY = "fast_plugin_boot"
    private const val BACKUP = ".fastboot-backup.json"
    private const val PATCH_TOUCH = "\n# dsh-fastboot release "

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .getBoolean(KEY, true)

    fun requestSkipNext(ctx: Context) {
        // commit() 而非 apply()：调用方紧接着就 restart()，后台线程可能在同一
        // 毫秒内 consume；apply 的异步落盘 + 读侧竞态会让「跳过快速启动」失效，
        // 于是删除对话后的重启又走 hold 路径（摘第三方插件 + 靠 HMR 补），
        // 正是 directoryPickerController unavailable 的现场。
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .edit().putBoolean("fast_plugin_boot_skip_once", true).commit()
    }

    fun consumeSkipNext(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
        val v = p.getBoolean("fast_plugin_boot_skip_once", false)
        if (v) p.edit().putBoolean("fast_plugin_boot_skip_once", false).commit()
        return v
    }

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY, on).apply()
    }

    private fun profileDir(ctx: Context) = File(EngineConfig.dshHome(ctx), "profiles/web")

    fun hold(ctx: Context): Boolean {
        if (!enabled(ctx)) return false
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        if (!manifest.isFile) return false
        // v1.6.34：**不再**在启动路径上跑 PluginPrefetcher.decide()。
        //
        // decide() 要遍历所有插件目录做 stat（早退阈值 2MB，但小插件集会走完）。
        // v1.6.32 取消「体量小就不摘」之后，它的结论只剩两个用途：
        //   · 打一行日志；
        //   · 让 PluginPrefetcher 判断值不值得预热。
        // 而它当时被放在 **spawn 之前** 的串行链上 —— 等于为了「打一行日志」
        // 让引擎 fork 向后推迟几十到几百毫秒（低端机/降频时更久）。
        // 现在该判断移到预热协程里（首帧之后、后台跑），hold 只做必要的
        // manifest 改写。日志里仍能看到结论，只是它不再挡在启动路径上。
        val backup = File(dir, BACKUP)
        if (backup.isFile) {
            runCatching {
                atomicWrite(manifest, backup.readText())
                backup.delete()
            }.onFailure { Log.w(TAG, "pending restore failed: ${it.message}") }
        }
        val root = runCatching { JSONObject(manifest.readText()) }.getOrNull() ?: return false
        val profile = root.optJSONObject("dsh")?.optJSONObject("profile") ?: return false
        val bundles = profile.optJSONArray("bundles") ?: return false
        val deps = root.optJSONObject("dependencies") ?: JSONObject()
        // v1.6.32：**取消** v1.6.29 的「优先级插件不参与推迟」豁免。
        //
        // v1.6.29 的理由是「dsh-web-mobile 决定首屏布局，推迟后用户第一眼看到的
        // 不是最终布局」。但代价是它随引擎首轮加载，把引擎的就绪时间拖长 ——
        // 而 WebUI 要等 Healthy 才能加载，于是首屏反而更慢。用户实测确认了这一点。
        //
        // 新的取舍：宁可让「布局从桌面态过渡到移动态」这一眼发生在首帧之后，
        // 也不让任何插件挡住首帧。为了把这个过渡压到最短，
        // · [PluginPriority] 仍把它放在 bundles 首位 → 释放后它是后台队列第一个；
        // · [PluginPrefetcher] 在首帧前预读它的入口文件 → HMR 读取时是 page cache 命中。
        // 开关关掉（`plugin_priority_mobile_ui`）时它会被排到末尾，语义不变。
        val keep = JSONArray()
        var removed = 0
        for (i in 0 until bundles.length()) {
            val name = bundles.optString(i)
            val thirdParty = deps.has(name) && !name.startsWith("@deepseek-ai/")
            if (thirdParty) removed++ else keep.put(name)
        }
        if (removed == 0) return false
        return runCatching {
            backup.writeText(manifest.readText())
            profile.put("bundles", keep)
            atomicWrite(manifest, root.toString(2))
            val first = keepOrderHint(ctx)
            Log.i(
                TAG,
                "fast boot: deferred $removed third-party bundle(s); " +
                    "WebUI paints on core only, plugins stream back in queue order" +
                    if (first != null) " (queue head: $first)" else "",
            )
            true
        }.getOrElse {
            Log.w(TAG, "fast boot hold failed: ${it.message}")
            false
        }
    }

    /**
     * 后台队列的头一个插件（= 释放后最先被 HMR 挂载的那个），仅用于日志。
     *
     * 取的是**备份**里的顺序，因为 hold 期间线上 manifest 已经不含第三方插件；
     * 备份是 [hold] 写下的、[PluginPriority] 已重排过的那一份。
     */
    private fun keepOrderHint(ctx: Context): String? = runCatching {
        val dir = profileDir(ctx)
        val backup = File(dir, BACKUP)
        val manifest = if (backup.isFile) backup else File(dir, "package.json")
        if (!manifest.isFile) return@runCatching null
        val root = JSONObject(manifest.readText())
        val bundles = root.optJSONObject("dsh")?.optJSONObject("profile")
            ?.optJSONArray("bundles") ?: return@runCatching null
        val deps = root.optJSONObject("dependencies") ?: JSONObject()
        for (i in 0 until bundles.length()) {
            val name = bundles.optString(i)
            if (deps.has(name) && !name.startsWith("@deepseek-ai/")) return@runCatching name
        }
        null
    }.getOrNull()

    fun release(ctx: Context): Boolean {
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        val backup = File(dir, BACKUP)
        if (!backup.isFile) return false
        val ok = runCatching {
            atomicWrite(manifest, backup.readText())
            backup.delete()
            true
        }.getOrElse {
            Log.w(TAG, "fast boot release failed: ${it.message}")
            false
        }
        if (ok) touchPatch(dir)
        return ok
    }

    /**
     * 第一阶段释放（v1.6.33）：只把**优先插件**放回 profile，其余第三方继续压着。
     *
     * ## 为什么需要分两阶段
     *
     * 只在 `bundles` 里排第一是**顺序**保证，不是**时间**保证 —— 引擎如果并发挂载
     * entry，排第一的插件仍会和其余插件抢同一批 CPU/IO。用户要的是它「比别人先
     * 加载完」，那就得让它先独占一轮：
     *
     * ```
     * 首帧 → 释放[核心 + dsh-web-mobile] → 它先独自挂载
     *      → HEAD_START_MS 之后 → 释放全部 → 其余插件才进场
     * ```
     *
     * ## 安全
     * · 不删备份：全量还原仍由 [release] 负责，中途失败下次启动时会自动 rollback。
     * · 只从备份里**筛**条目，不造新条目（优先插件本来就在备份里且已排首位）。
     * · 备份里根本没装目标插件时直接返回 false，调用方跳过第一阶段。
     *
     * @return 是否真的写了「只带优先插件」的 profile。
     */
    fun releasePriorityOnly(ctx: Context): Boolean {
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        val backup = File(dir, BACKUP)
        if (!backup.isFile) return false
        val priority = PluginPriority.listedName(backup) ?: return false
        val ok = runCatching {
            val root = JSONObject(backup.readText())
            val profile = root.optJSONObject("dsh")?.optJSONObject("profile")
                ?: return@runCatching false
            val bundles = profile.optJSONArray("bundles") ?: return@runCatching false
            val deps = root.optJSONObject("dependencies") ?: JSONObject()
            val staged = JSONArray()
            var deferred = 0
            for (i in 0 until bundles.length()) {
                val name = bundles.optString(i)
                val thirdParty = deps.has(name) && !name.startsWith("@deepseek-ai/")
                if (thirdParty && name != priority) {
                    deferred++
                } else {
                    staged.put(name)
                }
            }
            if (staged.length() == 0) return@runCatching false
            val stagedRoot = JSONObject(root.toString())
            stagedRoot.optJSONObject("dsh")?.optJSONObject("profile")?.put("bundles", staged)
            atomicWrite(manifest, stagedRoot.toString(2))
            Log.i(
                TAG,
                "priority stage: released $priority alone (" +
                    "$deferred third-party bundle(s) still deferred)",
            )
            true
        }.getOrElse {
            Log.w(TAG, "priority stage failed: ${it.message}")
            false
        }
        if (ok) touchPatch(dir)
        return ok
    }

    fun rollback(ctx: Context): Boolean {
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        val backup = File(dir, BACKUP)
        if (!backup.isFile) return false
        return runCatching {
            atomicWrite(manifest, backup.readText())
            backup.delete()
            true
        }.getOrElse { false }
    }

    private fun touchPatch(dir: File) {
        runCatching {
            File(dir, "cordis.patch.yml").appendText(PATCH_TOUCH + System.currentTimeMillis() + "\n")
            Log.i(TAG, "profile patch touched for HMR plugin reload")
        }.onFailure { Log.w(TAG, "touch patch failed: ${it.message}") }
    }

    private fun atomicWrite(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) {
            target.writeText(text)
            tmp.delete()
        }
    }
}
package app.dsh.mobile.ui

/**
 * 热档位 → 具体动作的映射表（v1.6.35）。
 *
 * ## 为什么把「策略」和「判定」分开
 *
 * [ThermalMonitor] 只回答「现在有多热」，本类只回答「这个热度下该关掉什么」。
 * 分开的好处：调参数时只改这一个文件，状态机与探针完全不受影响；也便于在
 * 文档里一张表说清「哪一档关了什么」。
 *
 * ## 降级阶梯（与需求一一对应）
 *
 * | 档位 | 帧率 | 页面侧 | 原生侧 |
 * |---|---|---|---|
 * | NORMAL | 不设上限 | 全开 | 全部后台任务正常 |
 * | WARM   | 60 | 关模糊/大面积阴影/大面积动画 | — |
 * | TIGHT  | 45 | + 停粒子、停非可视区域动效 | 暂停非关键后台任务、Renderer 降为 BOUND |
 * | SEVERE | 30 | + 停轮播/视差/装饰性动画，仅保滚动点击 | Renderer 降为 WAIVED、只保可见内容 |
 *
 * ## 帧率为什么是 60/45/30
 *
 * · 60：绝大多数机型的显示上限；
 * · 45：**仍是 60Hz 的整数分频（每 1.33 帧画一帧）**，js 侧 rAF 降到 45 会让部分帧
 *   错过 vsync，但肉眼几乎无感，而 GPU 合成量直接降 25%；
 * · 30：与 60 的 2:1 整除关系最稳，掉帧观感是「变成 30fps 动画」而不是「不规则抖动」——
 *   不规则抖动比低帧率更让人难受。
 *
 * 不用 40/48 之类：非整除分频会同时产生「一顿一顿」和「偶尔跳帧」两种观感。
 */
object ThermalPolicy {

    /** 页面侧降级位（与 `assets/js/thermal-degrade.js` 里的常量**必须**一致） */
    object JsFlags {
        /** 禁用 `backdrop-filter`（大面积高斯模糊是 GPU 合成最贵的单项） */
        const val NO_BACKDROP = 1 shl 0
        /** 削弱 box/text-shadow 与按钮过渡（阴影触发大量 draw call） */
        const val LIGHT_SHADOW = 1 shl 1
        /** 暂停粒子/彩带等高开销装饰画布 */
        const val NO_PARTICLES = 1 shl 2
        /** 暂停非可视区域（IntersectionObserver 判定）的动画与视频 */
        const val PAUSE_OFFSCREEN = 1 shl 3
        /** 暂停轮播/视差/背景装饰等非核心动画 */
        const val NO_NONCORE_ANIM = 1 shl 4
        /** 降低 Canvas 渲染分辨率（页面侧按此缩放 backing store） */
        const val LOWER_CANVAS = 1 shl 5
    }

    /**
     * 一档的完整动作集。`data class` 便于探针整体比较，也便于日志打印。
     *
     * @param jsFlags      推给页面侧的降级位
     * @param frameCapFps  原生侧帧率地板（0 = 不设上限）
     * @param pauseBgWork  是否暂停非关键后台任务（[DeferredWork]）
     * @param renderer     期望的 WebView Renderer 优先级
     */
    data class Plan(
        val level: ThermalMonitor.Level,
        val jsFlags: Int,
        val frameCapFps: Int,
        val pauseBgWork: Boolean,
        val renderer: Int,
    )

    /** Renderer 优先级常量（与 WebView.RENDERER_PRIORITY_* 数值一致，避免这里 import WebView） */
    const val RENDERER_WAIVED = 0
    const val RENDERER_BOUND = 1
    const val RENDERER_IMPORTANT = 2

    fun planFor(level: ThermalMonitor.Level): Plan = when (level) {
        ThermalMonitor.Level.NORMAL -> Plan(
            level = level,
            jsFlags = 0,
            frameCapFps = 0,
            pauseBgWork = false,
            renderer = RENDERER_IMPORTANT,
        )
        // 温升初期：**保帧率**，只削最贵的合成项（模糊/阴影/大面积动画）
        ThermalMonitor.Level.WARM -> Plan(
            level = level,
            jsFlags = JsFlags.NO_BACKDROP or JsFlags.LIGHT_SHADOW or JsFlags.NO_NONCORE_ANIM,
            frameCapFps = 60,
            pauseBgWork = false,
            renderer = RENDERER_IMPORTANT,
        )
        // 余量收窄：降帧 + 停非可视区域 + 停粒子，后台任务让路
        ThermalMonitor.Level.TIGHT -> Plan(
            level = level,
            jsFlags = JsFlags.NO_BACKDROP or JsFlags.LIGHT_SHADOW or JsFlags.NO_NONCORE_ANIM or
                JsFlags.NO_PARTICLES or JsFlags.PAUSE_OFFSCREEN,
            frameCapFps = 45,
            pauseBgWork = true,
            renderer = RENDERER_BOUND,
        )
        // 严重降频：只保滚动/点击/可见内容
        ThermalMonitor.Level.SEVERE -> Plan(
            level = level,
            jsFlags = JsFlags.NO_BACKDROP or JsFlags.LIGHT_SHADOW or JsFlags.NO_NONCORE_ANIM or
                JsFlags.NO_PARTICLES or JsFlags.PAUSE_OFFSCREEN or JsFlags.LOWER_CANVAS,
            frameCapFps = 30,
            pauseBgWork = true,
            renderer = RENDERER_WAIVED,
        )
    }

    /** 一行的可读摘要，进 engine.log / dump()。 */
    fun describe(plan: Plan): String =
        "level=${plan.level.name} fps=${if (plan.frameCapFps == 0) "∞" else plan.frameCapFps}" +
            " jsFlags=0x%02X pauseBg=${plan.pauseBgWork} renderer=${plan.renderer}".format(plan.jsFlags)
}

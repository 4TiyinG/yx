package app.dsh.mobile.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import app.dsh.mobile.engine.BackgroundThreads

/**
 * 热预算与性能提示（v1.6.35）—— ADPF 的宿主侧实现。
 *
 * ## 为什么需要它
 *
 * 用户现象：手机热起来之后，WebUI 滑动发黏、点击延迟、偶尔整页顿住。
 * 这类「越热越卡」有明确的物理成因，不是玄学：
 *
 * 1. **CPU 降频**：SoC 结温到阈值后调度器压频，单核吞吐可掉 40%~60%；
 * 2. **GPU 降频更早**：合成/栅格化先于 CPU 受限，于是「主线程没算完」和
 *    「算完了合不出来」同时出现；
 * 3. **内存回收介入**：热态下系统更倾向 direct reclaim / kswapd，page fault
 *    把帧时间拉出尖峰（这一条在 WebView 大 Tile Cache 时尤其明显）。
 *
 * 结论：**降频不是「跑得慢一点」，而是「同一份工作量所需时间整体上移」**。
 * 所以正确做法不是「等它变卡再补救」，而是**在还能跑的时候先把负载降下来** ——
 * 这正是 ADPF（Android Dynamic Performance Framework）的设计意图：
 *
 * - **Thermal API**（`getCurrentThermalStatus` / `getThermalHeadroom`）：读系统
 *   给出的热压力与**剩余余量**，据此**提前**降载；
 * - **Performance Hint**（`PerformanceHintManager`）：把每帧的**实际耗时**告诉
 *   调度器，让它在有预算时给足频率、在没预算时平滑降频，而不是忽然掐一下。
 *
 * ## 为什么不用「实时温度」
 *
 * Android 没有稳定公开的温度读数（`/sys/class/thermal/…` 各厂商路径不一致、
 * 且多数 ROM 限制应用读取）。公开且稳定的只有这两个聚合信号，它们已经是
 * 调度器内部决策的结果，比温度更有决策价值。
 *
 * ## 分级与滞回（本类的核心）
 *
 * 四级 [Level.CRITICAL 见 Level]：NORMAL → WARM → TIGHT → SEVERE。
 * 目标级别由四个输入合成：
 *
 * ```
 * 目标 = max( 热状态档, 余量档, 省电模式档, 掉帧档 )
 * ```
 *
 * 然后经过**双重滞回**才真正切换（这是「防画质抖动」的关键，需求明确要求）：
 *
 * | 方向 | 条件 | 最短保持 |
 * |---|---|---|
 * | 升档 | 目标 > 当前，且持续 [UP_DWELL_MS] | 升一次只走**一级** |
 * | 降档 | 目标 < 当前，且持续 [DOWN_DWELL_MS] | 降一次只走**一级** |
 *
 * 为什么不直接跳到目标档：
 * · 跳档会让页面侧效果「唰」地全没（用户能看见的突变比慢一点更糟）；
 * · 过热往往是**脉冲式**的（切个后台再回来、跑一次 GC），跳档等于把脉冲放大。
 *
 * 升档 2s、降档 8s 的取值理由：升档要快（热积累是单调的，晚降载就是真降频），
 * 降档要慢（余量恢复常是假象 —— 降载之后温度立刻回落一点点，若马上恢复满负荷，
 * 就会进入「降载→升温→再降载」的振荡，正是抖动来源）。
 *
 * ## 谁消费这个级别
 *
 * · [ThermalPolicy] → 具体动作（帧率上限、JS 降级位、后台任务暂停）；
 * · [RenderBudget.setFrameCap] → 全局帧率地板；
 * · 页面侧 `js/thermal-degrade.js` → 削减合成层/模糊/粒子，rAF 降频。
 *
 * 本类**只做判定**，不做任何 UI/JS 操作 —— 便于在探针里单测状态机。
 */
object ThermalMonitor {

    private const val TAG = "ThermalMonitor"

    /**
     * 热压力档位。数值即优先级：`max` 取最严重的那一个。
     *
     * 与 Android `PowerManager.THERMAL_STATUS_*` 的映射见 [fromThermalStatus]。
     */
    enum class Level {
        /** 无压力：满帧、全部效果 */
        NORMAL,

        /** 温升初期：保帧率，先削页面侧非核心效果 */
        WARM,

        /** 余量收窄：降帧 + 暂停非可视区域动效 + 允许暂停后台任务 */
        TIGHT,

        /** 严重降频：只保核心交互（滚动/点击/可见内容更新） */
        SEVERE,
    }

    // ---------------------------------------------------------------- 阈值

    /** 升档前必须持续满足目标的时间 */
    private const val UP_DWELL_MS = 2_000L

    /** 降档前必须持续满足目标的时间（比升档长得多，专门抑制振荡） */
    private const val DOWN_DWELL_MS = 8_000L

    /** 判定周期：1s 足够跟上温升，又不会自己变成负担 */
    private const val TICK_MS = 1_000L

    /**
     * 热余量（`getThermalHeadroom`）的分档阈值。
     *
     * 该 API 返回 [0,1]：0 = 凉爽、1 = 已到降频阈值。它比 thermal status **更早**
     * 给出信号（status 是「已经降了」，headroom 是「快要降了」），所以用它做预降载。
     */
    private const val HEADROOM_WARM = 0.60f
    private const val HEADROOM_TIGHT = 0.80f
    private const val HEADROOM_SEVERE = 0.92f

    /** 前瞻秒数：10s 是官方示例值，覆盖「一段滑动的时长」 */
    private const val HEADROOM_FORECAST_S = 10

    // ---------------------------------------------------------------- 状态

    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var level: Level = Level.NORMAL

    /** 当前**目标**级别（未经过滞回），仅用于日志与诊断 */
    @Volatile private var rawTarget: Level = Level.NORMAL

    private var pendingTarget: Level? = null
    private var pendingSince = 0L

    @Volatile private var attached = false
    private var appContext: Context? = null
    private var powerManager: PowerManager? = null
    private var thermalListener: Any? = null
    private var hintSession: Any? = null

    /** 最近一次从 RenderBudget 读到的帧间隔 EMA（ms） */
    @Volatile private var frameEmaMs = 0.0

    private val listeners = mutableListOf<(Level) -> Unit>()

    /** 当前级别（任意线程可读） */
    val current: Level get() = level

    /** 目标级别（未滞回），诊断用 */
    val target: Level get() = rawTarget

    // ---------------------------------------------------------------- 生命周期

    /**
     * 开始监听。幂等；重复调用只更新 Context。
     *
     * 用 applicationContext：监听要跟进程生命周期一致，不该被 Activity 泄漏绑住。
     */
    fun attach(ctx: Context) {
        appContext = ctx.applicationContext
        if (attached) return
        attached = true
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
        powerManager = pm
        // ── Thermal API（API 29+）─────────────────────────────────────────────
        // 用 addThermalStatusListener 而不是轮询：系统本来就会在状态跃变时通知，
        // 轮询只会白白唤醒 CPU（热态下唤醒本身就是负担）。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { ThermalCompat.registerStatusListener(pm, onThermalStatus) }
                .onSuccess { thermalListener = it }
                .onFailure { Log.w(TAG, "thermal listener unavailable: ${it.message}") }
        }
        // ── Performance Hint 会话（API 31+）──────────────────────────────────
        hintSession = PerformanceHintCompat.create(appContext)
        // ── 省电模式变化（API 21+，用广播）───────────────────────────────────
        runCatching {
            ctx.applicationContext.registerReceiver(
                powerSaveReceiver,
                IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED),
            )
        }.onFailure { Log.w(TAG, "power-save receiver failed: ${it.message}") }

        handler.removeCallbacks(tick)
        handler.postDelayed(tick, TICK_MS)
        Log.i(TAG, "attached (sdk=${Build.VERSION.SDK_INT}, hint=${hintSession != null})")
    }

    /** 停止监听并释放会话。幂等。 */
    fun detach() {
        if (!attached) return
        attached = false
        handler.removeCallbacks(tick)
        runCatching {
            @Suppress("UNCHECKED_CAST")
            val l = thermalListener as? PowerManager.OnThermalStatusChangedListener
            if (l != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                powerManager?.removeThermalStatusListener(l)
            }
        }
        thermalListener = null
        PerformanceHintCompat.close(hintSession)
        hintSession = null
        runCatching { appContext?.unregisterReceiver(powerSaveReceiver) }
        appContext = null
        powerManager = null
    }

    /** 注册级别变化回调（在主线程回调）。返回移除函数。 */
    fun addListener(l: (Level) -> Unit): () -> Unit {
        listeners += l
        return { listeners.remove(l) }
    }

    /**
     * 上报一帧的**实际耗时**给 ADPF。
     *
     * 这是「预降载」的另一半：告诉调度器「我一帧要这么久」，它才能在频率预算里
     * 优先保证这段时间。不报的话调度器只能看 CPU 占用率猜。
     *
     * @param actualNs 本帧实际耗时（从帧开始到 GPU 完成，或到提交为止的近似值）
     */
    fun reportFrame(actualNs: Long) {
        PerformanceHintCompat.report(hintSession, actualNs)
    }

    /** 掉帧信号：由 RenderBudget 在每次分发后上报帧间隔 EMA（ms）。 */
    fun feedFrameInterval(emaMs: Double) {
        frameEmaMs = emaMs
    }

    // ---------------------------------------------------------------- 判定

    private val tick = object : Runnable {
        override fun run() {
            if (!attached) return
            runCatching { evaluate() }
            handler.postDelayed(this, TICK_MS)
        }
    }

    private val onThermalStatus: (Int) -> Unit = { status ->
        // 状态跃变是「事件」，立刻评估一次，不等 1s 的 tick —— 降载晚 1 秒就是
        // 真降频了 1 秒。但**切换**仍受滞回约束（[applyWithHysteresis]）。
        runCatching { evaluate() }
        Log.i(TAG, "thermal status=$status → target=${rawTarget.name}")
    }

    private val powerSaveReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            runCatching { evaluate() }
            Log.i(TAG, "power save mode changed → target=${rawTarget.name}")
        }
    }

    /**
     * 合成目标级别，并按滞回规则推进实际级别。
     *
     * 只在主线程调用（tick / 广播 / thermal 回调都在主线程）。
     */
    private fun evaluate() {
        frameEmaMs = runCatching { RenderBudget.stats().intervalEmaMs }.getOrDefault(frameEmaMs)
        val pm = powerManager

        // ① 热状态（API 29+）
        var target = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            fromThermalStatus(ThermalCompat.currentStatus(pm))
        } else {
            Level.NORMAL
        }
        // ② 热余量（API 30+）：比状态更早，用于预降载
        val headroom = ThermalCompat.headroom(pm)
        if (headroom >= HEADROOM_SEVERE) target = max(target, Level.SEVERE)
        else if (headroom >= HEADROOM_TIGHT) target = max(target, Level.TIGHT)
        else if (headroom >= HEADROOM_WARM) target = max(target, Level.WARM)

        // ③ 省电模式：用户明确要求省电时至少 WARM（少一点效果、少一点唤醒）
        if (pm?.isPowerSaveMode == true) target = max(target, Level.WARM)

        // ④ 掉帧：帧间隔 EMA 连续超过名义值 1.6 倍 → 至少 TIGHT。
        //    注意这用的是 RenderBudget 已有的实测值，不额外测量。
        val ema = frameEmaMs
        if (ema > 60.0) target = max(target, Level.SEVERE)
        else if (ema > 26.7) target = max(target, Level.TIGHT)   // 60Hz 名义 16.67 × 1.6

        rawTarget = target
        applyWithHysteresis(target)
    }

    /**
     * 滞回推进：一次只走一级，且必须持续满足方向条件。
     *
     * 这是「防画质抖动」的实现点，改动务必小心 —— 去掉最短保持时间会让页面在
     * 热边界上来回切换效果，比一直卡着更难受。
     */
    private fun applyWithHysteresis(target: Level) {
        val cur = level
        if (target == cur) {
            pendingTarget = null
            return
        }
        val now = System.currentTimeMillis()
        val upgrading = target.ordinal > cur.ordinal
        val dwell = if (upgrading) UP_DWELL_MS else DOWN_DWELL_MS

        // 方向变了（例如刚想升档又回落）→ 重新计时
        val pending = pendingTarget
        if (pending != target) {
            pendingTarget = target
            pendingSince = now
            // 首次满足条件不立刻切换：必须真的持续 dwell 这么久
            return
        }
        if (now - pendingSince < dwell) return

        // 一次只走一级：升级 cur+1，降级 cur-1。
        // 即使目标再严重，也给页面侧一个「逐级适应」的机会。
        val next = if (upgrading) {
            Level.entries[cur.ordinal + 1]
        } else {
            Level.entries[cur.ordinal - 1]
        }
        pendingTarget = null
        applyLevel(next)
    }

    private fun applyLevel(next: Level) {
        val prev = level
        level = next
        Log.i(
            TAG,
            "thermal level ${prev.name} → ${next.name} " +
                "(raw=$rawTarget ema=%.1fms headroom=%.2f)".format(
                    frameEmaMs, ThermalCompat.headroom(powerManager),
                ),
        )
        // 回调异常不能影响其余监听者
        for (l in listeners.toList()) {
            runCatching { l(next) }
                .onFailure { Log.w(TAG, "listener threw: ${it.javaClass.simpleName}") }
        }
        // 级别变化时把「后台可做的工作」一起管起来（SEVERE/TIGHT 暂停，NORMAL 补做）
        DeferredWork.setPaused(next.ordinal >= Level.TIGHT.ordinal)
    }

    private fun max(a: Level, b: Level): Level = if (a.ordinal >= b.ordinal) a else b

    /**
     * Android 热状态 → 本类级别。
     *
     * NONE→NORMAL、LIGHT→WARM、MODERATE→TIGHT、SEVERE 及以上→SEVERE。
     * CRITICAL/EMERGENCY/SHUTDOWN 全部折算成 SEVERE：对应用来说它们的差别是
     * 「系统还剩几秒掐你」，能做的动作完全一样（保核心交互）。
     */
    private fun fromThermalStatus(status: Int): Level = when (status) {
        0 -> Level.NORMAL                    // THERMAL_STATUS_NONE
        1 -> Level.WARM                      // LIGHT
        2 -> Level.TIGHT                     // MODERATE
        else -> Level.SEVERE                 // SEVERE / CRITICAL / EMERGENCY / SHUTDOWN
    }

    // ---------------------------------------------------------------- 诊断

    fun dump(): String {
        val sb = StringBuilder()
        sb.append("thermal level=").append(level.name)
        sb.append(" raw=").append(rawTarget.name)
        sb.append(" ema=").append("%.1fms".format(frameEmaMs))
        sb.append(" headroom=").append("%.2f".format(ThermalCompat.headroom(powerManager)))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            sb.append(" status=").append(ThermalCompat.currentStatus(powerManager))
        }
        sb.append(" hint=").append(hintSession != null)
        return sb.toString()
    }

    /**
     * 测试/诊断用：强制把级别设成指定值（跳过滞回）。
     *
     * 仅用于「设置里的手动档位」与探针；正常路径永远走 [applyWithHysteresis]。
     */
    fun forceLevel(level: Level, reason: String) {
        Log.i(TAG, "forced level → ${level.name} ($reason)")
        applyLevel(level)
    }

    /** 供探针使用：重置到 NORMAL 并清空滞回状态。 */
    fun resetForTest() {
        pendingTarget = null
        pendingSince = 0L
        level = Level.NORMAL
        rawTarget = Level.NORMAL
        frameEmaMs = 0.0
    }
}

/**
 * Thermal API 的版本兼容层（API 29 / 30 的门槛都在这里）。
 *
 * 单独拆出来是为了让主类保持可读，并且**只有这一处**需要 `@RequiresApi` 之类的
 * 版本判断 —— 版本判断散落在业务代码里是后续出错的常见来源。
 */
internal object ThermalCompat {

    /** 当前热状态；低于 API 29 返回 0（NONE）。 */
    @android.annotation.SuppressLint("NewApi")
    fun currentStatus(pm: PowerManager?): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && pm != null) {
            runCatching { pm.currentThermalStatus }.getOrDefault(0)
        } else {
            0
        }

    /**
     * 热余量 [0,1]；低于 API 30、或该机型未实现时返回 0（= 无预兆）。
     *
     * ⚠️ 不少机型在此 API 上恒返回 0.0 或 1.0（未实现/异常）。所以**它只作为
     * 「提前降载」的加分项**，主判据仍是 thermal status —— 否则一个恒返回 1.0
     * 的机型会永久卡在 SEVERE。
     */
    @android.annotation.SuppressLint("NewApi")
    fun headroom(pm: PowerManager?): Float =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && pm != null) {
            runCatching { pm.getThermalHeadroom(10) }.getOrDefault(0f)
        } else {
            0f
        }

    /** 注册热状态监听（API 29+），返回监听器本身供后续注销。 */
    @android.annotation.SuppressLint("NewApi")
    fun registerStatusListener(
        pm: PowerManager?,
        onStatus: (Int) -> Unit,
    ): Any? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || pm == null) return null
        val listener = PowerManager.OnThermalStatusChangedListener { status -> onStatus(status) }
        // 回调投递到后台线程：thermal 状态跃变可能发生在 binder 线程，
        // 而我们的 evaluate() 需要主线程 Handler —— 交给 tick 侧统一处理，
        // 这里只要求「不在系统回调线程上做业务」（避免任何形式的阻塞风险）。
        val executor = java.util.concurrent.Executor { r ->
            BackgroundThreads.startRaw("thermal-cb") { r.run() }
        }
        pm.addThermalStatusListener(executor, listener)
        return listener
    }
}

/**
 * Performance Hint 会话（API 31+）。低版本一律 no-op。
 *
 * ## 会话里放哪些线程
 *
 * ADPF 的语义是「这些线程共同完成一帧」。本 App 的帧关键线程有两条：UI 线程与
 * WebView 的 **RenderThread**。后者是 Chromium 创建的 native 线程，**公开 SDK 拿不到
 * 它的 tid**（`ThreadedRenderer` 不暴露），所以这里只能登记 UI 线程 ——
 * 这是本实现的已知局限，已在文档里写明；如需完整覆盖要用 NDK 的
 * `APerformanceHint_createSession` 并在 native 侧登记。
 *
 * 即便只有 UI 线程，收益也是真实的：UI 线程的 `onDraw`/measure/layout 与
 * 输入分发都在它上面，正是冷启动与滑动时最容易掉帧的一段。
 */
internal object PerformanceHintCompat {

    private var unavailable = false

    /**
     * 创建会话；不可用时返回 null（不抛，不影响启动）。
     *
     * @param ctx 用来取 `PerformanceHintManager` 系统服务
     */
    @android.annotation.SuppressLint("NewApi")
    fun create(ctx: Context?): Any? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        if (unavailable || ctx == null) return null
        return try {
            val mgr = ctx.getSystemService(android.os.PerformanceHintManager::class.java)
                ?: return null
            val uiTid = android.os.Process.myTid()
            // 目标时长按 60Hz 给（16.7ms）。系统会以此为基准做频率规划，
            // 具体帧率上限由 RenderBudget 的帧地板另行控制 —— 两者职责不同：
            // 这个告诉调度器「我需要多少」，帧地板是「我自己主动少要一点」。
            mgr.createHintSession(intArrayOf(uiTid), 16_670_000L)
        } catch (t: Throwable) {
            // 机型未实现 / 会话数超限 / 权限受限 都会走到这里，均不影响主流程
            unavailable = true
            android.util.Log.w("PerfHint", "unsupported: ${t.javaClass.simpleName}: ${t.message}")
            null
        }
    }

    @android.annotation.SuppressLint("NewApi")
    fun report(session: Any?, actualNs: Long) {
        val s = session as? android.os.PerformanceHintManager.Session ?: return
        runCatching { s.reportActualWorkDuration(actualNs) }
    }

    @android.annotation.SuppressLint("NewApi")
    fun close(session: Any?) {
        val s = session as? android.os.PerformanceHintManager.Session ?: return
        runCatching { s.close() }
    }
}

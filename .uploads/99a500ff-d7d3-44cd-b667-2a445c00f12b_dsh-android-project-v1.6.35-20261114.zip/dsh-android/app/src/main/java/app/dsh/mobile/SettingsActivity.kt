package app.dsh.mobile

import android.app.AlertDialog
import android.Manifest
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import app.dsh.mobile.engine.ExtensionManager
import app.dsh.mobile.engine.FakeLinuxEnv
import app.dsh.mobile.engine.PluginFastBoot
import app.dsh.mobile.engine.PluginPriority
import app.dsh.mobile.engine.PrivMode
import app.dsh.mobile.engine.Privilege
import app.dsh.mobile.engine.RuntimeDownloadConfig
import app.dsh.mobile.engine.LanWebProxy

/**
 * 独立设置页（MIUI 分组卡片风格，替代原先的悬浮菜单）。
 *
 * 三个分组：
 *  - 显示：屏幕朝向（竖屏/横屏/自动，v1.2.120）、页面缩放
 *  - 权限中心（统一管理运行权限与无障碍）：运行权限模式、Root 能力状态、Shizuku 状态、屏幕点击（无障碍）
 *  - 其他：重启引擎、关于
 *
 * 权限切换与缩放均复用 MainActivity 的既有决策（Root 双警告、缩放 −/＋ 步进、
 * 无障碍跳系统设置），落库到同一组 SharedPreferences，MainActivity 在 onResume 重新读取生效。
 */
class SettingsActivity : ThemedActivity() {
    /** 属于设置体系：启用「设置页背景图」（见 ThemedActivity.usesSettingsBackground）。 */
    override val usesSettingsBackground: Boolean get() = true


    /** 上次应用的主题/强调色/布局快照：子页改动后回到本页检测重建（v1.4.56） */
    private var appliedTheme: ThemeMode = ThemeMode.DARK
    private var appliedAccent: Int = 0
    private var appliedLayout: SettingsLayoutMode = SettingsLayoutMode.LIST

    // ─── 头部折叠停靠（v1.6.23）───────────────────────────────────────────
    // 只有一个可变位：正在跑的吸附动画。没有 isCollapsed 开关 —— 头部外观永远是
    // scrollY 的纯函数（applyHeaderTransform），所以拖动、吸附动画、被打断后的
    // 接管，走的是同一条映射，不会跳变。
    private var headerAnim: android.animation.ValueAnimator? = null
    private var settleTick: Runnable? = null
    private var userDragging = false
    private val settleHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var headerScrollRef: android.widget.ScrollView? = null

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // v1.5.x：大屏跟随偏好、手机锁竖屏；用户可在外观页打开「设置页跟随屏幕方向」
        OrientationPrefs.applyToSettingsPage(this)
        setContentView(R.layout.activity_settings)
        findViewById<LinearLayout>(R.id.rowAppProfile)?.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
        setupSearch()
        applyResponsiveLayout()


        // —— 扩展：局域网访问 WebUI（v1.2.160/v1.2.161）——
        // 独立端口 3090 的反向代理，让同网段设备用原生 WebUI 连上本机引擎。
        // v1.2.161（用户要求）：验证码改为 **6 位数字 + 每次开启重新随机**，
        // 生成后**自动复制到剪贴板**，且**只在应用内显示一次**（退出再进设置不显示）。
        val swLan = findViewById<android.widget.Switch>(R.id.swLanWeb)
        val lanSub = findViewById<android.widget.TextView>(R.id.lanWebSub)
        // ⚠️ v1.2.162 实测修复（用户反馈"关闭时显示网址、开启时反而不显示"）：
        // 旧实现用 LanWebProxy.isRunning() 判断 —— 但代理的启停都是**异步**的
        // （拉起要 1-3s，停止要等进程回收）→ 点开关的瞬间读到的还是旧状态，
        // 表现正好相反。改为**以开关自身的状态为准**（用户看到的就是他点的那个状态），
        // 地址只在该状态为"开"时展示。
        // v1.2.162（用户要求）：**行内不再保留验证码** —— 验证码只在开启时的
        // 提示框里显示一次，避免长期驻留。行内只显示说明与访问地址。
        fun lanSubText() {
            val on = swLan.isChecked
            val addr = "http://" + (LanWebProxy.lanAddress() ?: "?") + ":" + LanWebProxy.PORT
            lanSub.text = if (!on) getString(R.string.setting_lan_web_sub)
            else getString(R.string.setting_lan_web_sub) + "\n\n" + addr
        }
        /** 复制到剪贴板（6 位码，方便直接粘到电脑上） */
        fun copyCode(code: String) {
            runCatching {
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                    as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("DSH LAN code", code))
            }
        }
        swLan.isChecked = DshApp.lanWebEnabled(this)
        // v1.2.162：验证码只在**刚生成时**用提示框展示一次（行内不再保留）。
        val pendingShown = DshApp.lanWebPwPending(this)
        if (pendingShown && DshApp.lanWebEnabled(this)) {
            val c = DshApp.lanWebPassword(this)
            runCatching {
                LanAccessDialog.show(
                    this, c,
                    "http://" + (LanWebProxy.lanAddress() ?: "?") + ":" + LanWebProxy.PORT,
                )
            }
            DshApp.markLanWebPwShown(this)   // 只显示一次
        }
        lanSubText()
        swLan.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                AlertDialog.Builder(this)
                    .setTitle(R.string.setting_lan_web)
                    .setMessage(R.string.lan_web_consent)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        DshApp.setLanWebEnabled(this, true)
                        // 每次开启都重新生成 6 位验证码
                        val code = DshApp.regenerateLanWebPassword(this)
                        // v1.2.162（用户要求）：改用「提示框」展示 —— 验证码显著、可点复制；
                        // 访问地址紧贴其下（小字、也可复制）；行内不再保留验证码。
                        runCatching {
                            LanAccessDialog.show(
                                this, code,
                                "http://" + (LanWebProxy.lanAddress() ?: "?") + ":" + LanWebProxy.PORT,
                            )
                        }
                        lanSubText()
                        DshApp.markLanWebPwShown(this)
                        Thread({
                            runCatching { LanWebProxy.start(code) }
                                .onFailure { android.util.Log.w("Settings", "lan proxy: ${it.message}") }
                        }, "lan-start").apply { isDaemon = true }.start()
                    }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> swLan.isChecked = false }
                    .setOnCancelListener { swLan.isChecked = false }
                    .show()
            } else {
                DshApp.setLanWebEnabled(this, false)
                Thread({ runCatching { LanWebProxy.stop() } }, "lan-stop").apply { isDaemon = true }.start()
                lanSubText()
            }
        }

        // —— 扩展：运行时下载代理（v1.4.21）——
        // 运行时 zip / 签名索引都从 GitHub Releases 取；国内直连经常超时。
        // 默认 gh-proxy.org，可换自建前缀，留空则直连。
        refreshRuntimeProxyRow()
        findViewById<LinearLayout>(R.id.rowRuntimeProxy).setOnClickListener {
            showRuntimeProxyDialog()
        }


        // —— 顶部返回 ——

        // —— 个性化入口（v1.4.56）：外观/扩展整组收进子页，主页只留入口 ——
        val savedLayout = SettingsLayoutMode.current(this)
        appliedTheme = ThemePref.get(this)
        appliedAccent = Accent.current(this).argb
        appliedLayout = savedLayout
        findViewById<LinearLayout>(R.id.rowAppearance).setOnClickListener {
            startActivity(Intent(this, AppearanceActivity::class.java))
        }
        // v1.4.58（宝宝要求）：扩展中心不再分组，直接显示在设置第一屏
        findViewById<LinearLayout>(R.id.rowExt).setOnClickListener {
            startActivity(Intent(this, ExtensionStoreActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.rowExtensionVoice).setOnClickListener {
            startActivity(Intent(this, ExtensionVoiceActivity::class.java))
        }
        if (savedLayout != SettingsLayoutMode.LIST) {
            // 布局参数改动需要在视图完成布局后进行
            findViewById<View>(R.id.columnPrimary)?.post { applyLayoutMode(savedLayout) }
        }

        // —— 权限与能力：运行身份 + 系统能力合并为同一页 ——
        findViewById<LinearLayout>(R.id.rowPermEngine).setOnClickListener {
            startActivity(Intent(this, PermissionCenterActivity::class.java))
        }


        // 自定义指令（v1.3.2，issue #19）：在 App 的环境说明之上补写用户自己的长期指令。
        // 落点是 AGENTS.md 的用户段 —— 引擎只加载这一个 user-global 指令文件，
        // 分段管理后升级 App 不会丢用户内容，用户改指令也不会让环境说明变旧。
        findViewById<LinearLayout>(R.id.rowUserPrompt).setOnClickListener {
            startActivity(Intent(this, UserPromptActivity::class.java))
        }

        // —— 数据：备份与恢复子页（v1.4.46：导出/导入/恢复对话/配置文件收拢）——
        findViewById<LinearLayout>(R.id.rowBackup).setOnClickListener {
            startActivity(Intent(this, BackupActivity::class.java))
        }

        

        // —— Linux 环境伪装：原生 Android 上模拟 Debian/Linux 识别层 ——
        val fakeLinux = findViewById<android.widget.Switch>(R.id.swFakeLinux)
        fakeLinux?.isChecked = FakeLinuxEnv.enabled(this)
        fakeLinux?.setOnCheckedChangeListener { _, on ->
            FakeLinuxEnv.setEnabled(this, on)
            Toast.makeText(this, R.string.fake_linux_restarting, Toast.LENGTH_SHORT).show()
            (application as DshApp).supervisor.restart()
        }

        // —— 插件快速启动：先显示 WebUI，第三方插件后台流式加载 ——
        val fastBoot = findViewById<android.widget.Switch>(R.id.swFastPluginBoot)
        fastBoot?.isChecked = PluginFastBoot.enabled(this)
        fastBoot?.setOnCheckedChangeListener { _, on ->
            PluginFastBoot.setEnabled(this, on)
            Toast.makeText(this, R.string.fast_plugin_boot_changed, Toast.LENGTH_SHORT).show()
        }

        // —— 插件加载优先级（v1.6.29）：已装的 dsh-web-mobile 排到最前、首轮就绪 ——
        // 关掉 = 它不再排首位、也不排除在「推迟加载」之外（下次启动引擎生效）。
        val priority = findViewById<android.widget.Switch>(R.id.swPluginPriority)
        priority?.isChecked = PluginPriority.enabled(this)
        priority?.setOnCheckedChangeListener { _, on ->
            PluginPriority.setEnabled(this, on)
            Toast.makeText(this, R.string.plugin_priority_changed, Toast.LENGTH_SHORT).show()
            (application as DshApp).supervisor.restart()
        }

        // —— 维护与高级（v1.4.45）：诊断与高风险操作收进子页，主页只留入口 ——
        findViewById<LinearLayout>(R.id.rowMaintenance).setOnClickListener {
            startActivity(Intent(this, MaintenanceActivity::class.java))
        }

        // —— 其他：语言 Language（v1.2.120：en/de/zh 三选一，默认 en）——
        // 语言名一律用该语言自身的写法（endonym）：中文恒为「中文」、德语恒为
        // 「Deutsch」、葡语恒为「Português」，泰语恒为「ไทย」。这样无论当前界面是哪种语言，用户在
        // 列表里都能靠母语认出自己要选的那一项（旧实现按当前 locale 翻译成
        // 「Chinese / Chinesisch / Chinês」，中文用户看到的反而是外语）。
        val langCodes = listOf("en", "de", "zh", "pt", "th")
        fun langLabel(code: String): String = when (code) {
            "zh" -> getString(R.string.lang_zh)
            "de" -> getString(R.string.lang_de)
            "pt" -> getString(R.string.lang_pt)
            "th" -> getString(R.string.lang_th)
            else -> getString(R.string.lang_en)
        }
        val langSub = findViewById<TextView>(R.id.appLanguageSub)
        fun refreshLangSub() {
            langSub.text = getString(
                R.string.app_language_sub_current,
                langLabel(LocaleHelper.get(this)),
            )
        }
        refreshLangSub()
        findViewById<LinearLayout>(R.id.rowLanguage).setOnClickListener {
            val choices = arrayOf(
                getString(R.string.lang_en),
                getString(R.string.lang_de),
                getString(R.string.lang_zh),
                getString(R.string.lang_pt),
                getString(R.string.lang_th),
            )
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_language))
                .setSingleChoiceItems(choices, langCodes.indexOf(LocaleHelper.get(this))) { dlg, which ->
                    val code = langCodes[which]
                    if (code == LocaleHelper.get(this)) { dlg.dismiss(); return@setSingleChoiceItems }
                    LocaleHelper.set(this, code)
                    dlg.dismiss()
                    // 立即生效：本页原地重建（recreate 会重走 attachBaseContext →
                    // 按新语言重新 inflate 布局），用户马上看到文案变化。
                    //
                    // 旧实现是「清任务栈 + 重新拉起 Launcher」——那是跨进程重建，
                    // 用户实测「切换后 UI 不能及时响应」（要等整个应用重开）。
                    // 现在只重建当前页；MainActivity 在 onResume 会检测到语言变化
                    // 并自行重建，返回主界面时也是新语言。
                    recreate()
                }
                .showStyled()
        }

        // —— 其他：关于 ——
        findViewById<TextView>(R.id.subAbout).text =
            getString(R.string.setting_about_sub, versionName())
        findViewById<LinearLayout>(R.id.rowAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }

    /** 从包管理器读取 versionName（AGP 8+ 默认关闭 BuildConfig，避免依赖它） */
    private fun versionName(): String =
        runCatching { packageManager.getPackageInfo(packageName, 0).versionName }
            .getOrNull() ?: "?"

    

    /**
     * 转屏不重建（Manifest 已声明 configChanges）：只切换宽/窄布局，
     * 保留滚动位置、已打开的对话框和进行中的数据导出/扩展安装任务。
     *
     * ⚠️ 必须把 [newConfig] 传下去：此刻 `resources.configuration` 仍是**转屏前**的
     * 那一份（实测 newCfg 800dp/竖屏、res 1280dp/横屏），照着 resources 算会把
     * 横屏双栏硬塞进竖屏里。
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyResponsiveLayout(newConfig)
    }

    override fun onResume() {
        super.onResume()
        // 从外观页返回时偏好可能已变（开关/朝向），重新对齐一次；值未变时是空操作
        OrientationPrefs.applyToSettingsPage(this)
        // 子页里改过主题/强调色/布局：回到本页立即重建，保证视觉与偏好一致（v1.4.56）
        if (appliedTheme != ThemePref.get(this) ||
            appliedAccent != Accent.current(this).argb ||
            appliedLayout != SettingsLayoutMode.current(this)
        ) {
            recreate()
            return
        }
        refreshAppearanceEntry()
        refreshExtEntry()
    }

    /** 个性化入口副标题：当前主题 · 强调色（v1.4.56） */
    private fun refreshAppearanceEntry() {
        findViewById<TextView>(R.id.subAppearanceEntry)?.text = getString(
            R.string.setting_appearance_sub,
            getString(ThemePref.get(this).labelRes),
            getString(Accent.current(this).labelRes),
        )
    }

    /** 扩展中心行副标题：已激活扩展数（v1.4.58 起该行回到主页第一屏） */
    private fun refreshExtEntry() {
        val count = runCatching { ExtensionManager(this).activeCount() }.getOrDefault(0)
        findViewById<TextView>(R.id.valExt)?.text =
            getString(R.string.setting_ext_active_count, count)
    }

    // ================= 设置搜索（参考图顶部搜索框） =================

    private var searchOpen = false

    // ================= 设置搜索（覆盖层 + 展开/收起动画） =================

    private fun setupSearch() {
        val home = findViewById<android.widget.EditText>(R.id.searchSettings)
        home?.isFocusable = false
        home?.isFocusableInTouchMode = false
        home?.isCursorVisible = false
        home?.setOnClickListener { openSearch() }
        findViewById<View>(R.id.btnVoiceSearch)?.setOnClickListener { startVoiceSearch() }

        val input = findViewById<android.widget.EditText>(R.id.searchInput)
        input?.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                renderSearch(s?.toString().orEmpty())
            }
        })
        findViewById<View>(R.id.btnSearchClear)?.setOnClickListener {
            input?.setText("")
            input?.requestFocus()
        }
        findViewById<View>(R.id.btnSearchCancel)?.setOnClickListener { closeSearch() }
        setupScrollEffect()
    }

    /** 大标题收缩吸顶、搜索框压缩淡出（对齐预览页 115/60 进度）。 */
    private fun setupScrollEffect() {
        val scroller = findViewById<android.widget.ScrollView>(R.id.settingsScroller) ?: return
        val title = findViewById<TextView>(R.id.settingsTitle) ?: return
        val bar = findViewById<View>(R.id.homeSearchBar) ?: return
        title.pivotX = 0f
        title.pivotY = 0f
        bar.pivotY = 0f
        headerScrollRef = scroller
        scroller.setOnScrollChangeListener { _, _, y, _, _ ->
            if (searchOpen) return@setOnScrollChangeListener
            applyHeaderTransform(y)
        }
        installHeaderSnap(scroller)
    }

    /**
     * 折叠区间的两个停靠点（v1.6.23）。规格里的 px 在代码里一律走 dp()，
     * 与既有 applyHeaderTransform 的 dp(115)/dp(60)/dp(46) 同一单位体系。
     */
    private val collapseEndPx get() = dp(115)
    private val snapAtPx get() = dp(60)

    /**
     * 接入停靠判定。返回 false 不消费事件 —— 滚动、fling、点击分发仍由
     * ScrollView 自己做，我们只在旁边看一眼手指何时离屏。
     */
    private fun installHeaderSnap(scroller: android.widget.ScrollView) {
        scroller.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    userDragging = true
                    // 规格 5：用户输入优先。动画只写过 scrollY，这里 cancel 后
                    // 从当前 scrollY 接着拖，不需要任何补齐。
                    cancelHeaderAnim()
                    cancelSettle()
                }

                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    userDragging = false
                    // 规格 6：松手不立即判定。fling 还在跑时抢着 scrollTo，会和
                    // OverScroller 互拉，表现为“半路被拽一下”或二次回弹。
                    if (!searchOpen) armSettle(scroller)
                }
            }
            false
        }
    }

    /**
     * 等惯性自然停稳：每 8ms 采样一次 scrollY，连续 [SETTLE_IDLE_MS] 不变就认为 fling 结束。
     * 只靠时间阈值而不靠“fling 完毕”回调：ScrollView 没有对外暴露 OverScroller 状态。
     */
    private fun armSettle(scroller: android.widget.ScrollView) {
        cancelSettle()
        var lastY = -1
        var stableSince = 0L
        var waited = 0L
        lateinit var tick: Runnable
        tick = Runnable {
            if (searchOpen || userDragging || headerAnim != null) { cancelSettle(); return@Runnable }
            val y = scroller.scrollY
            val now = android.os.SystemClock.uptimeMillis()
            if (y != lastY) {
                lastY = y
                stableSince = now
            } else if (stableSince > 0 && now - stableSince >= SETTLE_IDLE_MS) {
                cancelSettle()
                decideSnap(y)
                return@Runnable
            }
            waited += SETTLE_TICK_MS
            // 万一 fling 一直不进入静止（长列表到底/到顶的微振荡），1.2s 后也要收场，
            // 不能让这个采样循环常驻。
            if (waited < SETTLE_MAX_WAIT_MS) settleHandler.postDelayed(tick, SETTLE_TICK_MS)
            else { cancelSettle(); decideSnap(scroller.scrollY) }
        }
        settleTick = tick
        settleHandler.postDelayed(tick, SETTLE_TICK_MS)
    }

    private fun cancelSettle() {
        settleTick?.let { settleHandler.removeCallbacks(it) }
        settleTick = null
    }

    private fun cancelHeaderAnim() {
        headerAnim?.cancel()
        headerAnim = null
    }

    /** 规格 2/3/4：同一个判定的三个分支 —— 回 0、吸到 115、或不接管。 */
    private fun decideSnap(off: Int) {
        if (off > collapseEndPx) return          // 区间外：滚动已属于内容，不拽回
        animateHeaderTo(if (off < snapAtPx) 0 else collapseEndPx)
    }

    /**
     * 吸附动画只改滚动偏移（规格 7）。外观仍走 applyHeaderTransform 那一套映射，
     * 因为 scrollTo() 会触发 onScrollChangeListener —— 所以标题与搜索框是“继续
     * 连续变形过去”，不会先跳到终点再补齐。
     */
    private fun animateHeaderTo(target: Int) {
        val scroller = headerScrollRef ?: return
        val from = scroller.scrollY
        if (from == target) return
        if (headerMotionDisabled()) {                    // 规格 8：减弱动效直接瞬跳
            scroller.scrollTo(0, target)
            return
        }
        cancelHeaderAnim()
        headerAnim = android.animation.ValueAnimator.ofInt(from, target).apply {
            duration = HEADER_SNAP_MS
            interpolator = android.view.animation.PathInterpolator(0.215f, 0.61f, 0.355f, 1f) // ease-out cubic
            addUpdateListener { scroller.scrollTo(0, it.animatedValue as Int) }
            // 不用 core-ktx 的 doOnEnd：cancel() 同样会走到这里，用引用比较避开
            // “旧动画的结束回调把新动画的引用摸掉”。
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (headerAnim === animation) headerAnim = null
                }
            })
            start()
        }
    }

    /** 系统“移除动画”开关（开发者选项里的 transition/global animation scale） */
    private fun headerMotionDisabled(): Boolean = runCatching {
        android.provider.Settings.Global.getFloat(
            contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f,
        ) == 0f
    }.getOrDefault(false)

    private fun applyHeaderTransform(scrollY: Int) {
        val title = findViewById<TextView>(R.id.settingsTitle) ?: return
        val bar = findViewById<View>(R.id.homeSearchBar) ?: return
        val tp = (scrollY / dp(115).toFloat()).coerceIn(0f, 1f)
        val cp = (scrollY / dp(60).toFloat()).coerceIn(0f, 1f)
        title.scaleX = 1f - 0.4375f * tp
        title.scaleY = 1f - 0.4375f * tp
        title.translationY = -dp(46) * tp
        bar.scaleY = 1f - cp
        bar.pivotY = 0f
        val alpha = (1f - cp * 1.8f).coerceIn(0f, 1f)
        if (bar is android.view.ViewGroup) {
            for (i in 0 until bar.childCount) bar.getChildAt(i).alpha = alpha
        }
    }

    private fun openSearch() {
        if (searchOpen) return
        searchOpen = true
        // 搜索展开后头部交给 titleFlight 接管，此时残留的停靠动画/采样循环必须收掉，
        // 否则会一边遮罩一边把 scrollY 往 115 拽。
        cancelHeaderAnim()
        cancelSettle()
        val overlay = findViewById<android.widget.FrameLayout>(R.id.searchOverlay) ?: return
        overlay.visibility = View.VISIBLE
        overlay.alpha = 0f
        overlay.animate().alpha(1f).setDuration(240)
            .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0.8f, 0.2f, 1f))
            .start()
        val bar = findViewById<View>(R.id.searchBarInline)
        bar?.translationY = -dp(56).toFloat()
        bar?.animate()?.translationY(0f)?.setDuration(300)
            ?.setInterpolator(android.view.animation.PathInterpolator(0.1f, 0.8f, 0.2f, 1f))
            ?.start()
        titleFlight(true)
        findViewById<View>(R.id.homeSearchBar)?.animate()?.alpha(0f)?.setDuration(120)?.start()
        val input = findViewById<android.widget.EditText>(R.id.searchInput)
        input?.requestFocus()
        input?.post {
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                as? android.view.inputmethod.InputMethodManager
            imm?.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }
        renderSearch("")
    }

    private fun closeSearch() {
        if (!searchOpen) return
        searchOpen = false
        val overlay = findViewById<android.widget.FrameLayout>(R.id.searchOverlay) ?: return
        overlay.animate().alpha(0f).setDuration(200).start()
        findViewById<View>(R.id.searchBarInline)?.animate()?.translationY(-dp(56).toFloat())
            ?.setDuration(220)?.start()
        titleFlight(false)
        val input = findViewById<android.widget.EditText>(R.id.searchInput)
        input?.clearFocus()
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
            as? android.view.inputmethod.InputMethodManager
        imm?.hideSoftInputFromWindow(input?.windowToken, 0)
        overlay.postDelayed({
            if (!searchOpen) {
                overlay.visibility = View.GONE
                input?.setText("")
                findViewById<View>(R.id.homeSearchBar)?.alpha = 1f
                applyHeaderTransform(
                    findViewById<android.widget.ScrollView>(R.id.settingsScroller)?.scrollY ?: 0,
                )
            }
        }, 320)
    }

    private fun titleFlight(on: Boolean) {
        val title = findViewById<TextView>(R.id.settingsTitle) ?: return
        title.pivotX = 0f
        title.pivotY = 0f
        val ease = android.view.animation.PathInterpolator(0.1f, 0.8f, 0.2f, 1f)
        if (on) {
            title.animate().scaleX(0.5625f).scaleY(0.5625f)
                .translationY(-dp(46).toFloat()).alpha(0f)
                .setDuration(300).setInterpolator(ease).start()
        } else {
            title.animate().scaleX(1f).scaleY(1f)
                .translationY(0f).alpha(1f)
                .setDuration(260).setInterpolator(ease).start()
        }
    }

    private fun renderSearch(query: String) {
        val results = findViewById<LinearLayout>(R.id.searchResults) ?: return
        val suggestions = findViewById<LinearLayout>(R.id.searchSuggestions)
        findViewById<View>(R.id.btnSearchClear)?.visibility =
            if (query.isNotEmpty()) View.VISIBLE else View.GONE
        results.removeAllViews()
        val q = query.trim()
        if (q.isEmpty()) {
            suggestions?.visibility = View.VISIBLE
            buildSuggestions()
            return
        }
        suggestions?.visibility = View.GONE

        val hits = ArrayList<Pair<View, Pair<String, String>>>()
        listOf(R.id.columnPrimary, R.id.columnSecondary).forEach { columnId ->
            val column = findViewById<LinearLayout>(columnId) ?: return@forEach
            for (i in 0 until column.childCount) {
                val card = column.getChildAt(i) as? LinearLayout ?: continue
                if (card.tag == "setting_profile") continue
                walkRowViews(card) { v ->
                    if (v.tag == "setting_row") {
                        val pair = rowTexts(v)
                        if (pair.first.isNotEmpty() && pair.first.contains(q, ignoreCase = true)) {
                            hits.add(v to pair)
                        }
                    }
                }
            }
        }
        if (hits.isEmpty()) {
            results.addView(TextView(this).apply {
                text = getString(R.string.settings_no_results)
                textSize = 14f
                gravity = android.view.Gravity.CENTER
                setTextColor(getColor(R.color.settings_text_secondary))
                setPadding(0, dp(70), 0, dp(70))
            })
            return
        }
        hits.forEach { (row, pair) ->
            val (title, sub) = pair
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(12), 0, dp(12))
                isClickable = true
            }
            item.addView(TextView(this).apply {
                text = highlight(title, q)
                textSize = 16.5f
                setTextColor(getColor(R.color.settings_text_primary))
            })
            if (sub.isNotBlank()) {
                item.addView(TextView(this).apply {
                    text = sub
                    textSize = 12.5f
                    setTextColor(getColor(R.color.settings_text_secondary))
                    setPadding(0, dp(3), 0, 0)
                })
            }
            item.setOnClickListener {
                closeSearch()
                scrollToRow(row)
            }
            results.addView(item)
            results.addView(View(this).apply {
                setBackgroundColor(getColor(R.color.settings_divider))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(1),
                )
            })
        }
    }

    private fun buildSuggestions() {
        val chips = findViewById<LinearLayout>(R.id.searchChips) ?: return
        if (chips.childCount > 0) return
        listOf(
            R.string.settings_section_appearance,
            R.string.setting_runtime_proxy,
            R.string.setting_maintenance,
        ).forEach { res ->
            val chip = TextView(this).apply {
                text = getString(res)
                textSize = 14.5f
                setTextColor(getColor(R.color.settings_text_primary))
                background = getDrawable(R.drawable.bg_settings_chip)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true
                setOnClickListener {
                    val input = findViewById<android.widget.EditText>(R.id.searchInput)
                    input?.setText(text)
                    input?.setSelection(text.length)
                }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            )
            lp.marginEnd = dp(8)
            chips.addView(chip, lp)
        }
    }

    private fun rowTexts(row: View): Pair<String, String> {
        var title = ""
        var sub = ""
        walkRowViews(row) { v ->
            if (v is TextView) {
                val t = v.text?.toString().orEmpty()
                val size = v.textSize / resources.displayMetrics.scaledDensity
                if (t.isNotBlank() && title.isEmpty() && size >= 15f) title = t
                else if (t.isNotBlank() && sub.isEmpty() && size <= 14.5f) sub = t
            }
        }
        return title to sub
    }

    private fun highlight(text: String, query: String): CharSequence {
        val idx = text.lowercase().indexOf(query.lowercase())
        if (idx < 0) return text
        val sp = android.text.SpannableString(text)
        sp.setSpan(
            android.text.style.ForegroundColorSpan(getColor(R.color.icon_blue)),
            idx, idx + query.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )
        return sp
    }

    private fun scrollToRow(row: View) {
        val scroller = findViewById<android.widget.ScrollView>(R.id.settingsScroller) ?: return
        val rowLoc = IntArray(2)
        row.getLocationInWindow(rowLoc)
        val scLoc = IntArray(2)
        scroller.getLocationInWindow(scLoc)
        scroller.smoothScrollTo(0, scroller.scrollY + rowLoc[1] - scLoc[1] - dp(72))
        val old = row.background
        row.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(getColor(R.color.accent_soft))
            cornerRadius = dp(12).toFloat()
        }
        row.postDelayed({ row.background = old }, 700)
    }

    private fun startVoiceSearch() {
        runCatching {
            startActivityForResult(
                Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(
                        android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                    )
                    .putExtra(
                        android.speech.RecognizerIntent.EXTRA_PROMPT,
                        getString(R.string.settings_search_hint),
                    ),
                REQ_VOICE_SEARCH,
            )
        }.onFailure {
            Toast.makeText(this, R.string.settings_voice_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE_SEARCH && resultCode == RESULT_OK) {
            val text = data
                ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                if (!searchOpen) openSearch()
                val input = findViewById<android.widget.EditText>(R.id.searchInput)
                input?.setText(text)
                input?.setSelection(text.length)
            }
        }
    }

    /**
     * 平板/横屏响应式布局（v1.4.18，v1.4.27 改为按高度均衡分列）：
     * - 宽窗：两栏，**按分区行数把 8 个分区就近对半分**（断点见 [useTwoColumns]）；
     * - 窄窗：单列，顺序不变（显示 → 权限中心 → 语音 → 扩展 → 数据 → 网络 → 维护 → 关于）。
     *
     * v1.5.x：断点不再只看「横屏 840dp 一个值」，改为**按当前配置的宽度 + 朝向**判定，
     * 所以平板竖屏（800dp）也能双栏、手机竖屏仍是单列，转屏时实时切换。
     *
     * ## 为什么不再写死「左显示+权限 / 右其余」
     * 旧实现把列归属硬编码在 XML 里（columnPrimary 放前两个分区，其余全塞
     * columnSecondary），行数一多就歪：v1.4.24 扩到 8 个分区后是左 12 行 / 右 18 行，
     * 右边要滚很久、左边一屏未完就空了。而且每加一行设置项都会继续加剧。
     *
     * 现在：把 XML 里的原始阅读顺序读出来（先 primary 再 secondary），按行数找
     * 一个**连续切分点**让两列高度最接近（保持"从上往下读"的语义，不做瀑布流乱序），
     * 再重新挂到两列上。以后加行/加分区自动重新均衡，不用再手工调 XML。
     *
     * 只改容器方向/权重与子视图归属，不重建页面。限宽交给
     * [MaxWidthLinearLayout]，避免平板横屏下单列内容被拉成超宽行。
     *
     * @param cfg **当前**配置。转屏路径必须传入 `onConfigurationChanged` 的 newConfig，
     *   默认值只适用于 onCreate（那时 resources 与实屏一致）。
     */
    private fun applyResponsiveLayout(cfg: Configuration = resources.configuration) {
        val wide = useTwoColumns(cfg)
        val columns = findViewById<LinearLayout>(R.id.settingsColumns)
        val primary = findViewById<LinearLayout>(R.id.columnPrimary)
        val secondary = findViewById<LinearLayout>(R.id.columnSecondary)
        findViewById<MaxWidthLinearLayout>(R.id.settingsContentWidth).maxWidthDp =
            if (wide) WIDE_CONTENT_MAX_WIDTH_DP else NARROW_CONTENT_MAX_WIDTH_DP

        val sections = sections()
        if (wide) {
            columns.orientation = LinearLayout.HORIZONTAL
            primary.layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f,
            ).apply { marginEnd = dp(16) }
            secondary.layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f,
            )
            distributeSections(sections, primary, secondary)
        } else {
            columns.orientation = LinearLayout.VERTICAL
            primary.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            secondary.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            // 单列时必须把分区全部收回 primary，否则右列内容会跑到屏幕外
            detachSections(sections)
            sections.forEach { addSection(primary, it) }
        }
    }

    /**
     * 单列 / 双栏判定（v1.5.x）：只看**传入配置**的可用宽度与朝向。
     *
     *  · 横屏：>= 840dp（Material 3 的 expanded 断点）—— 手机横屏 780~800dp
     *    仍是单列，避免两栏各 380dp 把说明文字挤成三行；
     *  · 竖屏：>= 600dp —— 平板竖屏（实测 1600x2560 @320dpi = 800dp）双栏，
     *    手机竖屏（360~430dp）单列。
     *
     * 这两个值都是「内容区宽度」的代理：判的是 screenWidthDp（已扣除系统栏），
     * 不依赖实测像素，所以在 onCreate（尚未布局）时也能算出正确结果。
     */
    private fun useTwoColumns(cfg: Configuration): Boolean {
        val min = if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            TWO_COLUMN_MIN_WIDTH_LANDSCAPE_DP
        } else {
            TWO_COLUMN_MIN_WIDTH_PORTRAIT_DP
        }
        return cfg.screenWidthDp >= min
    }

    /**
     * 一个「分区单元」：标题 + 卡片 + 行数权重。
     *
     * 权重用**卡片内的行数**而不是实测像素：两列等宽、行高一致，行数是最稳的
     * 代理；实测像素要求先布局，而本方法在 onCreate 阶段就会被调用。
     */
    private class Section(val header: TextView?, val card: LinearLayout, val weight: Int)

    /** XML 原始阅读顺序（先 columnPrimary 再 columnSecondary），只在首次调用时收集 */
    private var cachedSections: List<Section>? = null

    private fun sections(): List<Section> = cachedSections ?: run {
        val out = ArrayList<Section>()
        out += collectSections(findViewById(R.id.columnPrimary))
        out += collectSections(findViewById(R.id.columnSecondary))
        out.also { cachedSections = it }
    }

    /** 形如「标题 TextView + 卡片 LinearLayout」交替出现；别的节点忽略 */
    private fun collectSections(column: LinearLayout): List<Section> {
        val out = ArrayList<Section>()
        for (i in 0 until column.childCount) {
            val child = column.getChildAt(i) as? LinearLayout ?: continue
            if (child.tag != "setting_card" && child.tag != "setting_profile") continue
            val rows = (0 until child.childCount).count {
                (child.getChildAt(it) as? View)?.tag == "setting_row"
            }
            out += Section(null, child, rows.coerceAtLeast(1))
        }
        return out
    }

    /**
     * 连续切分：找一个 k，让前 k 个分区与其余分区的行数差最小。
     * 保持阅读顺序（不做「往短的那列随手塞」的瀑布流），分列结果可预测。
     */
    private fun distributeSections(
        sections: List<Section>,
        primary: LinearLayout,
        secondary: LinearLayout,
    ) {
        if (sections.isEmpty()) return
        val total = sections.sumOf { it.weight }
        var best = 1
        var bestDiff = Int.MAX_VALUE
        var acc = 0
        for (k in 1 until sections.size) {
            acc += sections[k - 1].weight
            val diff = kotlin.math.abs(total - 2 * acc)
            if (diff < bestDiff) {
                bestDiff = diff
                best = k
            }
        }
        detachSections(sections)
        sections.forEachIndexed { index, section ->
            addSection(if (index < best) primary else secondary, section)
        }
    }

    private fun detachSections(sections: List<Section>) {
        sections.forEach { section ->
            (section.header?.parent as? ViewGroup)?.removeView(section.header)
            (section.card.parent as? ViewGroup)?.removeView(section.card)
        }
    }

    private fun addSection(column: LinearLayout, section: Section) {
        column.addView(section.card)
    }

    override fun onDestroy() {
        // 头部停靠的采样循环与吸附动画都挂在本 Activity 的 Handler/Animator 上，
        // 不收干净会拖住 ScrollView 引用。
        cancelHeaderAnim()
        cancelSettle()
        settleHandler.removeCallbacksAndMessages(null)
        headerScrollRef = null
        super.onDestroy()
    }

    // 权限中心代码（v1.4.58）已整体迁入 PermissionCenterActivity —— 含 Shizuku
    // 监听、麦克风权限回调、运行权限模式对话框（双警告 + 引擎重启）。
    // 本页只保留两个分类入口行（rowPermEngine / rowPermCaps）。

    // ================= 扩展：运行时下载代理 =================

    /** 刷新「运行时下载代理」行的说明文字（默认 / 自定义 / 直连）。 */
    private fun refreshRuntimeProxyRow() {
        val sub = findViewById<TextView>(R.id.subRuntimeProxy)
        val current = RuntimeDownloadConfig.proxy(this)
        sub.text = when {
            current.isBlank() -> getString(R.string.setting_runtime_proxy_value_direct)
            RuntimeDownloadConfig.isDefault(this) ||
                current.equals(RuntimeDownloadConfig.DEFAULT_PROXY.trimEnd('/'), ignoreCase = true) ->
                getString(R.string.setting_runtime_proxy_value_default)
            else -> getString(R.string.setting_runtime_proxy_value_custom, current)
        }
    }

    /**
     * 运行时下载代理编辑框（v1.4.21）。
     *
     * 运行时 zip 与签名索引都从 GitHub Releases 取；默认 gh-proxy.org，
     * 国内网络不用先等一轮直连超时。用户可换自建镜像，或留空直连。
     */
    private fun showRuntimeProxyDialog() {
        val current = RuntimeDownloadConfig.proxy(this)
        val input = EditText(this).apply {
            setText(current)
            hint = RuntimeDownloadConfig.DEFAULT_PROXY
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setSelection(text.length)
        }
        val tip = TextView(this).apply {
            text = getString(
                R.string.setting_runtime_proxy_dialog_hint,
                RuntimeDownloadConfig.DEFAULT_PROXY,
            )
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, dp(8), 0, 0)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), dp(4))
            addView(input)
            addView(tip)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.setting_runtime_proxy)
            .setView(box)
            .setPositiveButton(android.R.string.ok, null)
            .setNeutralButton(R.string.setting_runtime_proxy_reset, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()

        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString()
                if (!RuntimeDownloadConfig.isValid(raw)) {
                    input.error = getString(R.string.setting_runtime_proxy_invalid)
                    return@setOnClickListener
                }
                RuntimeDownloadConfig.setProxy(this, raw)
                refreshRuntimeProxyRow()
                Toast.makeText(
                    this, getString(R.string.setting_runtime_proxy_saved), Toast.LENGTH_SHORT,
                ).show()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                RuntimeDownloadConfig.setProxy(this, null)
                refreshRuntimeProxyRow()
                Toast.makeText(
                    this, getString(R.string.setting_runtime_proxy_reset_done), Toast.LENGTH_SHORT,
                ).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
    /** dp → px 小工具（对话框内边距用） */
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** 统一弹窗样式：覆盖自绘圆角背景，贴近原生安卓对话框的圆润观感 */
    private fun AlertDialog.Builder.showStyled(): AlertDialog =
        create().apply {
            window?.setWindowAnimations(R.style.SettingsDialogAnimation)
            setOnShowListener {
                window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
            }
            show()
        }



    private companion object {
        const val REQ_VOICE_SEARCH = 0x5A1

        /** 吸附时长与曲线（v1.6.23 规格 8：约 340ms、ease-out cubic） */
        const val HEADER_SNAP_MS = 340L

        /** 松手后 scrollY 静默多久算“惯性停稳”（规格 6） */
        const val SETTLE_IDLE_MS = 60L

        /** 停稳采样间隔：8ms 在 120Hz 上仍是每帧一次，不会漏判 */
        const val SETTLE_TICK_MS = 8L

        /** 采样循环的封顶时长，防长列表微振荡时循环常驻 */
        const val SETTLE_MAX_WAIT_MS = 1200L

        /** 双栏断点（横屏）：Material 3 的 expanded 宽度（840dp） */
        const val TWO_COLUMN_MIN_WIDTH_LANDSCAPE_DP = 840

        /** 双栏断点（竖屏）：平板竖屏 800dp 也应双栏，手机竖屏远达不到 */
        const val TWO_COLUMN_MIN_WIDTH_PORTRAIT_DP = 600

        /** 宽窗内容最大宽度：两栏各约 516dp，平板横屏不拉满 */
        const val WIDE_CONTENT_MAX_WIDTH_DP = 1080

        /** 窄窗内容最大宽度：手机/平板竖屏保持易读行宽 */
        const val NARROW_CONTENT_MAX_WIDTH_DP = 680
    }

    /**
     * 「去开启」按钮（v1.4.45~v1.4.57）已整体移除（v1.4.58）：按钮点击行为与
     * 整行点击本就一致（跳系统设置），纯视觉冗余且在窄屏上挤压标题/说明文字。
     * 现在整行即入口，未授权指引由各行的 sub 文案承担（"点击去系统设置开启"）。
     */

    /** 把当前 Activity 的视图按模式重排（不改 XML，运行时改布局参数） */
    private fun applyLayoutMode(mode: SettingsLayoutMode) {
        // 分区横跨两列：Display/Permissions 在 columnPrimary，Extensions/Other 在
        // columnSecondary（v1.2.79 双栏改造的产物）。只重排第一列会漏掉后两个分区
        // ——实测网格模式下 Extensions 仍是一列。
        val columns = listOfNotNull(
            findViewById<LinearLayout>(R.id.columnPrimary),
            findViewById<LinearLayout>(R.id.columnSecondary),
        )
        if (columns.isEmpty()) return
        val sections = columns.flatMap { sectionCards(it) }
        when (mode) {
            SettingsLayoutMode.LIST -> {
                sections.forEach { card ->
                    if (card.tag == "setting_profile") return@forEach
                    (card.layoutParams as? LinearLayout.LayoutParams)?.let {
                        it.bottomMargin = dp(4); card.layoutParams = it
                    }
                    card.orientation = LinearLayout.VERTICAL
                    rowsOf(card).forEach { row ->
                        row.layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                        )
                        setDescriptionsVisible(row, true)
                    }
                }
            }
            SettingsLayoutMode.GRID -> {
                // 真正两列：每两行包进一个横向容器（卡片的父方向是 vertical，
                // 直接把行设 weight=1/width=0 会得到宽度 0 —— 实测踩过）。
                val gap = dp(6)
                sections.forEach { card ->
                    if (card.tag == "setting_profile") return@forEach
                    (card.layoutParams as? LinearLayout.LayoutParams)?.let {
                        it.bottomMargin = dp(18); card.layoutParams = it
                    }
                    val rows = rowsOf(card)
                    card.removeAllViews()
                    rows.chunked(2).forEach { pair ->
                        val wrap = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            layoutParams = LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                            )
                        }
                        pair.forEachIndexed { idx, row ->
                            row.layoutParams = LinearLayout.LayoutParams(
                                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f,
                            ).apply { if (idx == 0 && pair.size == 2) marginEnd = gap }
                            setDescriptionsVisible(row, false)
                            // 网格里每行只剩图标 + 标题 + 当前值：文字必须单行省略，
                            // 否则会被逐字换行（实测「Landscape mode」竖排成一列）
                            compactRowForGrid(row)
                            wrap.addView(row)
                        }
                        if (pair.size == 1) {
                            // 奇数行：补占位保持左对齐，避免最后一项被拉满整行
                            wrap.addView(View(this).apply {
                                layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                            })
                        }
                        card.addView(wrap)
                    }
                }
            }
        }
    }

    /**
     * 找 columnPrimary 下的分区卡片（v1.4.23）。
     *
     * ⚠️ 不能只认「有 background 的 LinearLayout」：Extensions / Other 两个分区
     * 的卡片没有 bg_card 背景（实测漏识 → 网格模式下它们不参与重排）。
     * 这里改为「分区标题 TextView 之后、且包含至少一个可点击行的容器」。
     */
    private fun sectionCards(primary: LinearLayout): List<LinearLayout> =
        (0 until primary.childCount)
            .mapNotNull { primary.getChildAt(it) as? LinearLayout }
            .filter { it.tag == "setting_card" || it.tag == "setting_profile" }

    /** 卡片内的行容器（直接子 View 里可点击的 LinearLayout） */
    private fun rowsOf(card: LinearLayout): List<LinearLayout> =
        (0 until card.childCount)
            .mapNotNull { card.getChildAt(it) as? LinearLayout }
            .filter { it.tag == "setting_row" }

    /**
     * 网格模式下隐藏「说明文字」（v1.4.23）。
     *
     * v1.4.58 起行结构是「标题行 + 说明行」两段式（任意深度嵌套），
     * 按直接子节点索引的老判据失效 → 改为**递归遍历**整棵行子树。
     * 判据：**小字号（≤12sp）且无 id 的 TextView** 才是说明文字——
     * 有 id 的都是有身份的控件（标题 16sp / 状态徽章 13-14sp / 箭头）；
     * 唯一例外 subAccess（带 id 的说明文字，照藏）。
     */
    private fun setDescriptionsVisible(row: LinearLayout, visible: Boolean) {
        walkRowViews(row) { v ->
            if (v is TextView) {
                val sp = v.textSize / resources.displayMetrics.scaledDensity
                val isDesc = v.tag == "setting_summary" || (sp <= 12.5f && v.id == View.NO_ID)
                if (isDesc) v.visibility = if (visible) View.VISIBLE else View.GONE
            }
        }
    }

    /** 深度优先遍历行内全部 View（含嵌套的标题行/说明行）。 */
    private fun walkRowViews(root: View, fn: (View) -> Unit) {
        fn(root)
        if (root is android.view.ViewGroup) {
            for (i in 0 until root.childCount) walkRowViews(root.getChildAt(i), fn)
        }
    }

    /**
     * 网格模式下行内压缩（v1.4.23；v1.4.58 改递归）：图标缩到 28dp、
     * 全部文字单行省略，保证 2 列宽度下仍可读（实测不处理会逐字竖排）。
     * 说明文字由 [setDescriptionsVisible] 先行隐藏，说明行随之塌缩，
     * 网格行只剩「图标 + 标题 + 状态徽章」单行。
     */
    private fun compactRowForGrid(row: LinearLayout) {
        row.setPadding(dp(8), dp(10), dp(8), dp(10))
        row.minimumHeight = dp(56)
        walkRowViews(row) { v ->
            when (v) {
                is android.widget.ImageView -> {
                    (v.layoutParams as? LinearLayout.LayoutParams)?.let {
                        if (it.width > dp(28)) {
                            it.width = dp(28); it.height = dp(28)
                            v.layoutParams = it
                        }
                    }
                    v.setPadding(dp(6), dp(6), dp(6), dp(6))
                }
                is TextView -> {
                    v.maxLines = 1
                    v.ellipsize = android.text.TextUtils.TruncateAt.END
                    v.setSingleLine(true)
                }
            }
        }
    }

}

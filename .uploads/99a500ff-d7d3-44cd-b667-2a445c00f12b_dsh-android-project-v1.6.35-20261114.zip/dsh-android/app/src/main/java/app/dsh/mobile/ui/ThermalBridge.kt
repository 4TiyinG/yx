package app.dsh.mobile.ui

import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * 热档位的 JS 桥（v1.6.35）。
 *
 * ## 双向通道
 *
 * 需求要求「原生侧决定降档后必须通过 JS Bridge 同步给页面侧」，同时
 * 「ADPF 应可从 JS 调用」。所以这里两条方向都要有：
 *
 * | 方向 | 机制 | 用途 |
 * |---|---|---|
 * | 原生 → 页面 | `evaluateJavascript("__dshThermal.set(...)")` | 每次档位变化推一次 |
 * | 页面 → 原生 | `DshAndroidThermal.level()` / `stats()` | 页面自检、诊断页、插件按需降级 |
 *
 * ## 为什么推送用 evaluateJavascript 而不是 addJavascriptInterface 回调
 *
 * `@JavascriptInterface` 是**页面调原生**的单向通道，原生无法「调用页面函数」。
 * 反过来推只能靠 `evaluateJavascript`（或 postWebMessage，但需要页面侧监听器，
 * 且我们不想要求前端配合）。一次 `set` 调用只有几百字节，开销可忽略 ——
 * 真正贵的是每秒几十次，而我们只在**档位变化时**推（最多每几秒一次，有滞回兜底）。
 *
 * ## 线程
 *
 * `evaluateJavascript` 必须在 UI 线程调用。级别回调来自 [ThermalMonitor]，
 * 而它的 tick/广播/thermal 回调都在主线程，所以这里直接调；保险起见仍包
 * `runCatching` 并对非主线程场景转投（WebView 已销毁时会抛）。
 */
object ThermalBridge {

    private const val TAG = "ThermalBridge"

    /** JS 接口名（页面侧 `window.DshAndroidThermal`） */
    const val JS_NAME = "DshAndroidThermal"

    @Volatile private var view: WebView? = null

    /** 页面是否已经装好 `__dshThermal`（注入完成前推过去是空操作） */
    @Volatile private var ready = false

    /** 最近一次推送的级别，导航后重推用 */
    @Volatile private var lastLevel: ThermalMonitor.Level = ThermalMonitor.Level.NORMAL

    /**
     * 挂上 JS 接口。在 `setupWebView` 里调用一次（WebView 重建后要重挂）。
     */
    fun install(webView: WebView) {
        view = webView
        ready = false
        runCatching {
            webView.addJavascriptInterface(Bridge(), JS_NAME)
        }.onFailure { Log.w(TAG, "install failed: ${it.message}") }
    }

    /** WebView 销毁 / 重建：断开引用，避免往已销毁的实例推 */
    fun detach() {
        view = null
        ready = false
    }

    /**
     * 页面侧脚本注入完成 → 标记就绪，并把当前档位补推一次。
     *
     * 必须补推：注入发生在 `onPageFinished`，而档位变化可能发生在导航之前
     * （用户在热态下切了个页面），不补推页面就会停在 NORMAL 档。
     */
    fun onPageReady() {
        ready = true
        push(lastLevel)
    }

    /**
     * 推送档位到页面。幂等：页面侧 `set()` 接受绝对档位。
     *
     * @param level 当前热档位
     */
    fun push(level: ThermalMonitor.Level) {
        lastLevel = level
        val w = view ?: return
        if (!ready) return
        val plan = ThermalPolicy.planFor(level)
        val js = "try{window.__dshThermal&&window.__dshThermal.set(" +
            "${level.ordinal},${plan.jsFlags},${plan.frameCapFps})}catch(e){}"
        runCatching { w.evaluateJavascript(js, null) }
            .onFailure {
                // 页面正在导航 / WebView 已销毁：属正常竞态，不当错误上报
                Log.d(TAG, "push skipped: ${it.message}")
            }
    }

    /** 当前档位（页面侧查询 / 诊断） */
    val currentLevel: ThermalMonitor.Level get() = lastLevel

    /**
     * 暴露给页面的原生接口。
     *
     * 所有方法都在 **JavaBridge 线程**上被调用（不是 UI 线程），因此只读
     * volatile 字段、不做任何 View 操作。
     *
     * 返回 JSON 字符串而不是对象：`@JavascriptInterface` 只支持基本类型/String，
     * 直接返对象会被转成 `[object Object]`，是常见坑。
     */
    private class Bridge {

        /** 当前档位序号：0=NORMAL 1=WARM 2=TIGHT 3=SEVERE */
        @JavascriptInterface
        fun level(): Int = lastLevel.ordinal

        /** 页面侧降级位（与 `ThermalPolicy.JsFlags` 一致），插件可据此自行收手 */
        @JavascriptInterface
        fun flags(): Int = ThermalPolicy.planFor(lastLevel).jsFlags

        /** 原生侧当前允许的最大帧率（0 = 不限） */
        @JavascriptInterface
        fun frameCap(): Int = ThermalPolicy.planFor(lastLevel).frameCapFps

        /**
         * 完整状态快照（JSON）。
         *
         * 页面侧可用于：本地诊断面板、按档位切换自己的渲染路径。
         */
        @JavascriptInterface
        fun stats(): String = runCatching {
            val p = ThermalPolicy.planFor(lastLevel)
            "{\"level\":${lastLevel.ordinal},\"name\":\"${lastLevel.name}\"," +
                "\"flags\":${p.jsFlags},\"fps\":${p.frameCapFps}," +
                "\"monitor\":\"${escape(ThermalMonitor.dump())}\"}"
        }.getOrDefault("{}")

        private fun escape(s: String): String =
            s.replace("\\", "\\\\").replace("\"", "\\\"")
    }
}

package app.dsh.mobile.ui

import android.graphics.Canvas
import android.util.Log
import android.view.View
import android.webkit.WebView

/**
 * WebView 渲染管线的原生侧治理（v1.6.35）。
 *
 * ## 这一层能改什么、不能改什么
 *
 * 需求里的「WebView 内核专项削减」有相当一部分**没有公开 API**（例如 Tile Cache
 * 上限、合成层数量、Renderer 的 GPU 线程亲和性）。不先讲清边界，就会写出
 * 「看起来做了优化、实际什么都没改」的代码。所以先把可做/不可做列出来：
 *
 * | 目标 | 公开手段 | 本类是否实现 |
 * |---|---|---|
 * | Renderer 优先级隔离 | `setRendererPriorityPolicy` | ✅ [applyRendererPriority] |
 * | Renderer 死亡恢复 | `onRenderProcessGone` → 重建 | ✅ 由 MainActivity 调 [onRendererGone] |
 * | 禁止软件渲染回退 | 只允许 `LAYER_TYPE_NONE` | ✅ [enforceHardwareLayer] |
 * | 收窄绘制面积 | 不创建超出屏幕的 WebView | ✅ [auditSize] |
 * | 合成层/模糊削减 | 只能靠页面侧 CSS | ⚠ 见 `js/thermal-degrade.js` |
 * | Tile Cache 上限 | **无公开 API** | ❌ 只能靠「不保留不可见实例」间接约束 |
 *
 * 最后一行尤其要说清：`WebView` 没有任何公开方法可以设置 tile 位图缓存上限
 * （`trimMemory` 是隐藏 API，`freeMemory` 已 deprecated 且契约不符 —— 详见
 * MainActivity 里 v1.6.20 的调查记录）。因此「限制 Tile Cache 增长」在应用层
 * 的唯一可靠手段是**减少同时存活的 WebView 数量与其绘制面积**，这也是本类
 * 的审计项。
 *
 * ## 为什么后台不直接 WAIVED
 *
 * `RENDERER_PRIORITY_WAIVED` 意味着「这个 Renderer 可以被系统随时杀掉来省内存」。
 * 但本 App 刻意让 WebView 在后台继续跑（AI 流式回复要靠 JS 定时器驱动，见
 * MainActivity.onPause 的注释）。WAIVED 会在后台把 Renderer 回收掉，用户切回来
 * 看到的就是「回复中断 + 页面重载」——用功能换内存，不能接受。
 *
 * 所以后台用 `BOUND`（比 IMPORTANT 低，但不至于被杀），并显式把
 * `waiveWhenNotVisible` 设为 false 与策略对齐：可见性由我们自己按
 * 「前台/后台 + 热档位」决定，而不是交给系统猜。
 */
object WebViewRendering {

    private const val TAG = "WebViewRendering"

    /**
     * 应用 Renderer 优先级。
     *
     * @param webView  目标 WebView
     * @param visible  Activity 是否在前台可见
     * @param level    当前热档位（决定前台时的优先级上限）
     */
    fun applyRendererPriority(
        webView: WebView?,
        visible: Boolean,
        level: ThermalMonitor.Level,
    ) {
        webView ?: return
        val plan = ThermalPolicy.planFor(level)
        val priority = when {
            // 后台：一律 BOUND。不用 WAIVED 的原因见类注释。
            !visible -> ThermalPolicy.RENDERER_BOUND
            // 前台：跟随热档位（SEVERE 时降到 WAIVED —— 此时保核心交互优先，
            // 页面本来也不再做重活了，被杀重启的代价小于持续抢 CPU/内存）
            else -> plan.renderer
        }
        setPolicy(webView, priority, "visible=$visible level=${level.name}")
    }

    private fun setPolicy(webView: WebView, priority: Int, why: String) {
        runCatching {
            // waiveWhenNotVisible=false：可见性由 [applyRendererPriority] 显式管理。
            // 若交给系统，后台瞬时不可见（下拉通知栏）就会触发一次 waive，
            // 回来时 Renderer 可能已经在重建，页面白屏一闪。
            webView.setRendererPriorityPolicy(priority, false)
        }.onFailure { Log.w(TAG, "setRendererPriorityPolicy($priority) failed: ${it.message}") }
            .onSuccess {
                if (priority != lastApplied) {
                    lastApplied = priority
                    Log.i(TAG, "renderer priority=$priority ($why)")
                }
            }
    }

    @Volatile private var lastApplied = Int.MIN_VALUE

    /** Renderer 崩溃/被杀后重建，重建实例的优先级要重新套一遍。 */
    fun onRendererGone(level: ThermalMonitor.Level, visible: Boolean) {
        lastApplied = Int.MIN_VALUE
        Log.i(TAG, "renderer gone → will re-apply priority on recovery")
        // 实际重挂由调用方在重建 WebView 后调 applyRendererPriority 完成
    }

    /**
     * 强制「只走硬件渲染」。
     *
     * ## 为什么要显式做这件事
     *
     * 「严禁盲目切回软件渲染」是需求里的硬要求，但代码里只要**任何一处**写了
     * `setLayerType(LAYER_TYPE_SOFTWARE)`（常见于「解决圆角/阴影/截图」的临时方案），
     * 就会让整棵 View 树回退到 CPU 软绘 —— 热态下这是灾难性的（软绘没有
     * RenderThread 并行，全部压在主线程上，且每帧重新栅格化）。
     *
     * 本方法在每次 attach/重建时把层类型**归位**到 `LAYER_TYPE_NONE`
     * （= 默认的硬件加速路径），并记录一次日志，便于发现「有东西偷偷改了它」。
     *
     * ⚠ 如果某个页面确实需要软绘（例如需要无损截图的离屏 View），应当在**离屏
     * 的独立 View** 上开启，绝不作用于承载 WebUI 的这棵视图树。
     */
    fun enforceHardwareLayer(webView: WebView?) {
        webView ?: return
        val current = webView.layerType
        if (current == View.LAYER_TYPE_SOFTWARE) {
            Log.w(
                TAG,
                "software layer detected on WebView (layerType=$current) → resetting to NONE; " +
                    "software rendering puts all raster work on the main thread",
            )
            runCatching { webView.setLayerType(View.LAYER_TYPE_NONE, null) }
        }
    }

    /**
     * 尺寸/绘制面积审计。
     *
     * 检测两类会让降频场景雪上加霜的问题：
     *
     * 1. **WebView 比屏幕还大**（常见于「为防止地址栏遮挡而多留一屏」的错误修复）——
     *    多出来的区域照样会被栅格化，白白多占 tile 内存与绘制时间；
     * 2. **页面高度远超视口**（长列表整页渲染）—— 这部分**不是**应用层能改的
     *    （取决于页面是否用虚拟列表），但记下实际数字，便于在真机 trace 里对齐
     *    「Renderer 耗时」与「内容高度」的关系。
     *
     * @return 一行诊断文本，同时按需落日志
     */
    fun auditSize(webView: WebView?, screenHeightPx: Int, screenWidthPx: Int): String {
        webView ?: return "webview=null"
        val w = webView.width
        val h = webView.height
        if (w <= 0 || h <= 0) return "webview not laid out yet"
        val contentH = runCatching { webView.contentHeight }.getOrDefault(0)
        val oversize = screenHeightPx > 0 && h > screenHeightPx * 1.05f
        val line = "webview=${w}x$h screen=${screenWidthPx}x$screenHeightPx " +
            "contentH=$contentH oversize=$oversize"
        if (oversize) {
            Log.w(
                TAG,
                "WebView is larger than the screen ($line) — the overflow area is still " +
                    "rasterized and costs tile memory; it should be clipped by the parent, not by size",
            )
        }
        return line
    }

    /**
     * 给诊断/日志用的渲染层摘要（不读隐藏 API，只用公开字段）。
     */
    fun describe(webView: WebView?): String {
        webView ?: return "webview=null"
        val layer = when (webView.layerType) {
            View.LAYER_TYPE_SOFTWARE -> "software"
            View.LAYER_TYPE_HARDWARE -> "hardware-layer"
            else -> "none(hw-accelerated)"
        }
        return "layer=$layer size=${webView.width}x${webView.height} " +
            "attached=${webView.isAttachedToWindow} shown=${webView.isShown}"
    }

    /**
     * 判断一次绘制是否落到了软件 Canvas（诊断用）。
     *
     * 正常路径下 [WebView.onDraw] 由硬件加速管线接管，`onDraw` 收到的 Canvas 是
     * `RecordingCanvas`。若拿到的是普通 `Canvas`，说明这棵视图树被关掉了硬件加速
     * （例如 AndroidManifest 里 `android:hardwareAccelerated="false"`，或上层 View
     * 用了 `LAYER_TYPE_SOFTWARE`）。热态下这会直接把帧时间打爆，所以留一个可查询的
     * 判据，而不是靠肉眼判断。
     */
    fun isHardwareCanvas(canvas: Canvas): Boolean =
        canvas.isHardwareAccelerated
}

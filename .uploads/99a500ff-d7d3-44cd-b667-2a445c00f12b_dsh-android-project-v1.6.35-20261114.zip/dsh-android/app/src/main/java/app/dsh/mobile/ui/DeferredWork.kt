package app.dsh.mobile.ui

import android.util.Log
import app.dsh.mobile.engine.BackgroundThreads

/**
 * 非关键任务的「可暂停」调度（v1.6.35）。
 *
 * ## 需求背景
 *
 * 「非关键任务调度：缓存清理、预热、上报等任务在热状态受限档位时暂停，
 * 待 thermal status 恢复正常后批量补做。」
 *
 * ## 为什么不能简单「丢掉」
 *
 * 缓存清理不做会涨盘、上报不做会丢数据。所以这里的语义是**延迟**而不是丢弃：
 * 暂停期间任务排队（按 id 去重，同一 id 只保留最后一次提交 —— 这正是「批量补做」
 * 的正确形态：10 次「清理缓存」请求合并成 1 次），恢复时在一个后台线程里连续做完。
 *
 * ## 为什么按 id 去重
 *
 * 暂停可能持续几分钟。若每个 tick 都往队列里塞一条「刷新某缓存」，恢复时会瞬间
 * 爆发几十个重复任务 —— 那比不暂停更糟（恢复瞬间正好是系统还在恢复余量的时刻）。
 *
 * ## 优先级
 *
 * 执行线程走 [BackgroundThreads]（`THREAD_PRIORITY_BACKGROUND`）：补做时不应与
 * 用户交互抢 CPU。这也是需求里「严防优先级反转」的一个落点。
 *
 * ## 上限
 *
 * 队列有条数上限 [MAX_QUEUE]。超了丢弃**最早**的条目并记日志 —— 宁可丢一次
 * 清理，也不要让队列无限增长（那本身会成为内存压力源，与「避免 direct reclaim」
 * 的目标相悖）。
 */
object DeferredWork {

    private const val TAG = "DeferredWork"

    /** 暂停期间最多攒多少个不同任务。 */
    private const val MAX_QUEUE = 24

    private val lock = Any()

    /** id → 任务；LinkedHashMap 保持提交顺序，便于按序补做。 */
    private val pending = LinkedHashMap<String, () -> Unit>()

    @Volatile private var paused = false

    /** 是否处于暂停（热受限）状态。 */
    val isPaused: Boolean get() = paused

    /** 当前排队条数（诊断用）。 */
    val pendingCount: Int get() = synchronized(lock) { pending.size }

    /**
     * 提交一个非关键任务。
     *
     * 未暂停时**立即**在后台线程执行（不排队、不阻塞调用方）；
     * 暂停时入队，等同 id 覆盖。
     *
     * @param id 去重键。用稳定的语义 id（如 `clean:webcache`），不要带时间戳。
     */
    fun submit(id: String, task: () -> Unit) {
        if (!paused) {
            BackgroundThreads.start("defer:$id", task)
            return
        }
        synchronized(lock) {
            // 覆盖旧值：只保留最新一次的意图（LinkedHashMap 覆盖时保留原插入顺序，
            // 这里希望它在队尾，所以先删再放）
            pending.remove(id)
            pending[id] = task
            while (pending.size > MAX_QUEUE) {
                val oldest = pending.keys.firstOrNull() ?: break
                pending.remove(oldest)
                Log.w(TAG, "queue full, dropped oldest task: $oldest")
            }
            Log.i(TAG, "deferred '$id' (thermal limited), queued=${pending.size}")
        }
    }

    /**
     * 由 [ThermalMonitor] 驱动。暂停/恢复正常时都会调用。
     *
     * 恢复到不暂停时**一次性**把队列取空并在一个后台线程里连续执行 ——
     * 单线程串行而不是并发，避免补做本身制造 IO 尖峰。
     */
    fun setPaused(value: Boolean) {
        if (paused == value) return
        paused = value
        if (value) {
            Log.i(TAG, "paused: non-critical work will queue (thermal level ≥ TIGHT)")
            return
        }
        val batch: List<Map.Entry<String, () -> Unit>>
        synchronized(lock) {
            if (pending.isEmpty()) {
                Log.i(TAG, "resumed: nothing queued")
                return
            }
            batch = pending.entries.toList()
            pending.clear()
        }
        Log.i(TAG, "resumed: flushing ${batch.size} deferred task(s)")
        BackgroundThreads.start("defer:flush") {
            for ((id, task) in batch) {
                // 单个任务失败不影响后续补做
                runCatching { task() }
                    .onFailure { Log.w(TAG, "deferred '$id' failed: ${it.message}") }
            }
            Log.i(TAG, "flush done (${batch.size} task(s))")
        }
    }

    /** 诊断：当前排队中的 id 列表。 */
    fun pendingIds(): List<String> = synchronized(lock) { pending.keys.toList() }

    /** 测试用：清空并复位。 */
    fun resetForTest() {
        synchronized(lock) { pending.clear() }
        paused = false
    }
}

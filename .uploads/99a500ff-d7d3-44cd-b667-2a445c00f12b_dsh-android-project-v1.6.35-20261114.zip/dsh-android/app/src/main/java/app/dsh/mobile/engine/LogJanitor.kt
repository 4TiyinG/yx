package app.dsh.mobile.engine

import android.content.Context
import android.util.Log
import java.io.File

/**
 * 日志卫生（v1.4.57，用户反馈「日志累积到 96 万行、不会定时清除」）。
 *
 * ## 现状与为什么仍需这个类
 *
 * 主日志 `engine/engine.log` 与 `engine/boot.log` 各自有环形上限
 * （[EngineLog.MAX_BYTES] = 2MB / BootTrace 128KB），**写入时**超限会截断。
 * 但有三类残留它们管不到：
 *
 * 1. **plugin-manager 每次操作建一个目录**
 *    `dsh-home/profiles/<p>/.plugin-manager/logs/operation-XXXXXX/pnpm.log`
 *    由引擎侧的 dsh-plugin-manager 生成，卸载插件也不会删。用户装几十次
 *    插件就是几十个目录；pnpm 的安装输出很容易单个几万行。
 * 2. **只读不写时永不收缩**：环形截断发生在 append 路径上。引擎起不来
 *    （退避重试）时日志只被 Health 探针追加少量内容，2MB 的旧内容会
 *    原样留着；用户看到的「96 万行」大概率来自这里或第 1 类。
 * 3. **其他引擎自建日志**：上游或第三方插件可能往 dsh-home 下写自己的
 *    log 文件，路径不可枚举。
 *
 * ## v1.6.34：这是启动路径上最大的 IO 热点，必须削掉
 *
 * 原实现每次启动都对整个 `dsh-home` 做**两遍**深度 8/6 的递归遍历，且对
 * **每个 entry** 调一次 `Files.isSymbolicLink`。而 dsh-home 里最大的两棵子树
 * 恰好完全没有日志：
 *
 * ```
 * dsh-home/
 *   engine/                 ← node 运行时，数万个文件（含全部 .so/.h）
 *   profiles/<p>/node_modules ← 引擎与插件依赖，数万个文件
 * ```
 *
 * 于是每次开机都要为「修剪日志」付出 5~10 万次 `lstat`：在低端机/发热降频时
 * 这是一两秒级的纯 IO 开销，还会与引擎自己的冷启动读盘抢 IO 队列 —— 用户看到
 * 的就是「启动卡、手机烫」。
 *
 * 现在三层收口：
 *
 * 1. **[SKIP_DIRS] 剪枝**：上面这些子树一个 entry 都不进（它们不可能藏日志）；
 * 2. **单次 stat**：先 `isDirectory`，只有目录才做符号链接判断（文件不需要）；
 * 3. **节流**：真正全量清扫最多每 [SWEEP_INTERVAL_MS] 一次，其余启动只做
 *    根目录浅扫（十几个 entry）。日志卫生本来就不需要「每次开机」的精度。
 *
 * 三项都不改变功能：超限日志仍会被裁剪，操作日志仍只留最新几份，只是不再
 * 每次开机都全量走一遍。第一次升级后会立刻做一次全量清扫。
 *
 * ## 边界
 * - 只处理**文件名以 .log 结尾**的文件，以及 `.plugin-manager/logs/` 下的
 *   整个 operation-* 目录；
 * - 单文件上限 [MAX_LOG_BYTES]（4MB，比 engine.log 的 2MB 宽松，因为这里
 *   处理的是「已经超限的历史遗留」）；
 * - 单个文件裁剪保留尾部一半，与 [EngineLog] 策略一致（保留最近的内容更有用）；
 * - 失败静默：日志卫生不该阻止引擎启动。
 */
object LogJanitor {

    private const val TAG = "LogJanitor"

    /** 单文件上限：超过就裁到一半。 */
    const val MAX_LOG_BYTES: Long = 4L shl 20

    /** plugin-manager 操作日志保留的份数（按修改时间保留最新的 N 个）。 */
    private const val KEEP_OPERATION_DIRS = 3

    /**
     * 全量清扫的最小间隔（v1.6.34）。
     *
     * 6 小时：日志上限是 4MB，按引擎典型写入速率，6 小时也涨不到需要紧急裁剪
     * 的程度；而它把「每次开机一次全树遍历」降到「每天最多 4 次」。
     * 间隔内的启动只做根目录浅扫，engine.log 这类根级日志仍会被及时处理。
     */
    private const val SWEEP_INTERVAL_MS = 6L * 60 * 60 * 1000

    /**
     * 绝不可能藏着日志的子树（v1.6.34）。
     *
     * 剪掉它们等于把遍历量从「数万」降到「数十」，这是本次优化的主要来源。
     * 判定只看**目录名**，不做任何路径匹配 —— 名字相同就当作同一类内容，
     * 对日志卫生来说足够（误剪的代价是「某个叫 engine 的目录里的 log 没被裁」，
     * 而那个目录里本来就不该有日志）。
     */
    private val SKIP_DIRS = setOf(
        "engine",           // node 运行时本体
        "node_modules",
        ".pnpm",
        ".git",
        ".cache",           // node compile cache
        ".gradle",
        "workspaces",       // 用户工作区：可能是海量文件，但不是引擎日志
        ".trash",
    )

    data class Result(
        val trimmedFiles: Int,
        val freedBytes: Long,
        val removedOpDirs: Int,
        /** 本次是否做了全量清扫（false = 仍在节流窗口内，只做了浅扫）。 */
        val full: Boolean = false,
    )

    /** 在引擎启动前调用；耗时通常在毫秒级（节流后多数启动只是一次根目录浅扫）。 */
    fun sweep(ctx: Context): Result {
        val home = runCatching { EngineConfig.dshHome(ctx) }.getOrNull()
            ?: return Result(0, 0, 0)
        var trimmed = 0
        var freed = 0L
        var removedDirs = 0

        val full = claimSweepSlot(ctx)

        // ① *.log 文件：超限则裁到尾部一半
        runCatching {
            walkLogFiles(home, 0, shallowOnly = !full) { f ->
                val len = runCatching { f.length() }.getOrDefault(0L)
                if (len > MAX_LOG_BYTES) {
                    val keep = MAX_LOG_BYTES / 2
                    val saved = trimToTail(f, keep)
                    if (saved > 0) {
                        trimmed++
                        freed += saved
                        Log.i(TAG, "trimmed ${f.name}: ${len} -> ${len - saved} bytes")
                    }
                }
            }
        }.onFailure { Log.w(TAG, "sweep logs failed: ${it.message}") }

        // ② plugin-manager 操作日志：按修改时间只留最新 N 个。
        //    只在全量轮次做 —— 它要枚举 profiles 下的目录，浅扫窗口里跳过。
        if (full) {
            runCatching {
                removedDirs = pruneOperationLogs(home)
            }.onFailure { Log.w(TAG, "prune operation logs failed: ${it.message}") }
        }

        if (trimmed > 0 || removedDirs > 0) {
            Log.i(
                TAG,
                "log sweep (${if (full) "full" else "shallow"}): " +
                    "trimmed=$trimmed freed=${freed / 1024}KB opDirs=$removedDirs",
            )
        }
        return Result(trimmed, freed, removedDirs, full)
    }

    /**
     * 判断本次是否可以走全量清扫，并在可以时**立即**记下时间戳。
     *
     * 先写时间戳再干活：即使本轮清扫中途被杀，也不会因为「没写戳」而在下一次
     * 启动又立刻全量跑一遍（宁可少清一次，也不要连续两次重扫）。
     */
    private fun claimSweepSlot(ctx: Context): Boolean = runCatching {
        val prefs = ctx.getSharedPreferences("log_janitor", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_full_sweep_ms", 0L)
        val now = System.currentTimeMillis()
        // 时钟回拨（用户改时间 / NTP 校正）会让 now - last 变成负数：此时**允许**
        // 一次全量清扫，否则可能永久卡在「不到间隔」。
        if (last > 0 && now > last && now - last < SWEEP_INTERVAL_MS) return false
        prefs.edit().putLong("last_full_sweep_ms", now).apply()
        true
    }.getOrDefault(true)

    /**
     * 遍历 .log 文件。**不跟随符号链接**（sessions/workspaces 可能外置）。
     * 深度限制 8 层 —— 正常日志都在 profiles/<name>/.plugin-manager/logs/x/y.log
     * 这个深度内，更深的结构不是日志。
     *
     * @param shallowOnly 只扫根目录一层（节流窗口内使用），避免任何递归开销。
     */
    private fun walkLogFiles(
        root: File,
        depth: Int = 0,
        shallowOnly: Boolean = false,
        visit: (File) -> Unit,
    ) {
        if (depth > 8) return
        val children = runCatching { root.listFiles() }.getOrNull() ?: return
        for (f in children) {
            // 单次 stat：先判目录，只有目录才需要「是不是软链」这个额外判断。
            // 原实现对每个文件也调 isSymbolicLink，等于每个 entry 两次 lstat。
            val isDir = runCatching { f.isDirectory }.getOrDefault(false)
            if (isDir) {
                if (shallowOnly) continue
                if (f.name in SKIP_DIRS) continue
                if (isSymlink(f)) continue
                walkLogFiles(f, depth + 1, false, visit)
            } else if (f.name.endsWith(".log", ignoreCase = true)) {
                if (isSymlink(f)) continue
                runCatching { visit(f) }
            }
        }
    }

    private fun isSymlink(f: File): Boolean =
        runCatching { java.nio.file.Files.isSymbolicLink(f.toPath()) }.getOrDefault(false)

    /**
     * 把文件裁到只保留尾部 [keep] 字节，返回释放的字节数。
     * 与 [EngineLog] 一样跳过 UTF-8 续字节，避免行首出现替换符。
     */
    private fun trimToTail(f: File, keep: Long): Long {
        return runCatching {
            val cur = f.length()
            if (cur <= keep) return@runCatching 0L
            val start = cur - keep
            var tail = java.io.RandomAccessFile(f, "rw").use { raf ->
                raf.seek(start)
                val buf = ByteArray((cur - start).toInt())
                raf.readFully(buf)
                buf
            }
            var i = 0
            while (i < tail.size && (tail[i].toInt() and 0xC0) == 0x80) i++
            if (i > 0) tail = tail.copyOfRange(i, tail.size)
            // 标记一行，让用户知道这里被裁剪过（否则日志开头看起来像丢了内容）
            val marker = "...[earlier log trimmed by LogJanitor]...${System.lineSeparator()}".toByteArray()
            f.writeBytes(marker + tail)
            cur - (marker.size + tail.size)
        }.getOrDefault(0L)
    }

    /**
     * 清理 plugin-manager 的操作日志目录，只保留最新的 [KEEP_OPERATION_DIRS] 个。
     *
     * 路径形如 `<profile>/.plugin-manager/logs/operation-XXXXXX/`。
     * 这些目录是 pnpm 安装过程的产物，事后只剩排障价值；保留最近几次足够。
     */
    private fun pruneOperationLogs(home: File): Int {
        var removed = 0
        val logsDirs = mutableListOf<File>()
        runCatching {
            findDirsNamed(home, ".plugin-manager", 0) { pm ->
                val logs = File(pm, "logs")
                if (logs.isDirectory) logsDirs += logs
            }
        }
        for (logs in logsDirs) {
            val ops = runCatching { logs.listFiles() }.getOrNull()?.filter {
                it.isDirectory && it.name.startsWith("operation-")
            }?.sortedByDescending { it.lastModified() } ?: continue
            ops.drop(KEEP_OPERATION_DIRS).forEach { old ->
                if (deleteNoFollow(old)) removed++
            }
        }
        return removed
    }

    private fun findDirsNamed(root: File, name: String, depth: Int, visit: (File) -> Unit) {
        if (depth > 6) return
        val children = runCatching { root.listFiles() }.getOrNull() ?: return
        for (f in children) {
            if (!runCatching { f.isDirectory }.getOrDefault(false)) continue
            if (f.name in SKIP_DIRS) continue
            if (isSymlink(f)) continue
            if (f.name == name) visit(f) else findDirsNamed(f, name, depth + 1, visit)
        }
    }

    private fun deleteNoFollow(f: File): Boolean = runCatching {
        if (isSymlink(f)) {
            f.delete()
        } else if (f.isDirectory) {
            var ok = true
            f.listFiles()?.forEach { if (!deleteNoFollow(it)) ok = false }
            if (ok) f.delete() else false
        } else {
            f.delete()
        }
    }.getOrDefault(false)
}

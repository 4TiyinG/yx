package app.dsh.mobile.engine

import android.os.Process
import android.util.Log

/**
 * 后台线程工厂（v1.6.35）。
 *
 * ## 为什么单独抽一个类
 *
 * 需求里明确要求「线程分层：除主线程和 RenderThread 外，降低工作线程优先级；
 * 缓存写入、日志、预加载等放入 `THREAD_PRIORITY_BACKGROUND` 执行，严防优先级反转」。
 *
 * 这件事如果散落在各处 `Thread { ... }.start()`，就一定会漏：本项目里已有
 * 十几处裸 `Thread(...)`（日志清扫、孤儿扫描、预读、缓存写入……），新代码再加
 * 几处，优先级就再也管不住了。所以统一到这一个入口，并用探针守住「热路径上
 * 不许裸建线程」。
 *
 * ## 为什么在 run() 里设优先级
 *
 * `Thread.setPriority` 在 `start()` 之前调用是合法的，但 **Android 上不保证生效**：
 * ART 会在 `pthread_create` 后按自己的策略重置 nice 值，某些 ROM 还会再覆盖一次。
 * 唯一可靠的时机是线程**已经跑起来**、在第一次真正干活之前 —— 也就是 run()
 * 的第一行。
 *
 * ## 为什么用 android.os.Process 的常量而不是 java.lang.Thread.NORM_PRIORITY
 *
 * `Process.THREAD_PRIORITY_BACKGROUND` = 10，比 `NORM_PRIORITY`(5) **数值更大、
 * 实际优先级更低**（Linux nice 语义：越大越让）。这正是「可运行但不抢主线程」。
 *
 * ## 优先级反转怎么防
 *
 * 后台线程**绝不允许**持有主线程要等的锁做长活。所以本类不提供线程池 +
 * 队列的复杂结构，只提供「一次性后台任务」：任务自身应当无锁、幂等、可丢弃。
 * 需要串行化的场景请显式用单线程 Executor，并在文档里写明持锁边界。
 */
object BackgroundThreads {

    private const val TAG = "BgThreads"

    /**
     * 起一个后台线程并立即返回。
     *
     * @param name  线程名（出现在 systrace/trace 里，务必可辨识）
     * @param body  任务体；抛异常只记日志，不会杀掉进程
     */
    fun start(name: String, body: () -> Unit): Thread {
        val t = Thread({
            // 必须在这里设：start() 之前设置在 ART 上不保证生效（见类注释）
            runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
            runCatching { body() }
                .onFailure { Log.w(TAG, "$name failed: ${it.javaClass.simpleName}: ${it.message}") }
        }, name)
        t.isDaemon = true
        t.start()
        return t
    }

    /**
     * 起一个后台线程，**允许**调用方自己 catch（需要拿到异常做回滚时用）。
     *
     * 与 [start] 的唯一区别：异常会往上抛给 [body] 内部的 try/catch，本类不记录。
     */
    fun startRaw(name: String, body: () -> Unit): Thread {
        val t = Thread({
            runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) }
            body()
        }, name)
        t.isDaemon = true
        t.start()
        return t
    }
}

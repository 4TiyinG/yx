/*
 * 热降级执行器（v1.6.35）—— 页面侧的「按档位削减开销」。
 *
 * 为什么在页面侧还要做一遍
 * ------------------------
 * 原生侧能做的是「少画几帧」「把 Renderer 优先级调低」。但真正决定一帧有多少
 * 合成层的，是页面自己的 CSS：
 *
 *   · `backdrop-filter: blur(20px)` —— 每次滑动都把背后区域重新做一次高斯模糊，
 *     是移动 GPU 上最贵的单项之一，热态降频后直接掉到个位数帧率；
 *   · 大面积 `box-shadow` —— 阴影没有硬件快捷路径时会走离屏层，层数一多，
 *     合成器每帧要多做 N 次 layer 合成；
 *   · 粒子/彩带 canvas —— 每帧几十个 draw call，纯装饰，热态下最该先砍；
 *   · 背景视差/自动轮播 —— 用户没在看的动效，却一直把所有可见层「弄脏」。
 *
 * 这些都不是原生侧能改的（CSS 在页面里），所以必须有这一段脚本。
 *
 * 设计原则
 * --------
 * 1. **不改页面源码、不用页面 API**：只操作 documentElement 的 class、注入一段
 *    style、以及包装 requestAnimationFrame。任何前端版本都能用，也不会有插件
 *    依赖它。
 * 2. **幂等**：`set()` 传的是**绝对档位**而不是「再降一级」，重复调用无副作用。
 *    这对「原生侧可能重发」很重要（导航后重注入、级别回弹）。
 * 3. **绝不抛错**：整段 IIFE 每块都包 try/catch，且首次执行失败时不留下半截状态。
 * 4. **可逆**：NORMAL 档把 style 清空、rAF 还原、canvas 分辨率复原，
 *    画质能回到原样（否则「降级」就变成了「永久掉画质」）。
 *
 * 档位与标志位必须与 Kotlin 侧 `ThermalPolicy.JsFlags` 完全一致。
 */
(function () {
  'use strict';
  if (window.__dshThermalInstalled) return;
  window.__dshThermalInstalled = true;

  // ── 与 ThermalPolicy.JsFlags 一一对应 ────────────────────────────────────
  var F_NO_BACKDROP = 1 << 0;
  var F_LIGHT_SHADOW = 1 << 1;
  var F_NO_PARTICLES = 1 << 2;
  var F_PAUSE_OFFSCREEN = 1 << 3;
  var F_NO_NONCORE_ANIM = 1 << 4;
  var F_LOWER_CANVAS = 1 << 5;

  var STYLE_ID = '__dsh_thermal_style';
  var ROOT_CLASS = ['dsh-th-0', 'dsh-th-1', 'dsh-th-2', 'dsh-th-3'];

  var state = { level: 0, flags: 0, fps: 0 };

  // ── 1. CSS 降级 ─────────────────────────────────────────────────────────
  // 一次性注入一个 style 节点，之后只改它的 textContent；不反复增删节点
  // （增删 style 会触发全文档样式重算，本身就是一个尖峰）。
  function cssFor(flags) {
    var out = [];
    if (flags & F_NO_BACKDROP) {
      // 不用 `*` 通配：那会让浏览器对每个元素都多算一条规则。只打最常见的几类
      // 载体，并保留一个属性选择器兜住显式声明过的元素。
      out.push(
        '.dsh-th-1 [class*="glass"],.dsh-th-1 [class*="blur"],' +
        '.dsh-th-2 [class*="glass"],.dsh-th-2 [class*="blur"],' +
        '.dsh-th-3 [class*="glass"],.dsh-th-3 [class*="blur"]' +
        '{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}'
      );
      // 直接命中所有声明了 backdrop-filter 的元素（属性选择器不可用于属性值，
      // 所以靠 class 约定 + 下面这条通用规则兜底）
      out.push(
        '.dsh-th-2 *,.dsh-th-3 *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}'
      );
    }
    if (flags & F_LIGHT_SHADOW) {
      // 阴影不是删掉而是「大幅削弱」：完全去掉会让界面失去层次、看起来像坏了
      out.push(
        '.dsh-th-1 *,.dsh-th-2 *,.dsh-th-3 *{' +
        'box-shadow:0 1px 2px rgba(0,0,0,.08)!important;' +
        'text-shadow:none!important}'
      );
      // 大面积动画（>50% 视口的元素）在热态下最耗合成
      out.push('.dsh-th-2 .dsh-th-big-anim,.dsh-th-3 .dsh-th-big-anim{animation:none!important}');
    }
    if (flags & F_NO_PARTICLES) {
      out.push(
        '.dsh-th-3 canvas[data-dsh-particle],.dsh-th-3 [class*="particle"],' +
        '.dsh-th-2 [class*="particle"]{display:none!important}'
      );
    }
    if (flags & F_PAUSE_OFFSCREEN) {
      // 非可视区域的一切动效都停：IntersectionObserver 会打上 dsh-th-off
      out.push(
        '.dsh-th-off,.dsh-th-off *{animation-play-state:paused!important;' +
        'transition:none!important}'
      );
    }
    if (flags & F_NO_NONCORE_ANIM) {
      // 轮播/视差/装饰性无限动画：按 class 约定 + `[class*="carousel"]` 等兜底
      out.push(
        '.dsh-th-2 [class*="carousel"],.dsh-th-3 [class*="carousel"],' +
        '.dsh-th-3 [class*="parallax"],.dsh-th-3 [class*="marquee"]' +
        '{animation:none!important;transition:none!important}'
      );
      out.push('.dsh-th-3 *{transition-duration:0s!important}');
    }
    return out.join('\n');
  }

  var styleEl = null;

  function applyCss(flags) {
    if (!styleEl) {
      styleEl = document.getElementById(STYLE_ID);
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = STYLE_ID;
        (document.head || document.documentElement).appendChild(styleEl);
      }
    }
    var css = flags ? cssFor(flags) : '';
    if (styleEl.textContent !== css) styleEl.textContent = css;
  }

  // ── 2. rAF 降频 ─────────────────────────────────────────────────────────
  // 只压「非关键」回调：用户输入/滚动后 400ms 内的回调放行，否则 30fps 下
  // 拖动手感会明显发黏。这是「主动降帧但保住核心交互」的落点。
  var rawRaf = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : null;
  var rawCancel = window.cancelAnimationFrame ? window.cancelAnimationFrame.bind(window) : null;
  var CRITICAL_WINDOW_MS = 400;
  var lastInputAt = 0;
  var rafQueue = [];          // 待放行的回调
  var rafIds = {};            // 我们发放的 id → 内部 id
  var nextRafId = 1;
  var pumpScheduled = false;
  var lastPumpAt = 0;

  function markInput() { lastInputAt = Date.now(); }

  ['pointerdown', 'pointermove', 'touchstart', 'touchmove', 'wheel', 'keydown', 'scroll']
    .forEach(function (ev) {
      try {
        // passive:true —— 我们不改事件，绝不能因此拖慢滚动
        window.addEventListener(ev, markInput, { passive: true, capture: true });
      } catch (e) { /* 老内核不支持 options 就退化成最简单形式 */ }
    });

  function isCritical() {
    return (Date.now() - lastInputAt) < CRITICAL_WINDOW_MS;
  }

  function pump() {
    pumpScheduled = false;
    if (!rafQueue.length) return;
    var fps = state.fps;
    // fps=0 表示不降帧：把积压的立刻全部放行（级别回升时的恢复路径）
    if (!fps) {
      var all = rafQueue; rafQueue = [];
      for (var k = 0; k < all.length; k++) fire(all[k]);
      return;
    }
    var now = Date.now();
    var minGap = 1000 / fps;
    // 关键窗口内不压：直接放行（否则拖动会一顿一顿）
    if (!isCritical() && (now - lastPumpAt) < minGap - 1) {
      schedulePump(minGap - (now - lastPumpAt));
      return;
    }
    lastPumpAt = now;
    // 每拍最多放行 1 个：多放会瞬间把 GPU 又顶满
    var item = rafQueue.shift();
    fire(item);
    if (rafQueue.length) schedulePump(minGap);
  }

  function schedulePump(delayMs) {
    if (pumpScheduled) return;
    pumpScheduled = true;
    // 用 rawRaf 而不是 setTimeout：仍跟 vsync 对齐，避免自己造出撕裂节奏
    if (rawRaf) rawRaf(function () { pump(); });
    else setTimeout(pump, Math.max(1, delayMs | 0));
  }

  function fire(item) {
    try {
      item.cb(performance.now());
    } catch (e) {
      // 页面自己的回调抛错与我们无关，但要保证队列继续走
      report(e);
    }
  }

  function report(e) {
    try {
      if (window.console && console.warn) {
        console.warn('[dsh-thermal] callback threw: ' + (e && e.message));
      }
    } catch (ignored) { /* 无 console 就算了 */ }
  }

  function installRaf() {
    if (!rawRaf || window.__dshRafWrapped) return;
    window.__dshRafWrapped = true;
    window.requestAnimationFrame = function (cb) {
      var id = nextRafId++;
      var item = { id: id, cb: cb };
      rafQueue.push(item);
      rafIds[id] = item;
      schedulePump(0);
      return id;
    };
    window.cancelAnimationFrame = function (id) {
      var item = rafIds[id];
      if (!item) return;
      delete rafIds[id];
      var idx = rafQueue.indexOf(item);
      if (idx >= 0) rafQueue.splice(idx, 1);
    };
  }

  // ── 3. 非可视区域暂停（IntersectionObserver）─────────────────────────────
  var io = null;

  function installObserver() {
    if (io || typeof IntersectionObserver !== 'function') return;
    io = new IntersectionObserver(function (entries) {
      for (var i = 0; i < entries.length; i++) {
        var en = entries[i];
        var el = en.target;
        if (!el || !el.classList) continue;
        if (en.isIntersecting) {
          el.classList.remove('dsh-th-off');
          // 视频：恢复原本在播的（不能无条件 play，会打断用户手动暂停）
          if (el.tagName === 'VIDEO' && el.__dshWasPlaying) {
            el.__dshWasPlaying = false;
            try { el.play().catch(function () {}); } catch (e) {}
          }
        } else {
          el.classList.add('dsh-th-off');
          if (el.tagName === 'VIDEO' && !el.paused) {
            el.__dshWasPlaying = true;
            try { el.pause(); } catch (e) {}
          }
        }
      }
    }, { rootMargin: '120px' });   // 留 120px 余量：即将进入视口的不要提前停
  }

  function observeAll() {
    if (!io) return;
    try {
      var els = document.querySelectorAll('video,canvas,[class*="anim"],[class*="motion"]');
      for (var i = 0; i < els.length; i++) io.observe(els[i]);
    } catch (e) { report(e); }
  }

  function unobserveAll() {
    if (!io) return;
    try { io.disconnect(); } catch (e) {}
    try {
      var els = document.querySelectorAll('.dsh-th-off');
      for (var i = 0; i < els.length; i++) els[i].classList.remove('dsh-th-off');
    } catch (e) {}
  }

  // ── 4. Canvas 分辨率 ────────────────────────────────────────────────────
  // 只对「有 CSS 尺寸」的 canvas 生效：宽高由样式决定时才敢缩 backing store，
  // 否则 width/height 属性就是布局尺寸，缩了会把界面压变形。
  var canvasBackup = [];

  function lowerCanvases() {
    if (canvasBackup.length) return;
    var list;
    try { list = document.querySelectorAll('canvas'); } catch (e) { return; }
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      try {
        if (c.hasAttribute('data-dsh-keep-res')) continue;
        var rect = c.getBoundingClientRect();
        if (!rect.width || !rect.height) continue;
        // 已经是 CSS 定尺寸（style 写了 width/height）才处理
        if (!c.style.width || !c.style.height) continue;
        var w0 = c.width, h0 = c.height;
        var nw = Math.max(1, Math.round(w0 * 0.65));
        var nh = Math.max(1, Math.round(h0 * 0.65));
        canvasBackup.push({ el: c, w: w0, h: h0, sw: c.style.width, sh: c.style.height });
        c.width = nw;
        c.height = nh;
        // 保持视觉尺寸不变：只降采样精度，不改布局
        c.style.width = c.style.width;
        c.style.height = c.style.height;
      } catch (e) { /* 单个 canvas 失败不影响其它 */ }
    }
    if (canvasBackup.length) {
      try {
        console.info('[dsh-thermal] canvas backing store reduced on ' + canvasBackup.length + ' canvas');
      } catch (e) {}
    }
  }

  function restoreCanvases() {
    for (var i = 0; i < canvasBackup.length; i++) {
      var b = canvasBackup[i];
      try {
        b.el.width = b.w;
        b.el.height = b.h;
        b.el.style.width = b.sw;
        b.el.style.height = b.sh;
      } catch (e) {}
    }
    canvasBackup = [];
  }

  // ── 5. 对外 API ─────────────────────────────────────────────────────────
  function apply(level, flags, fps) {
    var safeLevel = (level | 0) < 0 ? 0 : (level | 0) > 3 ? 3 : (level | 0);
    var safeFlags = flags | 0;
    var safeFps = fps | 0;
    // TIGHT/SEVERE 之外不降帧：WARM 档的要求是「保持帧率」
    if (safeLevel <= 1) safeFps = 0;

    var prevLevel = state.level;
    var prevFlags = state.flags;
    state = { level: safeLevel, flags: safeFlags, fps: safeFps };

    try {
      var de = document.documentElement;
      for (var i = 0; i < ROOT_CLASS.length; i++) de.classList.remove(ROOT_CLASS[i]);
      de.classList.add(ROOT_CLASS[safeLevel]);
    } catch (e) { report(e); }

    try { applyCss(safeFlags); } catch (e) { report(e); }
    try { installRaf(); } catch (e) { report(e); }

    // 观察器只在需要时挂，级别回升就拆掉（拆掉时顺手清掉 off 标记）
    try {
      if (safeFlags & F_PAUSE_OFFSCREEN) {
        installObserver();
        observeAll();
      } else if (prevFlags & F_PAUSE_OFFSCREEN) {
        unobserveAll();
      }
    } catch (e) { report(e); }

    try {
      if (safeFlags & F_LOWER_CANVAS) lowerCanvases();
      else if (prevFlags & F_LOWER_CANVAS) restoreCanvases();
    } catch (e) { report(e); }

    if (prevLevel !== safeLevel) {
      try {
        console.info('[dsh-thermal] level ' + prevLevel + ' → ' + safeLevel +
          ' (flags=0x' + safeFlags.toString(16) + ', fps=' + (safeFps || '∞') + ')');
      } catch (e) {}
    }
    return { level: safeLevel, flags: safeFlags, fps: safeFps };
  }

  window.__dshThermal = {
    /** 原生侧推档位：set(level, flags, fps)。幂等，可重复调用。 */
    set: apply,
    /** 页面侧查询当前档位（诊断用） */
    get: function () {
      return { level: state.level, flags: state.flags, fps: state.fps };
    },
    /**
     * 页面侧主动上报「这个回调是核心交互」，rAF 降频时永远放行。
     * 用 `window.__dshThermal.critical(cb)` 包一层即可。
     */
    critical: function (cb) {
      return function () {
        lastInputAt = Date.now();
        return cb.apply(this, arguments);
      };
    },
    /** 手动标记一个元素为「大面积动画」，热态下优先停它 */
    markBigAnim: function (el) {
      try { if (el && el.classList) el.classList.add('dsh-th-big-anim'); } catch (e) {}
    },
  };

  // 首帧就把样式挂上（NORMAL 档为空操作，不会引起任何重排）
  try { applyCss(0); } catch (e) {}
})();

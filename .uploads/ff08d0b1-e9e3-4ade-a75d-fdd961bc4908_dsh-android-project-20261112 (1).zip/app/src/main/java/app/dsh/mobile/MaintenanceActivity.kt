package app.dsh.mobile

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import app.dsh.mobile.engine.BootTrace
import app.dsh.mobile.engine.EngineUpdater
import app.dsh.mobile.engine.PluginKillSwitch
import app.dsh.mobile.engine.HomeResetter
import app.dsh.mobile.engine.SelfCheck

/**
 * 维护与高级（v1.4.45）：从设置主页收拢的诊断与高风险操作子页。
 *
 * 收进来的四行：插件应急总开关、全面体检与修复、上次启动详情、重启引擎。
 * 这些都是「出问题才进来」的工具 —— 和日常偏好混排会稀释主页，也容易误触。
 * 体检/启动详情用 [ReportDialog] 结构化展示（状态徽章列表），不再堆纯文本。
 */
class MaintenanceActivity : ThemedActivity() {
    /** 属于设置体系：启用「设置页背景图」（见 ThemedActivity.usesSettingsBackground）。 */
    override val usesSettingsBackground: Boolean get() = true


    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OrientationPrefs.applyToSettingsPage(this)
        setContentView(R.layout.activity_maintenance)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }

        // —— 插件应急总开关（v1.4.27）：插件把 WebUI 弄坏但引擎还活着时的逃生门 ——
        findViewById<LinearLayout>(R.id.rowPluginKill).setOnClickListener {
            confirmKillSwitch()
        }

        // —— 本地导入运行时：文件选择器 / 指定手机目录 ——
        findViewById<LinearLayout>(R.id.rowImportRuntime)?.setOnClickListener {
            runCatching { RuntimeImporter.pickZip(this) }.onFailure {
                Toast.makeText(this, getString(R.string.runtime_import_failed, it.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
        findViewById<LinearLayout>(R.id.rowImportRuntimeDir)?.setOnClickListener {
            runCatching { RuntimeImporter.pickDirectory(this) }.onFailure {
                Toast.makeText(this, getString(R.string.runtime_import_failed, it.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }

        // —— 引擎层热更新：只替换 @deepseek-ai，基础运行时不动 ——
        refreshEngineSub()
        findViewById<LinearLayout>(R.id.rowCheckEngine)?.setOnClickListener { checkEngineUpdate() }
        findViewById<LinearLayout>(R.id.rowRollbackEngine)?.setOnClickListener { confirmEngineRollback() }

        // —— 删除对话（v1.6.17）：只跳转，不做任何扫描 ——
        //
        // 用户硬约束「不要启动时读取，一定不要让任何事情影响启动速度」：
        // 这里**只绑一个 startActivity**，会话枚举全部发生在
        // WipeChatsActivity 的后台线程里。本 Activity 自身也不会去数会话数
        // （那同样是 IO）—— 副标题保持静态文案。
        findViewById<LinearLayout>(R.id.rowWipeChats).setOnClickListener {
            startActivity(android.content.Intent(this, WipeChatsActivity::class.java))
        }

        // —— 全面体检与修复（v1.4.4）：逐条展示，异常项带具体数值 ——
        val selfCheckSub = findViewById<TextView>(R.id.txtSelfCheckSub)
        findViewById<LinearLayout>(R.id.rowSelfCheck).setOnClickListener {
            selfCheckSub.text = getString(R.string.self_check_running)
            Thread({
                val report = runCatching { SelfCheck.run(this) }.getOrNull()
                runOnUiThread {
                    if (report == null) {
                        selfCheckSub.text = getString(
                            R.string.recover_failed, getString(R.string.file_editor_read_failed),
                        )
                        return@runOnUiThread
                    }
                    selfCheckSub.text = if (report.issues == 0) {
                        getString(R.string.self_check_ok)
                    } else {
                        getString(R.string.self_check_issues, report.issues, report.fixed)
                    }
                    ReportDialog.show(
                        this,
                        getString(R.string.setting_self_check),
                        report.items.map { item ->
                            ReportDialog.Item(
                                status = when (item.status) {
                                    SelfCheck.Item.Status.OK -> ReportDialog.Status.OK
                                    SelfCheck.Item.Status.FIXED -> ReportDialog.Status.FIXED
                                    SelfCheck.Item.Status.WARN -> ReportDialog.Status.WARN
                                    SelfCheck.Item.Status.FAIL -> ReportDialog.Status.FAIL
                                },
                                title = item.title,
                                detail = item.detail,
                            )
                        },
                        getString(R.string.report_copy),
                        SelfCheck.summarize(report),
                    )
                }
            }, "self-check").start()
        }

        // —— 上次启动详情（v1.4.8）：各阶段耗时，不用再翻 engine.log ——
        findViewById<LinearLayout>(R.id.rowBootTrace).setOnClickListener {
            val snap = BootTrace.snapshot.value
            val items = ArrayList<ReportDialog.Item>()
            if (snap.startedAt <= 0) {
                items.add(ReportDialog.Item(ReportDialog.Status.WARN, getString(R.string.boot_trace_none)))
            } else {
                items.add(
                    ReportDialog.Item(
                        ReportDialog.Status.OK,
                        getString(R.string.boot_step_runtime),
                        String.format(java.util.Locale.US, "%.1fs", snap.elapsedMs() / 1000.0) +
                            if (snap.running) " · " + getString(R.string.boot_trace_running) else "",
                    ),
                )
                val ins = snap.install
                if (ins.totalFiles > 0) {
                    items.add(
                        ReportDialog.Item(
                            ReportDialog.Status.OK,
                            getString(R.string.splash_files, ins.doneFiles, ins.totalFiles),
                        ),
                    )
                }
                snap.steps.forEach { s ->
                    items.add(
                        ReportDialog.Item(
                            ReportDialog.Status.OK,
                            s.key,
                            String.format(java.util.Locale.US, "%d ms (at +%d ms)", s.durationMs, s.atMs),
                        ),
                    )
                }
                if (snap.failure != null) {
                    items.add(ReportDialog.Item(ReportDialog.Status.FAIL, getString(R.string.report_error), snap.failure))
                }
            }
            ReportDialog.show(
                this,
                getString(R.string.boot_trace_title),
                items,
                getString(R.string.report_copy),
                BootTrace.readLogTail(this, 32 * 1024),
            )
        }

        // —— 查看日志（v1.4.45 迁自设置页数据区）：崩溃/无限重启的核心排查入口 ——
        findViewById<LinearLayout>(R.id.rowViewLog).setOnClickListener {
            startActivity(android.content.Intent(this, LogViewerActivity::class.java))
        }

        // —— 重启引擎：有中断后果，先确认再动手（v1.4.45 起）——
        findViewById<LinearLayout>(R.id.rowRestart).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.restart_confirm_title))
                .setMessage(getString(R.string.restart_confirm_body))
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    (application as DshApp).supervisor.restart()
                    Toast.makeText(this, getString(android.R.string.ok), Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .showStyled()
        }

        // —— 深度清理 / 彻底重置（v1.4.56，用户反馈「体检修不好只能重装」）——
        findViewById<LinearLayout>(R.id.rowDeepClean).setOnClickListener {
            confirmClean(HomeResetter.Mode.DEEP)
        }
        findViewById<LinearLayout>(R.id.rowResetHome).setOnClickListener {
            confirmClean(HomeResetter.Mode.RESET)
        }
        // 右侧的按钮也绑一份：它是 TextView 且带 background，会消费点击事件，
        // 父容器的监听收不到（v1.4.56 实测「点了没反应」）
        findViewById<TextView>(R.id.btnResetHome)?.setOnClickListener {
            confirmClean(HomeResetter.Mode.RESET)
        }
        findViewById<TextView>(R.id.btnDeepClean)?.setOnClickListener {
            confirmClean(HomeResetter.Mode.DEEP)
        }
        // —— 修复文件属主（v1.4.70）——
        findViewById<LinearLayout>(R.id.rowFixOwner)?.setOnClickListener { runFixOwner() }
        findViewById<LinearLayout>(R.id.rowGrantPerms)?.setOnClickListener { runGrantPerms() }
        findViewById<TextView>(R.id.btnGrantPerms)?.setOnClickListener { runGrantPerms() }
        refreshGrantSub()
        findViewById<TextView>(R.id.btnFixOwner)?.setOnClickListener { runFixOwner() }
        refreshHomeUsage()
    }

    /**
     * 「修复文件属主」按钮（v1.4.70）。
     *
     * ## 为什么需要这个按钮
     *
     * 宝宝反复踩同一个坑：只要在 Root 模式（或从 adb 用 `su`）跑过 pnpm，
     * `profiles/web` 下就会有文件属主变成 uid 0，或者被剥掉 SELinux 的
     * MCS 分类（`s0` 而不是 `s0:c232,c257,c512,c768`）。App 自己的 uid 是
     * 10488，读不了也删不动，表现为：
     *
     *     Error: EACCES: permission denied, open '.../package.json.lock'
     *     ERR_PNPM_PACKAGE_MANAGER_REMOVE_MODULES_DIR
     *       ╰─▶ Failed to remove .../node_modules/.bin: Permission denied
     *
     * 旧版本只有两条路：等引擎启动时的 `dshHomeNeedsOwnershipFix` 自愈
     * （要重启才触发），或者「深度清理 / 卸载重装」（会把插件全删了）。
     * 这里给一个就地入口，不动任何数据。
     *
     * ## 为什么可能失败
     *
     * `chown` 跨 uid 与 `chcon` 都是 root 专属：普通模式（无 Shizuku、无 su）
     * 只能修「属主已经是自己、只是权限位被剥」的那部分，root 占有的文件改不动。
     * 这种情况如实提示去开 Shizuku / Root 模式，不假装成功。
     */
    private fun runFixOwner() {
        val sub = findViewById<TextView>(R.id.txtFixOwnerSub)
        val btn = findViewById<TextView>(R.id.btnFixOwner)
        btn?.isEnabled = false
        sub?.text = getString(R.string.fix_owner_progress)
        Thread {
            val dbg = StringBuilder()
            fun log(s: String) {
                dbg.append(s).append(System.lineSeparator())
                android.util.Log.w("FixOwner", s)
                runCatching {
                    java.io.File(filesDir, "fix-owner-debug.log").writeText(dbg.toString())
                }
            }
            log("start, home=" + app.dsh.mobile.engine.EngineConfig.dshHome(this).absolutePath)
            // v1.4.75：**点了就修，不再先探测**。
            //
            // 旧的 `need = dshHomeNeedsOwnershipFix()` 前置判断有两个坑（真机实测）：
            //   ① 探测本身会漏报 —— 真机上有 root 占有的 node_modules/.root_test，
            //      但 need 仍返回 false，于是直接提示「没有发现异常文件」什么都不做；
            //   ② 探测路径里 `runPrivileged` 在 ROOT 模式下走的是引擎侧 su，
            //      对「app 自己改不动」的文件判定不完整。
            // 而「修复」本身是幂等的：全对的情况下 chown/chmod 都是空操作，代价
            // 只有一次目录遍历。用户点这个按钮的意图就是「我怀疑坏了，帮我修」，
            // 所以直接执行，再用修复后的复检结果决定提示文案。
            val ok = runCatching {
                app.dsh.mobile.engine.Privilege.fixHomeOwnership(this)
            }.getOrElse { log("fix threw: " + it); false }
            log("fixed=$ok")
            val stillBad = runCatching {
                app.dsh.mobile.engine.Privilege.dshHomeNeedsOwnershipFix(this)
            }.getOrDefault(false)
            log("stillBad=$stillBad")
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                btn?.isEnabled = true
                val msg = when {
                    ok && !stillBad -> R.string.fix_owner_ok
                    // 修完复检仍报坏：多半是需要 root 才能动的条目，别谎报成功
                    stillBad -> R.string.fix_owner_fail
                    ok -> R.string.fix_owner_ok
                    else -> R.string.fix_owner_none
                }
                Toast.makeText(this, getString(msg), Toast.LENGTH_LONG).show()
                sub?.text = getString(R.string.setting_fix_owner_sub)
            }
        }.apply { isDaemon = true }.start()
    }

    /**
     * 一键授予全部权限（v1.5.0-beta.9）。
     *
     * ## 为什么无差别尝试
     * 不挑白名单 —— 把 Manifest 里声明的每一个权限都试一遍 `pm grant`。能拿就拿，
     * 拿不到也只花一条命令的代价。这样未来系统版本把某个权限从 signature 放宽成
     * development 时，我们自动就能拿到，不用改代码。
     *
     * ## 为什么必须回读
     * `pm grant` 的退出码对「未声明的权限」也返回 0（静默成功但完全不生效）。
     * 所以每个权限grant 完都 `checkSelfPermission` 复核，只统计真的拿到手的。
     */
    private fun runGrantPerms() {
        val sub = findViewById<TextView>(R.id.txtGrantPermsSub)
        val btn = findViewById<TextView>(R.id.btnGrantPerms)
        btn?.isEnabled = false
        sub?.text = getString(R.string.grant_perms_progress)
        // 走 startAsync：全量上千条要一两分钟，后台线程池跑，UI 只轮询进度。
        // 不用裸 Thread，是因为 PermGrant 内部要保证同一时刻只有一轮在跑。
        app.dsh.mobile.engine.PermGrant.startAsync(this, force = true)
        Thread {
            var last = -1
            var waited = 0
            while (waited < 300_000) {
                val p = app.dsh.mobile.engine.PermGrant.progress(this)
                if (p.done != last) {
                    last = p.done
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        sub?.text = "${p.done} / ${p.total}  +${p.newlyGranted}"
                    }
                }
                if (!p.running) break
                Thread.sleep(400)
                waited += 400
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                btn?.isEnabled = true
                val p = app.dsh.mobile.engine.PermGrant.progress(this)
                val msg = when {
                    p.lastGranted < 0 -> getString(R.string.grant_perms_fail)
                    p.lastGranted > 0 -> getString(R.string.grant_perms_ok, p.lastGranted)
                    else -> getString(R.string.grant_perms_none, app.dsh.mobile.engine.PermGrant.grantedCount(this), p.total)
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                refreshGrantSub()
            }
        }.apply { isDaemon = true }.start()
    }

    /** 刷新一键授权行的副标题：显示当前已拿到多少 / 总共声明多少。 */
    private fun refreshGrantSub() {
        val sub = findViewById<TextView>(R.id.txtGrantPermsSub) ?: return
        val total = app.dsh.mobile.engine.PermGrant.declaredPermissions(this).size
        val got = app.dsh.mobile.engine.PermGrant.grantedCount(this)
        sub.text = if (total > 0) "$got / $total" else getString(R.string.setting_grant_perms_sub)
    }

    /**
     * 清理前的确认流程。
     *
     * 顺序：用量摘要 -> 用户选备份位置 -> 二次确认（RESET 还要输入 RESET）
     * -> 停引擎 -> 清理 -> 重启引擎。任何一步取消都安全退出。
     *
     * 为什么必须先停引擎：运行中删除会让引擎崩溃在半途，且它持有的 fd 会让
     * 删除失败（表现为「删了一半」这种更难查的状态）。
     */
    private fun confirmClean(mode: HomeResetter.Mode) {
        // 体积统计必须在后台算（见 refreshHomeUsage 的 ANR 说明）。
        // 算的这点时间用户感知不到，先显示一个「正在计算」的占位更稳。
        Toast.makeText(this, getString(R.string.clean_calculating), Toast.LENGTH_SHORT).show()
        Thread {
            val usage = runCatching { HomeResetter.usage(this) }.getOrNull()
            val willDelete = when (mode) {
                HomeResetter.Mode.DEEP -> usage?.cacheBytes ?: 0L
                HomeResetter.Mode.RESET -> usage?.totalBytes ?: 0L
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val titleId = if (mode == HomeResetter.Mode.DEEP) {
                    R.string.setting_deep_clean
                } else {
                    R.string.setting_reset_home
                }
                val body = when (mode) {
                    HomeResetter.Mode.DEEP ->
                        getString(R.string.deep_clean_confirm_body, formatSize(willDelete))
                    HomeResetter.Mode.RESET ->
                        getString(R.string.reset_home_confirm_body, formatSize(willDelete))
                }
                AlertDialog.Builder(this)
                    .setTitle(titleId)
                    .setMessage(body)
                    .setNegativeButton(android.R.string.cancel, null)
                    .setPositiveButton(R.string.action_choose_backup) { _, _ -> pickBackupLocation(mode) }
                    .showStyled()
            }
        }.apply { isDaemon = true }.start()
    }

    /** 让用户用系统文件选择器指定备份位置（选完才真正动手）。 */
    private fun pickBackupLocation(mode: HomeResetter.Mode) {
        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US)
            .format(java.util.Date())
        val tag = if (mode == HomeResetter.Mode.DEEP) "clean" else "reset"
        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE)
            .setType("application/zip")
            .putExtra(android.content.Intent.EXTRA_TITLE, "dsh-home-before-" + tag + "-" + stamp + ".zip")
        runCatching {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_BACKUP)
            pendingMode = mode
        }.onFailure {
            Toast.makeText(this, getString(R.string.backup_unavailable, it.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            RuntimeImporter.REQ_PICK_ZIP -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) {
                    RuntimeImporter.persistRead(this, uri)
                    startRuntimeImport(RuntimeImporter.Source("runtime.zip", uri))
                }
            }
            RuntimeImporter.REQ_PICK_DIR -> {
                val uri = data?.data
                if (resultCode != RESULT_OK || uri == null) return
                RuntimeImporter.persistRead(this, uri)
                val zips = RuntimeImporter.listZips(this, uri)
                when {
                    zips.isEmpty() ->
                        Toast.makeText(this, R.string.runtime_import_no_zip, Toast.LENGTH_LONG).show()
                    zips.size == 1 -> startRuntimeImport(zips[0])
                    else -> AlertDialog.Builder(this)
                        .setTitle(R.string.runtime_import_choose)
                        .setItems(zips.map { it.name }.toTypedArray()) { _, i ->
                            startRuntimeImport(zips[i])
                        }
                        .setNegativeButton(android.R.string.cancel, null)
                        .showStyled()
                }
            }
            REQ_BACKUP -> {
                val uri = data?.data
                val mode = pendingMode
                pendingMode = null
                if (resultCode != RESULT_OK || uri == null || mode == null) return
                // RESET 不可逆（且备份可能失败），要求输入确认词
                if (mode == HomeResetter.Mode.RESET) {
                    askResetTypedConfirm(uri)
                } else {
                    executeClean(mode, uri)
                }
            }
        }
    }

    private var importDialog: AlertDialog? = null
    private var importBar: ProgressBar? = null
    private var importText: TextView? = null

    /** 本地 zip → 解压安装 → 重启引擎。 */
    private fun startRuntimeImport(source: RuntimeImporter.Source) {
        if (importDialog?.isShowing == true) return
        val d = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val text = TextView(this).apply {
            this.text = getString(R.string.runtime_import_progress)
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, (10 * d).toInt(), 0, 0)
        }
        box.addView(bar)
        box.addView(text)
        importBar = bar
        importText = text

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.runtime_import_progress)
            .setView(box)
            .setCancelable(false)
            .create()
        importDialog = dialog
        dialog.show()

        RuntimeImporter.import(
            this,
            source,
            onProgress = { p -> importBar?.progress = (p.coerceIn(0f, 1f) * 100).toInt() },
            onDetail = { info ->
                if (info.totalFiles > 0 && info.doneFiles <= info.totalFiles) {
                    importText?.text =
                        getString(R.string.runtime_import_files, info.doneFiles, info.totalFiles)
                }
            },
            onDone = {
                dismissImport()
                Toast.makeText(this, R.string.runtime_import_done, Toast.LENGTH_SHORT).show()
                Toast.makeText(this, R.string.runtime_import_restarting, Toast.LENGTH_SHORT).show()
                (application as DshApp).supervisor.restart()
            },
            onError = { e ->
                dismissImport()
                Toast.makeText(
                    this,
                    getString(R.string.runtime_import_failed, e.message ?: e.javaClass.simpleName),
                    Toast.LENGTH_LONG,
                ).show()
            },
        )
    }

    private fun dismissImport() {
        runCatching { importDialog?.dismiss() }
        importDialog = null
        importBar = null
        importText = null
    }

    private fun refreshEngineSub() {
        val sub = findViewById<TextView>(R.id.txtEngineSub) ?: return
        val ver = EngineUpdater.currentVersion(this)
        sub.text = if (ver.isNullOrBlank()) {
            getString(R.string.engine_check_sub)
        } else {
            getString(R.string.engine_current, ver)
        }
    }

    /** 只替换 @deepseek-ai 引擎层；基础运行时与用户数据不动。 */
    private fun checkEngineUpdate() {
        val sub = findViewById<TextView>(R.id.txtEngineSub)
        sub?.text = getString(R.string.engine_checking)
        Thread({
            val entry = runCatching { EngineUpdater.checkForUpdate(this) }.getOrNull()
            if (entry == null) {
                runOnUiThread {
                    Toast.makeText(this, R.string.engine_latest, Toast.LENGTH_SHORT).show()
                    refreshEngineSub()
                }
                return@Thread
            }
            val result = EngineUpdater.updateFromIndex(this, entry)
            runOnUiThread {
                when (result) {
                    is EngineUpdater.Result.Ok -> {
                        val msg = getString(R.string.engine_updated, result.version)
                        sub?.text = msg
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                        (application as DshApp).supervisor.restart()
                    }
                    is EngineUpdater.Result.Failed -> {
                        val msg = getString(R.string.engine_failed, result.message)
                        sub?.text = msg
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }, "engine-check").start()
    }

    private fun confirmEngineRollback() {
        AlertDialog.Builder(this)
            .setTitle(R.string.engine_rollback)
            .setMessage(R.string.engine_rollback_sub)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                Thread({
                    val ok = EngineUpdater.rollback(this)
                    runOnUiThread {
                        if (ok) {
                            Toast.makeText(this, R.string.engine_rollback_done, Toast.LENGTH_SHORT).show()
                            (application as DshApp).supervisor.restart()
                        } else {
                            Toast.makeText(this, R.string.engine_rollback_failed, Toast.LENGTH_LONG).show()
                        }
                    }
                }, "engine-rollback").start()
            }
            .showStyled()
    }

    /** RESET 的二次确认：必须手输 RESET 四个字母，防止误触。 */
    private fun askResetTypedConfirm(uri: android.net.Uri) {
        val input = android.widget.EditText(this).apply {
            hint = getString(R.string.reset_type_hint)
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.reset_final_title)
            .setMessage(getString(R.string.reset_final_body))
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                if (input.text.toString().trim().equals("RESET", ignoreCase = true)) {
                    executeClean(HomeResetter.Mode.RESET, uri)
                } else {
                    Toast.makeText(this, getString(R.string.reset_wrong_word), Toast.LENGTH_SHORT).show()
                }
            }
            .showStyled()
    }

    /**
     * 执行：备份 -> 停引擎 -> 清理 -> 重启。
     *
     * 备份失败就**中止**。RESET 尤其如此：没有备份的彻底重置等于让用户丢失
     * API 凭证和会话历史，不可接受。DEEP 保持一致行为，避免两套语义。
     */
    private fun executeClean(mode: HomeResetter.Mode, target: android.net.Uri) {
        val progress = android.app.ProgressDialog(this).apply {
            setMessage(getString(R.string.backup_running))
            setCancelable(false)
            show()
        }
        Thread {
            var backupErr: String? = null
            try {
                val out = contentResolver.openOutputStream(target)
                if (out == null) {
                    backupErr = "cannot open output stream"
                } else {
                    out.use {
                        HomeResetter.backupTo(this, it) { done ->
                            runOnUiThread {
                                progress.setMessage(getString(R.string.backup_progress, formatSize(done)))
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                backupErr = e.message ?: e.javaClass.simpleName
            }

            if (backupErr != null) {
                runOnUiThread {
                    progress.dismiss()
                    AlertDialog.Builder(this)
                        .setTitle(R.string.backup_failed_title)
                        .setMessage(getString(R.string.backup_failed_body, backupErr ?: ""))
                        .setPositiveButton(android.R.string.ok, null)
                        .showStyled()
                }
                return@Thread
            }

            runOnUiThread { progress.setMessage(getString(R.string.clean_running)) }
            val app = application as DshApp
            // 停引擎：运行中删除会让引擎崩溃在半途
            runCatching { app.supervisor.stopForMaintenance() }

            val result = runCatching { HomeResetter.run(this, mode) }
                .getOrElse {
                    HomeResetter.Result(
                        ok = false,
                        mode = mode,
                        removedBytes = 0,
                        removedEntries = 0,
                        failures = listOf(it.message ?: "unknown"),
                        preserved = emptyList(),
                        error = it.message,
                    )
                }

            runOnUiThread {
                progress.dismiss()
                AlertDialog.Builder(this)
                    .setTitle(if (result.ok) R.string.clean_done_title else R.string.clean_partial_title)
                    .setMessage(cleanSummary(mode, result))
                    .setPositiveButton(R.string.action_restart_now) { _, _ ->
                        app.supervisor.restart()
                        Toast.makeText(this, getString(R.string.engine_restarting), Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .showStyled()
                refreshHomeUsage()
            }
        }.start()
    }

    private fun cleanSummary(mode: HomeResetter.Mode, r: HomeResetter.Result): String {
        val nl = System.lineSeparator()
        return buildString {
            append(getString(R.string.clean_summary_removed, r.removedEntries, formatSize(r.removedBytes)))
            if (r.preserved.isNotEmpty()) {
                append(nl).append(getString(R.string.clean_summary_preserved, r.preserved.joinToString(", ")))
            }
            if (r.failures.isNotEmpty()) {
                append(nl).append(getString(R.string.clean_summary_failed, r.failures.joinToString(", ")))
            }
            append(nl).append(nl).append(getString(R.string.clean_summary_backup_hint))
            if (mode == HomeResetter.Mode.RESET) {
                append(nl).append(getString(R.string.clean_summary_reset_hint))
            }
        }
    }

    /**
     * 刷新两行副标题上的体积摘要。
     *
     * ⚠️ v1.4.56 实测 ANR：体积统计要遍历 `.cache`（6 万多个文件），在
     * `onCreate` 里同步调用会阻塞主线程 >5s，系统直接弹「应用无响应」。
     * 必须放到后台线程，算完再回主线程设置文本。
     *
     * 未算完时先显示静态副标题（不显示体积），避免出现空白或假数字。
     */
    private fun refreshHomeUsage() {
        val deep = findViewById<TextView>(R.id.subDeepClean) ?: return
        val reset = findViewById<TextView>(R.id.subResetHome) ?: return
        Thread {
            val u = runCatching { HomeResetter.usage(this) }.getOrNull() ?: return@Thread
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                deep.text = getString(R.string.setting_deep_clean_sub_usage, formatSize(u.cacheBytes))
                reset.text = getString(R.string.setting_reset_home_sub_usage, formatSize(u.totalBytes))
            }
        }.apply { isDaemon = true }.start()
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024 * 1024 ->
            String.format(java.util.Locale.US, "%.1f GB", bytes / 1024.0 / 1024 / 1024)
        bytes >= 1024L * 1024 ->
            String.format(java.util.Locale.US, "%.1f MB", bytes / 1024.0 / 1024)
        bytes >= 1024L ->
            String.format(java.util.Locale.US, "%.0f KB", bytes / 1024.0)
        else -> bytes.toString() + " B"
    }

    private var pendingMode: HomeResetter.Mode? = null
    private val REQ_BACKUP = 9101

    override fun onResume() {
        super.onResume()
        // 从外观页返回时偏好可能已变（开关/朝向），重新对齐一次；值未变时是空操作
        OrientationPrefs.applyToSettingsPage(this)
        refreshPluginKill()
    }

    /**
     * 插件应急总开关的状态刷新（v1.4.27，v1.4.45 迁入本页）。
     * 标题随状态变：正常时是「停用全部第三方插件」，停用后变成「恢复第三方插件」。
     * 状态来自意图日志（[PluginKillSwitch.status]），引擎重启中也永远显示真实状态。
     */
    private fun refreshPluginKill() {
        val title = findViewById<TextView>(R.id.valPluginKill) ?: return
        val sub = findViewById<TextView>(R.id.txtPluginKillSub) ?: return
        val btn = findViewById<TextView>(R.id.btnPluginKill) ?: return
        val st = runCatching { PluginKillSwitch.status(this) }.getOrNull() ?: return
        if (st.active) {
            title.text = getString(R.string.setting_plugin_kill_restore)
            sub.text = if (st.allow.isNotEmpty()) {
                getString(
                    R.string.setting_plugin_kill_restore_sub_partial,
                    st.allow.size, st.disabled.size,
                )
            } else {
                getString(R.string.setting_plugin_kill_restore_sub, st.disabled.size)
            }
            sub.setTextColor(getColor(R.color.warning))
            btn.text = getString(R.string.action_restore)
        } else {
            title.text = getString(R.string.setting_plugin_kill)
            sub.text = getString(R.string.setting_plugin_kill_sub, st.thirdParty.size)
            sub.setTextColor(getColor(R.color.text_secondary))
            btn.text = getString(R.string.action_disable)
        }
    }

    /** 确认框：把将被停用/恢复的包名列出来，别让用户盲点 */
    private fun confirmKillSwitch() {
        val st = runCatching { PluginKillSwitch.status(this) }.getOrNull() ?: return
        val restore = st.active
        val list = if (restore) st.disabled else st.thirdParty
        if (list.isEmpty()) {
            Toast.makeText(this, getString(R.string.plugin_kill_none), Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(
                if (restore) R.string.plugin_kill_restore_title
                else R.string.plugin_kill_disable_title,
            )
            .setMessage(
                getString(
                    if (restore) R.string.plugin_kill_restore_body
                    else R.string.plugin_kill_disable_body,
                    list.size,
                    summarizePackages(list),
                ),
            )
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ -> applyKillSwitch(restore) }
            .showStyled()
    }

    /** 包名列表：超过 8 个只列前 8 个 + 「等 N 个」，避免对话框撑满屏幕 */
    private fun summarizePackages(list: List<String>): String {
        val head = list.take(8).joinToString("\n") { "· $it" }
        return if (list.size <= 8) head
        else head + "\n" + getString(R.string.plugin_kill_more, list.size - 8)
    }

    /**
     * 落意图 + 重启引擎（v1.4.45 迁入本页）。
     *
     * ⚠️ 只写意图日志，不改 profiles/web/package.json —— 引擎运行中会把内存里的
     * profile 状态写回去；真正的数组改写由监督器在下次 spawn 前完成。
     */
    private fun applyKillSwitch(restore: Boolean) {
        val outcome =
            if (restore) PluginKillSwitch.requestEnable(this)
            else PluginKillSwitch.requestDisable(this, "maintenance")
        if (!outcome.ok) {
            Toast.makeText(
                this,
                getString(R.string.plugin_kill_failed, outcome.message),
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        Toast.makeText(this, getString(R.string.plugin_kill_restarting), Toast.LENGTH_SHORT).show()
        (application as DshApp).supervisor.restart()
        refreshPluginKill()
    }

    /** 统一弹窗样式：覆盖自绘圆角背景 */
    private fun AlertDialog.Builder.showStyled(): AlertDialog =
        create().apply {
            window?.setWindowAnimations(R.style.SettingsDialogAnimation)
            setOnShowListener {
                window?.setBackgroundDrawableResource(R.drawable.bg_dialog_rounded)
            }
            show()
        }
}

package app.dsh.mobile.engine

import android.content.Context
import android.util.Log
import app.dsh.mobile.DshApp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 插件快速启动：启动前临时摘除第三方 bundle，核心引擎先起、WebUI 先显示；
 * HTTP 就绪后恢复 profile 并 touch patch 文件，交给 dsh-hmr 流式热加载插件。
 */
object PluginFastBoot {
    private const val TAG = "PluginFastBoot"
    private const val KEY = "fast_plugin_boot"
    private const val BACKUP = ".fastboot-backup.json"
    private const val PATCH_TOUCH = "\n# dsh-fastboot release "

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .getBoolean(KEY, true)

    fun requestSkipNext(ctx: Context) {
        // commit() 而非 apply()：调用方紧接着就 restart()，后台线程可能在同一
        // 毫秒内 consume；apply 的异步落盘 + 读侧竞态会让「跳过快速启动」失效，
        // 于是删除对话后的重启又走 hold 路径（摘第三方插件 + 靠 HMR 补），
        // 正是 directoryPickerController unavailable 的现场。
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .edit().putBoolean("fast_plugin_boot_skip_once", true).commit()
    }

    fun consumeSkipNext(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
        val v = p.getBoolean("fast_plugin_boot_skip_once", false)
        if (v) p.edit().putBoolean("fast_plugin_boot_skip_once", false).commit()
        return v
    }

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(DshApp.PREFS_UI, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY, on).apply()
    }

    private fun profileDir(ctx: Context) = File(EngineConfig.dshHome(ctx), "profiles/web")

    fun hold(ctx: Context): Boolean {
        if (!enabled(ctx)) return false
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        if (!manifest.isFile) return false
        val backup = File(dir, BACKUP)
        if (backup.isFile) {
            runCatching {
                atomicWrite(manifest, backup.readText())
                backup.delete()
            }.onFailure { Log.w(TAG, "pending restore failed: ${it.message}") }
        }
        val root = runCatching { JSONObject(manifest.readText()) }.getOrNull() ?: return false
        val profile = root.optJSONObject("dsh")?.optJSONObject("profile") ?: return false
        val bundles = profile.optJSONArray("bundles") ?: return false
        val deps = root.optJSONObject("dependencies") ?: JSONObject()
        val keep = JSONArray()
        var removed = 0
        for (i in 0 until bundles.length()) {
            val name = bundles.optString(i)
            val thirdParty = deps.has(name) && !name.startsWith("@deepseek-ai/")
            if (thirdParty) removed++ else keep.put(name)
        }
        if (removed == 0) return false
        return runCatching {
            backup.writeText(manifest.readText())
            profile.put("bundles", keep)
            atomicWrite(manifest, root.toString(2))
            Log.i(TAG, "fast boot: deferred $removed third-party bundle(s)")
            true
        }.getOrElse {
            Log.w(TAG, "fast boot hold failed: ${it.message}")
            false
        }
    }

    fun release(ctx: Context): Boolean {
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        val backup = File(dir, BACKUP)
        if (!backup.isFile) return false
        val ok = runCatching {
            atomicWrite(manifest, backup.readText())
            backup.delete()
            true
        }.getOrElse {
            Log.w(TAG, "fast boot release failed: ${it.message}")
            false
        }
        if (ok) touchPatch(dir)
        return ok
    }

    fun rollback(ctx: Context): Boolean {
        val dir = profileDir(ctx)
        val manifest = File(dir, "package.json")
        val backup = File(dir, BACKUP)
        if (!backup.isFile) return false
        return runCatching {
            atomicWrite(manifest, backup.readText())
            backup.delete()
            true
        }.getOrElse { false }
    }

    private fun touchPatch(dir: File) {
        runCatching {
            File(dir, "cordis.patch.yml").appendText(PATCH_TOUCH + System.currentTimeMillis() + "\n")
            Log.i(TAG, "profile patch touched for HMR plugin reload")
        }.onFailure { Log.w(TAG, "touch patch failed: ${it.message}") }
    }

    private fun atomicWrite(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) {
            target.writeText(text)
            tmp.delete()
        }
    }
}
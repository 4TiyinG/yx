package app.dsh.mobile.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** 插件后台加载状态（与引擎状态解耦，供 UI 展示）。 */
object PluginBootBus {
    enum class State { IDLE, HOLDING, LOADING, DONE, PARTIAL, FAILED }

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state

    fun set(s: State) {
        _state.value = s
    }
}
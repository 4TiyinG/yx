package app.dsh.mobile

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/**
 * 全局 Edge-to-Edge 工具：状态栏保持显示但透明，导航栏透明，
 * 内容绘制到系统栏后方，同时用 Insets 保证安全区域。
 */
object EdgeToEdge {

    fun applyWindow(activity: Activity) {
        val w = activity.window ?: return

        @Suppress("DEPRECATION")
        w.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        w.navigationBarColor = Color.TRANSPARENT

        if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION")
            w.isStatusBarContrastEnforced = false
            @Suppress("DEPRECATION")
            w.isNavigationBarContrastEnforced = false
        }

        @Suppress("DEPRECATION")
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        WindowCompat.setDecorFitsSystemWindows(w, false)
        val controller = WindowCompat.getInsetsController(w, w.decorView)
        controller.show(WindowInsetsCompat.Type.systemBars())
        val light = !ThemeManager.isDark(activity)
        controller.isAppearanceLightStatusBars = light
        controller.isAppearanceLightNavigationBars = light
    }

    fun applyContentInsets(activity: Activity) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val root = content.getChildAt(0) as? View ?: return
        val base = basePaddings.getOrPut(root) {
            intArrayOf(root.paddingLeft, root.paddingTop, root.paddingRight, root.paddingBottom)
        }

        content.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime(),
            )
            // 顶部/左右避让系统栏与挖孔；底部不给根布局留白，
            // 背景与滚动内容都延伸到底部导航栏后方。
            root.updatePadding(
                left = base[0] + bars.left,
                top = base[1] + bars.top,
                right = base[2] + bars.right,
                bottom = base[3],
            )
            val hasScrollable = applyScrollableBottomPadding(root, bars.bottom)
            if (!hasScrollable) {
                // 终端/编辑器等非滚动页：根布局保留底部安全区，避免输入区被手势条遮住。
                root.updatePadding(bottom = base[3] + bars.bottom)
            }
            insets
        }
        ViewCompat.requestApplyInsets(content)
    }

    /**
     * 给滚动容器补底部内容内边距（clipToPadding=false），
     * 让列表可以滚动到导航栏/手势条后方，但不遮挡最后一项。
     * @return 是否找到滚动容器
     */
    private fun applyScrollableBottomPadding(root: View, insetBottom: Int): Boolean {
        var found = false
        fun visit(v: View) {
            if (v is android.widget.ScrollView) {
                found = true
                val original = scrollBasePaddings.getOrPut(v) { v.paddingBottom }
                val want = original + insetBottom
                if (v.paddingBottom != want) {
                    v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, want)
                }
                v.clipToPadding = false
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) visit(v.getChildAt(i))
            }
        }
        visit(root)
        return found
    }

    private val basePaddings = java.util.WeakHashMap<View, IntArray>()
    private val scrollBasePaddings = java.util.WeakHashMap<View, Int>()
}
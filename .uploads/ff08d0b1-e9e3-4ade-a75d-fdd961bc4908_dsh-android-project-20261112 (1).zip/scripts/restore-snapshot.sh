#!/usr/bin/env bash
# 从工作区 _snapshots/source-latest.tar.gz 恢复源码（可选参数：指定某份快照）。
set -euo pipefail
cd "$(dirname "$0")/.."
SNAP="${1:-_snapshots/source-latest.tar.gz}"
[ -f "$SNAP" ] || { echo "snapshot not found: $SNAP" >&2; exit 1; }
echo "restoring $SNAP"
tar -xzf "$SNAP" -C .
echo "restored to $(pwd)"
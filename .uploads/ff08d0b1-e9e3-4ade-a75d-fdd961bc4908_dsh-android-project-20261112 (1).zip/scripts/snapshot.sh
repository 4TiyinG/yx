#!/usr/bin/env bash
# 生成最新源码快照，并**校验 + 原子替换** source-latest.tar.gz。
# 触发：每次 chat.finished（.codeartsdoer/plugin）与每次成功构建（build-debug.sh）。
set -euo pipefail
cd "$(dirname "$0")/.."

OUT=_snapshots
mkdir -p "$OUT"
exec 9>"$OUT/.snapshot.lock"
flock -n 9 || { echo "snapshot busy, skip"; exit 0; }

STAMP=$(date +%Y%m%d-%H%M%S)
TMP="$OUT/.source-$STAMP.tmp.tar.gz"
LIST="$OUT/.snapshot.list"
cleanup() { rm -f "$TMP" "$LIST" "$OUT/.latest.new" "$OUT/.latest.sha.tmp"; }
trap cleanup EXIT

paths=(app/src app/build.gradle.kts app/proguard-rules.pro scripts
  build.gradle.kts settings.gradle.kts gradle.properties local.properties
  build-debug.sh community-plugins.json LICENSE NOTICE .gitignore .vscode
  .codeartsdoer/plugin)
[ -d debug-signing ] && paths+=(debug-signing)
[ -d .github ] && paths+=(.github)

tar -czf "$TMP" \
  --exclude='app/build' --exclude='app/.cxx' --exclude='.gradle' \
  --exclude='_snapshots' --exclude='_runtime_src' --exclude='.codeartsdoer/cache' \
  "${paths[@]}"

# 完整性：压缩包可读 + 关键文件存在
gzip -t "$TMP"
tar -tzf "$TMP" > "$LIST"
for f in \
  app/src/main/AndroidManifest.xml \
  app/src/main/java/app/dsh/mobile/MainActivity.kt \
  app/src/main/java/app/dsh/mobile/SettingsActivity.kt \
  build-debug.sh; do
  if ! grep -qx "$f" "$LIST"; then
    echo "snapshot incomplete: $f" >&2
    exit 1
  fi
done

SHA=$(sha256sum "$TMP" | awk '{print $1}')
FINAL="$OUT/source-$STAMP.tar.gz"
mv -f "$TMP" "$FINAL"

# 旧 latest 保留为 previous；新 latest 原子替换
if [ -f "$OUT/source-latest.tar.gz" ]; then
  cp -f "$OUT/source-latest.tar.gz" "$OUT/source-previous.tar.gz"
fi
cp -f "$FINAL" "$OUT/.latest.new"
mv -f "$OUT/.latest.new" "$OUT/source-latest.tar.gz"
printf '%s  %s\n' "$SHA" "_snapshots/source-latest.tar.gz" > "$OUT/.latest.sha.tmp"
mv -f "$OUT/.latest.sha.tmp" "$OUT/source-latest.sha256"

# 只保留最近 10 份时间戳快照（不删 latest/previous）
ls -1t "$OUT"/source-*.tar.gz 2>/dev/null \
  | grep -v -e 'source-latest' -e 'source-previous' \
  | tail -n +11 | xargs -r rm -f

echo "snapshot: $OUT/source-latest.tar.gz (sha256=$SHA)"
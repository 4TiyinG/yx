#!/usr/bin/env bash
# 把完整 runtime zip 拆出「引擎层」（@deepseek-ai 全家桶）并生成 engine-index.json。
#
#   scripts/package-engine.sh \
#     --runtime dist/runtime-arm64-v8a.zip \
#     --abi arm64-v8a --version 1.5.0 \
#     --out dist/engine-arm64-v8a-1.5.0.zip \
#     --manifest dist/engine-index.json \
#     --url https://github.com/<owner>/<repo>/releases/latest/download/engine-arm64-v8a-1.5.0.zip
#
# 可选：
#   --base-out dist/runtime-base-arm64-v8a.zip   生成去掉引擎层的基础层（CI 分层产物，不可直接单独安装）
#   --sign-key  path/to/ec-p256.key              用 release 私钥签名清单（输出 <manifest>.sig）
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RUNTIME=""
OUT=""
MANIFEST=""
BASE_OUT=""
ABI="arm64-v8a"
VERSION=""
URL=""
SIGN_KEY=""
MIN_APP_CODE="366"

usage() {
  cat >&2 <<'USAGE'
usage: package-engine.sh --runtime <runtime.zip> --version <ver> --out <engine.zip> \
         --manifest <engine-index.json> [--abi arm64-v8a] [--url <download-url>] \
         [--base-out <base.zip>] [--sign-key <pem>] [--min-app-code 366]
USAGE
  exit 2
}

while [ $# -gt 0 ]; do
  case "$1" in
    --runtime) RUNTIME="${2:?}"; shift 2 ;;
    --out) OUT="${2:?}"; shift 2 ;;
    --manifest) MANIFEST="${2:?}"; shift 2 ;;
    --base-out) BASE_OUT="${2:?}"; shift 2 ;;
    --abi) ABI="${2:?}"; shift 2 ;;
    --version) VERSION="${2:?}"; shift 2 ;;
    --url) URL="${2:?}"; shift 2 ;;
    --sign-key) SIGN_KEY="${2:?}"; shift 2 ;;
    --min-app-code) MIN_APP_CODE="${2:?}"; shift 2 ;;
    -h|--help) usage ;;
    *) echo "unknown arg: $1" >&2; usage ;;
  esac
done

[ -f "$RUNTIME" ] || { echo "runtime zip not found: $RUNTIME" >&2; exit 1; }
[ -n "$OUT" ] || usage
[ -n "$MANIFEST" ] || usage
[ -n "$VERSION" ] || usage
command -v python3 >/dev/null || { echo "python3 required" >&2; exit 1; }

mkdir -p "$(dirname "$OUT")" "$(dirname "$MANIFEST")"
if [ -n "$URL" ]; then URLARG="$URL"; else URLARG=""; fi
if [ -n "$BASE_OUT" ]; then BASEARG="$BASE_OUT"; else BASEARG=""; fi

python3 - "$RUNTIME" "$OUT" "$MANIFEST" "$ABI" "$VERSION" "$URLARG" "$BASEARG" "$MIN_APP_CODE" <<'PY'
import base64, hashlib, json, os, sys, time, zipfile

runtime, out, manifest, abi, version, url, base_out, min_code = sys.argv[1:9]
min_code = int(min_code)
PREFIX = "lib/node_modules/@deepseek-ai/"
SCOPE = "lib/node_modules/@deepseek-ai"

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

src = zipfile.ZipFile(runtime)
names = src.namelist()
engine_entries = [i for i in src.infolist() if i.filename == SCOPE or i.filename.startswith(PREFIX)]
if not engine_entries:
    raise SystemExit("runtime has no " + PREFIX)

unpacked = sum(i.file_size for i in engine_entries if not i.is_dir())
files = sum(1 for i in engine_entries if not i.is_dir())

def copy_entry(dst, info):
    data = b"" if info.is_dir() else src.read(info.filename)
    ni = zipfile.ZipInfo(info.filename, info.date_time)
    ni.external_attr = info.external_attr
    ni.create_system = info.create_system
    ni.compress_type = zipfile.ZIP_STORED if info.is_dir() else zipfile.ZIP_DEFLATED
    dst.writestr(ni, data)

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as dst:
    for i in engine_entries:
        copy_entry(dst, i)

z = zipfile.ZipFile(out)
def text(name):
    return z.read(name).decode("utf-8", "replace") if name in z.namelist() else ""

anchors = [
    SCOPE + "/dsh/lib/bin.js",
    SCOPE + "/cordis/lib/index.js",
    SCOPE + "/dsh-base/cordis.patch.yml",
    SCOPE + "/dsh-web-app/cordis.patch.yml",
    SCOPE + "/dsh-client-ui-chat/lib/client.js",
]
missing = [a for a in anchors if a not in z.namelist()]
if missing:
    raise SystemExit("engine zip missing anchors: " + ", ".join(missing))

ptc = text(SCOPE + "/dsh-ptc-runtime-node/lib/index.js")
need = ['"LD_LIBRARY_PATH"', "Inject the runtime library path unconditionally",
        "OPENSSL_CONF", "SSL_CERT_FILE", '"MAGICK_CONFIGURE_PATH"',
        "[dsh-android] bootstrap path fallback"]
if any(n not in ptc for n in need):
    raise SystemExit("engine layer lacks PTC patch; rebuild runtime first")

poly = text(SCOPE + "/dsh-web-frontend/dist/index.html")
need = ["legacy-webview polyfill v4", "throwIfAborted", "AbortSignal.any", "Promise.withResolvers"]
if any(n not in poly for n in need):
    raise SystemExit("engine layer lacks WebView polyfill v4")

if base_out:
    with zipfile.ZipFile(base_out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as dst:
        for i in src.infolist():
            if i.filename == SCOPE or i.filename.startswith(PREFIX):
                continue
            copy_entry(dst, i)

digest = sha256(out)
size = os.path.getsize(out)
built_at = int(time.time() * 1000)
if not url:
    url = ("https://github.com/Soodok/Deepseek-Harness-Local-Android/releases/latest/download/"
           + os.path.basename(out))

doc = {
    "schema": 1,
    "minAppVersionCode": min_code,
    "generatedAt": built_at,
    "engine": {
        abi: {
            "version": version,
            "builtAt": built_at,
            "sha256": digest,
            "size": size,
            "unpackedBytes": unpacked,
            "urls": [url],
        }
    },
}
with open(manifest, "w", encoding="utf-8") as f:
    json.dump(doc, f, indent=2, ensure_ascii=False)
    f.write("\n")

print("engine zip : %s" % out)
print("files      : %d" % files)
print("zip size   : %.1f MB" % (size / (1 << 20)))
print("unpacked   : %.1f MB" % (unpacked / (1 << 20)))
print("sha256     : %s" % digest)
print("manifest   : %s" % manifest)
if base_out:
    print("base zip   : %s (分层产物，需配合 engine 层安装)" % base_out)
PY

if [ -n "$SIGN_KEY" ]; then
  command -v openssl >/dev/null || { echo "openssl required for --sign-key" >&2; exit 1; }
  openssl dgst -sha256 -sign "$SIGN_KEY" -binary "$MANIFEST" | base64 > "$MANIFEST.sig"
  echo "signature  : $MANIFEST.sig"
else
  echo "note       : manifest 未签名；release 必须用 --sign-key 生成 .sig，否则客户端会拒绝在线更新。"
fi
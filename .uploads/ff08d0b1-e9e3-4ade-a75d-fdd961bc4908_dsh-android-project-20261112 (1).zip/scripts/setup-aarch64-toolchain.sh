#!/usr/bin/env bash
# 在 aarch64 Linux 上为 x86_64 Android 工具链建立 qemu 包装。
# 依赖：/opt/qemu-user/bin/qemu-x86_64-static、/opt/x86_64-sysroot、
#       /opt/android-sdk（已装 ndk;26.1.10909125 与 cmake;3.22.1）。
set -euo pipefail

QEMU=/opt/qemu-user/bin/qemu-x86_64-static
SYSROOT=/opt/x86_64-sysroot
NDK=/opt/toolchains/ndk-qemu
CMAKE=/opt/toolchains/cmake-qemu

[ -x "$QEMU" ] || { echo "missing $QEMU" >&2; exit 1; }
[ -d "$SYSROOT" ] || { echo "missing $SYSROOT" >&2; exit 1; }
[ -d /opt/android-sdk/ndk/26.1.10909125 ] || { echo "NDK not installed" >&2; exit 1; }
[ -d /opt/android-sdk/cmake/3.22.1 ] || { echo "CMake not installed" >&2; exit 1; }

mkdir -p /opt/toolchains /opt/toolchains/bin
rm -rf "$NDK" "$CMAKE"
cp -a /opt/android-sdk/ndk/26.1.10909125 "$NDK"
cp -a /opt/android-sdk/cmake/3.22.1 "$CMAKE"

# NDK 自带的 x86_64 libc++ 给 qemu 运行时用
PRE="$NDK/toolchains/llvm/prebuilt/linux-x86_64/lib/x86_64-unknown-linux-gnu"
mkdir -p "$SYSROOT/usr/lib/x86_64-linux-gnu" "$SYSROOT/lib/x86_64-linux-gnu"
cp -a "$PRE"/libc++.so.1 "$PRE"/libc++abi.so.1 "$SYSROOT/usr/lib/x86_64-linux-gnu/" 2>/dev/null || true
cp -a "$SYSROOT/usr/lib/x86_64-linux-gnu/libc++"* "$SYSROOT/lib/x86_64-linux-gnu/" 2>/dev/null || true

wrap_dir() {
  local d="$1"
  for f in "$d"/*; do
    case "$f" in *.real) continue;; esac
    [ -L "$f" ] && continue
    [ -f "$f" ] || continue
    if file -b "$f" | grep -q 'ELF 64-bit LSB.*x86-64'; then
      [ -e "$f.real" ] || cp -a "$f" "$f.real"
      cat > "$f" <<WRAP
#!/bin/sh
# android-qemu-wrapper (x86_64 -> aarch64)
exec $QEMU -0 "\$(basename "\$0")" -L $SYSROOT "$f.real" "\$@"
WRAP
      chmod +x "$f"
    fi
  done
}

wrap_dir "$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
wrap_dir "$CMAKE/bin"

cat > /opt/toolchains/bin/aapt2 <<WRAP
#!/bin/sh
exec $QEMU -L $SYSROOT /opt/android-sdk/build-tools/35.0.1/aapt2 "\$@"
WRAP
chmod +x /opt/toolchains/bin/aapt2
echo "toolchain wrappers ready"
"$CMAKE/bin/cmake" --version | head -2
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/clang" --version | head -1
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/ld.lld" --version | head -1
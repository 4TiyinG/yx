// 每次任务/聊天结束自动更新源码快照（CodeArts Agent chat.finished Hook）。
export const DshSnapshotPlugin = async ({ $, worktree, directory }) => {
  const root = worktree || directory || process.cwd()
  return {
    "chat.finished": async () => {
      try {
        // 快照脚本自带锁、完整性校验与原子替换；失败不阻塞任务收尾。
        await $`cd ${root} && bash scripts/snapshot.sh >/dev/null 2>&1`
      } catch {
        // ignore
      }
    },
  }
}